import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageDraw

class FirmaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Generador de Firma")

        # Variables para controlar el dibujo
        self.dibujando = False
        self.ultimo_x, self.ultimo_y = None, None

        # Crear un lienzo donde el usuario pueda dibujar
        self.lienzo = tk.Canvas(self.root, width=200, height=200, bg="white")
        self.lienzo.pack(padx=10, pady=10)

        # Iniciar imagen de fondo transparente
        self.imagen = Image.new("RGBA", (200, 200), (255, 255, 255, 0))
        self.draw = ImageDraw.Draw(self.imagen)

        # Conectar los eventos del mouse para dibujar
        self.lienzo.bind("<Button-1>", self.comenzar_dibujo)
        self.lienzo.bind("<B1-Motion>", self.dibujar)
        self.lienzo.bind("<ButtonRelease-1>", self.terminar_dibujo)

        # Botón para guardar la firma
        self.boton_guardar = tk.Button(self.root, text="Guardar Firma", command=self.guardar_firma)
        self.boton_guardar.pack(pady=10)

    def comenzar_dibujo(self, event):
        self.dibujando = True
        self.ultimo_x, self.ultimo_y = event.x, event.y

    def dibujar(self, event):
        if self.dibujando:
            x, y = event.x, event.y
            self.lienzo.create_line(self.ultimo_x, self.ultimo_y, x, y, width=2, fill="black", capstyle=tk.ROUND, smooth=tk.TRUE)

            # Dibujar sobre la imagen para conservar el trazo
            self.draw.line([self.ultimo_x, self.ultimo_y, x, y], fill="black", width=2)

            self.ultimo_x, self.ultimo_y = x, y

    def terminar_dibujo(self, event):
        self.dibujando = False

    def guardar_firma(self):
        # Pedir al usuario el nombre y lugar para guardar la imagen
        archivo = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png")])
        if archivo:
            self.imagen.save(archivo)
            print(f"Firma guardada en: {archivo}")

# Crear la ventana principal
root = tk.Tk()
app = FirmaApp(root)

# Ejecutar la interfaz gráfica
root.mainloop()
