<?php
// Configurar el tipo de contenido como JSON
header('Content-Type: application/json; charset=utf-8');

// Deshabilitar el reporte de errores para evitar que aparezcan en el JSON
error_reporting(0);
ini_set('display_errors', 0);

try {
    // Conexión a la base de datos
    $serverName = "PA-S1-DATA\\UCQNDATA";
    $connectionInfo = array(
        "Database" => "recep_tec", 
        "UID" => "sadumesm", 
        "PWD" => "Dumes100%", 
        "characterset" => "UTF-8"
    );
    
    $conn = sqlsrv_connect($serverName, $connectionInfo);

    if (!$conn) {
        throw new Exception("Error de conexión a la base de datos");
    }

    // Obtener total de usuarios
    $queryTotal = "SELECT COUNT(*) as total FROM firma_usuarios";
    $stmtTotal = sqlsrv_query($conn, $queryTotal);
    
    if (!$stmtTotal) {
        throw new Exception("Error al consultar total de usuarios");
    }
    
    $rowTotal = sqlsrv_fetch_array($stmtTotal, SQLSRV_FETCH_ASSOC);
    $total = $rowTotal['total'] ?? 0;

    // Obtener usuarios con imagen
    $queryConImagen = "SELECT COUNT(*) as con_imagen FROM firma_usuarios WHERE RutaImagen IS NOT NULL AND RutaImagen != ''";
    $stmtConImagen = sqlsrv_query($conn, $queryConImagen);
    
    if (!$stmtConImagen) {
        throw new Exception("Error al consultar usuarios con imagen");
    }
    
    $rowConImagen = sqlsrv_fetch_array($stmtConImagen, SQLSRV_FETCH_ASSOC);
    $conImagen = $rowConImagen['con_imagen'] ?? 0;

    // Cerrar conexión
    sqlsrv_close($conn);

    // Devolver respuesta en JSON
    echo json_encode([
        'success' => true,
        'total' => intval($total),
        'con_imagen' => intval($conImagen)
    ]);

} catch (Exception $e) {
    // En caso de error, devolver respuesta de error en JSON
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'total' => 0,
        'con_imagen' => 0
    ]);
}
?>