<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recepcion</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="img/icono.ico" type="image/x-icon">
    <!-- Estilos personalizados -->
    <style>
/* Aplicamos el fondo de pantalla y estilizamos el cuerpo */
body, html {
    margin: 0;
    padding: 0;
    height: 100%;  /* Asegura que el fondo ocupe todo el alto de la página */
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-image: url('img/FONDO2025.jpg');  /* Ruta de la imagen de fondo */
    background-size: cover;  /* Hace que la imagen cubra toda el área */
    background-position: center;  /* Centra la imagen en la pantalla */
    background-attachment: fixed;  /* Hace que el fondo quede fijo mientras se hace scroll */
    display: flex;
    justify-content: center;  /* Centra el contenido horizontalmente */
    align-items: center;  /* Centra el contenido verticalmente */
    color: white;  /* Texto blanco por defecto para que resalte sobre el fondo */
    overflow: hidden;  /* Para evitar barras de desplazamiento */
    background-color: #1a1a2e; /* Color de respaldo */
}

        .table-container {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.85));
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border-radius: 25px;
            padding: 45px 40px;
            box-shadow: 
                0 8px 32px rgba(0, 0, 0, 0.2),
                0 0 0 1px rgba(255, 255, 255, 0.2);
            text-align: center;
            width: 100%;
            max-width: 750px;
            border: 1px solid rgba(255, 255, 255, 0.18);
            position: relative;
        }

        .table-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, 
                rgba(255, 255, 255, 0.1) 0%,
                rgba(255, 255, 255, 0.05) 100%);
            border-radius: 25px;
            pointer-events: none;
        }

        .table {
            position: relative;
            z-index: 1;
        }

        .btn-custom {
            margin: 15px 10px;
            padding: 20px 40px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 30px;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 280px;
            text-decoration: none;
            border: none;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .btn-custom::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.6s;
        }

        .btn-custom:hover::before {
            left: 100%;
        }

        .btn-custom i {
            margin-right: 12px;
            font-size: 20px;
            transition: transform 0.3s ease;
        }

        .btn-custom:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
        }

        .btn-custom:hover i {
            transform: scale(1.1);
        }

        .btn-custom:active {
            transform: translateY(-4px) scale(1.01);
            transition: all 0.1s ease;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, #BE1819 0%, #BE1819 100%);
            color: white;
        }

        .btn-primary-custom:hover {
            background: linear-gradient(135deg, #BE1819 0%, #BE1819 100%);
            color: white;
        }

        .btn-secondary-custom {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }

        .btn-secondary-custom:hover {
            background: linear-gradient(135deg, #0e8378 0%, #2dd654 100%);
            color: white;
        }

        .btn-success-custom {
            background: linear-gradient(135deg, #868f96 0%, #596164 100%);
            color: white;
        }

        .btn-success-custom:hover {
            background: linear-gradient(135deg, #7a8187 0%, #4f5659 100%);
            color: white;
        }

        .btn-success-custom1 {
            background: linear-gradient(135deg, #306CA0 0%, #306CA0 100%);
            color: white;
            position: relative;
        }

        .btn-success-custom1:hover {
            background: linear-gradient(135deg, #306CA0 0%, #306CA0 100%);
            color: white;
        }

        .text-below {
            margin-top: 15px;
            font-size: 15px;
            color: #666;
            font-weight: 500;
            opacity: 0.8;
            transition: opacity 0.3s ease;
        }

        .btn-custom:hover + .text-below {
            opacity: 1;
            color: #444;
        }

        /* Estilos mejorados para el modal de contraseña */
        #passwordModal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.9));
            backdrop-filter: blur(20px);
            padding: 40px 35px;
            border-radius: 20px;
            width: 420px;
            max-width: 90vw;
            text-align: center;
            box-shadow: 
                0 20px 60px rgba(0, 0, 0, 0.3),
                0 0 0 1px rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.18);
            animation: modalSlideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-30px) scale(0.9);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .modal-content h2 {
            color: #333;
            margin-bottom: 10px;
            font-size: 26px;
            font-weight: 700;       
            background: linear-gradient(135deg, #3D3A3A, #3D3A3A);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .modal-content p {
            color: #666;
            margin-bottom: 25px;
            font-size: 16px;
            font-weight: 500;
        }

        .modal-content input {
            width: 100%;
            padding: 15px 20px;
            margin: 15px 0 25px 0;
            font-size: 16px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            outline: none;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.8);
            box-sizing: border-box;
        }

        .modal-content input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            background: rgba(255, 255, 255, 0.95);
        }

        .modal-content button {
            padding: 12px 25px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            border-radius: 10px;
            margin: 5px 8px;
            transition: all 0.3s ease;
            min-width: 100px;
        }

        .modal-content button:first-of-type {
            background: linear-gradient(135deg, #138496, #138496);
            color: white;
        }

        .modal-content button:first-of-type:hover {
            background: linear-gradient(135deg, #138496, #138496);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }

        .modal-content button:last-of-type {
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            color: white;
        }

        .modal-content button:last-of-type:hover {
            background: linear-gradient(135deg, #ff5252, #e55039);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.3);
        }

        #errorMessage {
            color: #ff4757;
            font-weight: 600;
            margin-top: 15px;
            padding: 10px;
            background: rgba(255, 71, 87, 0.1);
            border-radius: 8px;
            border-left: 4px solid #ff4757;
        }

        /* Estilos para el modal de error */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(8px);
        }

        .modal .modal-content {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.9));
            margin: 15% auto;
            padding: 30px;
            border-radius: 20px;
            width: 80%;
            max-width: 450px;
            text-align: center;
            box-shadow: 
                0 20px 60px rgba(0, 0, 0, 0.3),
                0 0 0 1px rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }

        .close {
            color: #999;
            float: right;
            font-size: 28px;
            font-weight: bold;
            line-height: 1;
            transition: color 0.3s ease;
        }

        .close:hover,
        .close:focus {
            color: #ff4757;
            text-decoration: none;
            cursor: pointer;
            transform: scale(1.1);
        }

        .modal .modal-content h2 {
            color: #ff4757;
            margin-bottom: 15px;
            font-size: 24px;
            font-weight: 700;
        }

        .modal .modal-content p {
            color: #666;
            margin-bottom: 25px;
            font-size: 16px;
        }

        button.btn {
            padding: 12px 25px;
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            min-width: 100px;
        }

        button.btn:hover {
            background: linear-gradient(135deg, #ff5252, #e55039);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.3);
        }
    </style>
</head>
<body>
    <!-- Contenedor de la tabla -->
    <div class="table-container animate__animated animate__fadeIn">
        <table class="table">
            <tr>
                <td>
                    <a href="vista.php" class="btn btn-custom btn-primary-custom">
                        <i class="fas fa-rocket"></i>Insumos             
                    </a>
                    <div class="text-below">Descripción de insumos.</div>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="consultas.php" class="btn btn-custom btn-secondary-custom">
                     <i class="fa-solid fa-file-excel"></i> Generar Excel.
                    </a>
                    <div class="text-below">Busca número de movimiento y lo descarga.</div>
                </td>
            </tr>

            <tr>
            <td>
    <a href="javascript:void(0);" onclick="openPasswordModal()" class="btn btn-custom btn-success-custom1">
        <i class="fas fa-cogs"></i> Administrador.
    </a>
    <div class="text-below">Gestión de usuarios.</div>
</td>
</tr>

<!-- Modal de error -->
<div id="myModal" class="modal" style="display:none;">
    <div class="modal-content">
        <span class="close" onclick="closeErrorModal()">&times;</span>
        <h2>Contraseña Incorrecta</h2>
        <p>Lo siento, no tienes acceso. Por favor, ingresa la contraseña correcta.</p>
        <button onclick="closeErrorModal()" class="btn btn-danger">Cerrar</button>
    </div>
</div>

<!-- Modal de contraseña -->
<div id="passwordModal" class="modal" style="display:none;">
    <div class="modal-content">
        <h2>🔐 Acceso Restringido</h2>
        <p>Por favor ingresa la contraseña para continuar:</p>
        <input type="password" id="passwordField" placeholder="Ingresa tu contraseña...">
        <div>
            <button onclick="checkPassword()">✓ Aceptar</button>
            <button onclick="closePasswordModal()">✕ Cerrar</button>
        </div>
        <p id="errorMessage" style="color: red; display:none;">Lo siento, no tienes acceso. Por favor, ingresa la contraseña correcta.</p>
    </div>
</div>

        </table>
    </div>
<script>
function openPasswordModal() {
    // Mostrar el modal de contraseña
    document.getElementById("passwordModal").style.display = "flex";
}

function closePasswordModal() {
    // Cerrar el modal de contraseña
    document.getElementById("passwordModal").style.display = "none";
}

function checkPassword() {
    // Obtener el valor ingresado en el campo de contraseña
    var password = document.getElementById("passwordField").value;

    // Validar la contraseña
    if (password === "123") {
        // Si la contraseña es correcta, redirigir a la página
        window.location.href = "clave.php";  // Redirige a clave.php
    } else {
        // Si la contraseña es incorrecta, mostrar el mensaje de error
        document.getElementById("errorMessage").style.display = "block";
    }
}

// Función para mostrar el modal de error
function showErrorModal(message) {
    var modal = document.getElementById("myModal");
    var modalMessage = modal.querySelector("p");
    modalMessage.textContent = message;  // Establece el mensaje dentro del modal
    modal.style.display = "block";  // Muestra el modal
}

// Función para cerrar el modal de error
function closeErrorModal() {
    var modal = document.getElementById("myModal");
    modal.style.display = "none";  // Oculta el modal
}
</script>
    <!-- Bootstrap JS y dependencias -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>