<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recepcion</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="img/icono.ico" type="image/x-icon">
    <!-- Estilos personalizados -->
    <style>
/* Aplicamos el fondo de pantalla y estilizamos el cuerpo */
body, html {
    margin: 0;
    padding: 0;
    height: 100%;  /* Asegura que el fondo ocupe todo el alto de la página */
    font-family: 'Arial', sans-serif;
    background-image: url('img/FONDO2025.jpg');  /* Ruta de la imagen de fondo */
    background-size: cover;  /* Hace que la imagen cubra toda el área */
    background-position: center;  /* Centra la imagen en la pantalla */
    background-attachment: fixed;  /* Hace que el fondo quede fijo mientras se hace scroll */
    display: flex;
    justify-content: center;  /* Centra el contenido horizontalmente */
    align-items: center;  /* Centra el contenido verticalmente */
    color: white;  /* Texto blanco por defecto para que resalte sobre el fondo */
    overflow: hidden;  /* Para evitar barras de desplazamiento */
}

   

        .table-container {
            background-color: rgba(255, 255, 255, 0.8); /* Fondo semitransparente */
            backdrop-filter: blur(10px); /* Efecto de desenfoque */
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 100%;
            max-width: 600px;
        }

        .btn-custom {
            margin: 10px;
            padding: 15px 30px;
            font-size: 18px;
            border-radius: 25px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-custom i {
            margin-right: 10px;
        }

        .btn-custom:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .btn-custom:active {
            transform: translateY(0);
        }

        .btn-primary-custom {
            background-color: #007BFF;
            border-color: #007BFF;
        }

        .btn-secondary-custom {
            background-color:rgb(94, 223, 126);
            border-color:rgb(30, 116, 42);
        }

        .btn-success-custom {
            background-color:rgb(120, 124, 121);
            border-color:rgb(143, 158, 147);
        }
        .btn-success-custom1 {
            background-color:rgb(196, 173, 45);
            border-color:rgb(167, 101, 40);
        }
        .text-below {
            margin-top: 10px;
            font-size: 14px;
            color: #555;
        }

        /* Estilos para el modal */
.modal {
    display: none; /* El modal está oculto por defecto */
    position: fixed;
    z-index: 1; /* Se superpone a la página */
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto; /* Asegura que el contenido sea desplazable */
    background-color: rgba(0, 0, 0, 0.4); /* Fondo semitransparente */
    color: cadetblue;
}

/* Contenido del modal */
.modal-content {
    background-color: #fff;
    margin: 15% auto;
    padding: 20px;
    border-radius: 8px;
    width: 80%;
    max-width: 400px;
    text-align: center;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
}

/* El botón de cerrar */
.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

/* Estilo del botón de cerrar cuando se pasa el ratón por encima */
.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}

/* Estilo del botón dentro del modal */
button.btn {
    padding: 10px 20px;
    background-color: #ff4d4d; /* Rojo */
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button.btn:hover {
    background-color: #e60000;
}

#passwordModal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
}

.modal-content {
    background-color: white;
    padding: 20px;
    border-radius: 10px;
    width: 300px;
    text-align: center;
}

input {
    width: 80%;
    padding: 10px;
    margin: 10px 0;
    font-size: 16px;
}

button {
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
}

    </style>
</head>
<body>
    <!-- Contenedor de la tabla -->
    <div class="table-container animate__animated animate__fadeIn">
        <table class="table">
            <tr>
                <td>
                    <a href="vista.php" class="btn btn-custom btn-primary-custom">
                        <i class="fas fa-rocket"></i>Insumos             
                    </a>
                    <div class="text-below">Descripción de insumos</div>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="consultas.php" class="btn btn-custom btn-secondary-custom">
                     <i class="fa-solid fa-file-excel"></i> Generar Excel
                    </a>
                    <div class="text-below">Busca Número de Movimiento y lo descarga</div>
                </td>
            </tr>

            <tr>
            <td>
    <a href="javascript:void(0);" onclick="openPasswordModal()" class="btn btn-custom btn-success-custom1">
        <i class="fas fa-cogs"></i> Administrador
    </a>
    <div class="text-below">Botón 3 - Descripción breve</div>
</td>
</tr>

<!-- Modal de error -->
<div id="myModal" class="modal" style="display:none;">
    <div class="modal-content">
        <span class="close" onclick="closeErrorModal()">&times;</span>
        <h2>Contraseña Incorrecta</h2>
        <p>Lo siento, no tienes acceso. Por favor, ingresa la contraseña correcta.</p>
        <button onclick="closeErrorModal()" class="btn btn-danger">Cerrar</button>
    </div>
</div>

<!-- Modal de contraseña -->
<div id="passwordModal" class="modal" style="display:none;">
    <div class="modal-content">
        <h2>Acceso restringido</h2>
        <p>Por favor ingresa la contraseña para continuar:</p>
        <input type="password" id="passwordField" placeholder="Contraseña">
        <button onclick="checkPassword()">Aceptar</button>
        <button onclick="closePasswordModal()">Cerrar</button>
        <p id="errorMessage" style="color: red; display:none;">Lo siento, no tienes acceso. Por favor, ingresa la contraseña correcta.</p>
    </div>
</div>

        </table>
    </div>
<script>
function openPasswordModal() {
    // Mostrar el modal de contraseña
    document.getElementById("passwordModal").style.display = "flex";
}

function closePasswordModal() {
    // Cerrar el modal de contraseña
    document.getElementById("passwordModal").style.display = "none";
}

function checkPassword() {
    // Obtener el valor ingresado en el campo de contraseña
    var password = document.getElementById("passwordField").value;

    // Validar la contraseña
    if (password === "123") {
        // Si la contraseña es correcta, redirigir a la página
        window.location.href = "clave.php";  // Redirige a clave.php
    } else {
        // Si la contraseña es incorrecta, mostrar el mensaje de error
        document.getElementById("errorMessage").style.display = "block";
    }
}

// Función para mostrar el modal de error
function showErrorModal(message) {
    var modal = document.getElementById("myModal");
    var modalMessage = modal.querySelector("p");
    modalMessage.textContent = message;  // Establece el mensaje dentro del modal
    modal.style.display = "block";  // Muestra el modal
}

// Función para cerrar el modal de error
function closeErrorModal() {
    var modal = document.getElementById("myModal");
    modal.style.display = "none";  // Oculta el modal
}
</script>
    <!-- Bootstrap JS y dependencias -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>