<?php
// Conexión a la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array(
    "Database" => "recep_tec",
    "UID" => "jhonyrj",
    "PWD" => "Jhonny@2003",
    "CharacterSet" => "UTF-8"
);

$conn = sqlsrv_connect($serverName, $connectionInfo);

// Verificar si la conexión fue exitosa
if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
}

// Obtener la cédula de quien elabora
if (isset($_GET['cedula'])) {
    $cedulaElabora = $_GET['cedula'];

    // Consulta SQL para obtener la ruta de la imagen de quien elabora
    $sql = "SELECT RutaImagen FROM firma_usuarios WHERE Identificacion = ?";
    $stmt = sqlsrv_prepare($conn, $sql, array(&$cedulaElabora));

    if (sqlsrv_execute($stmt)) {
        if (sqlsrv_has_rows($stmt)) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            echo json_encode(array("success" => true, "RutaImagen" => $row['RutaImagen']));
        } else {
            echo json_encode(array("success" => false, "error" => "Cédula no encontrada"));
        }
    } else {
        echo json_encode(array("success" => false, "error" => "Error al ejecutar la consulta"));
    }
} else {
    echo json_encode(array("success" => false, "error" => "Cédula no proporcionada"));
}
?>
