
-- Usar la base de datos creada
USE recep_tec;
-- Crear la tabla insumos
CREATE TABLE insumos (
    [No. Orden] INT NULL,
    Proveedor NVARCHAR(255) NULL,
    [No. Movimiento] INT NULL,
    [Tipo Movimiento] NVARCHAR(255) NULL,
    [Fecha Movimiento] DATETIME NULL,
    [Tipo Documento] NVARCHAR(255) NULL,
    [No. Documento soporte] INT NULL,
    [Cod. Producto] NVARCHAR(255) NULL,
    [Producto_Comercial] NVARCHAR(255) NULL,
    [Forma Farmaceutica] NVARCHAR(255) NULL,
    Presentacion NVARCHAR(255) NULL,
    Fabricante NVARCHAR(255) NULL,
    Lote NVARCHAR(255) NULL,
    [Fecha Vencimiento] DATETIME NULL,
    [Cantidad Mov] INT NULL,
    Valor DECIMAL(18, 2) NULL,
    [Registro Sanitario] NVARCHAR(255) NULL,
    [Vigencia registro Sanitario] NVARCHAR(255) NULL,
    CUM NVARCHAR(255) NULL,
    [Codigo Clasificacion] NVARCHAR(255) NULL,
    Clasificacion NVARCHAR(255) NULL,
    Observacion NVARCHAR(MAX) NULL,
    Usuario NVARCHAR(255) NULL,
    condi VARCHAR(255) NULL,
    ID INT IDENTITY(1,1) PRIMARY KEY -- Agregado el campo autoincrementable como llave primaria
);



-- Crear la tabla firma_usuarios
CREATE TABLE firma_usuarios (
    NomYApellCmp NVARCHAR(255) NOT NULL,
    Identificacion NVARCHAR(255) NOT NULL,
    Imagen VARBINARY(MAX) NULL, -- Para almacenar la imagen
    FechaRegistro DATETIME NOT NULL
);


---agregar campo 
ALTER TABLE insumos
ADD condi VARCHAR(255) NULL;
