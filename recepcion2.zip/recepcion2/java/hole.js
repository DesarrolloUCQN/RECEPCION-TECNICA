$("#generatePDFBtn").click(function () {
    var noMovimiento = $("#searchInput").val();
    var tipoMovimiento = $("#tipoMovimiento").val();

    if (noMovimiento && noMovimiento.trim() !== "" && tipoMovimiento && tipoMovimiento.trim() !== "") {
        console.log("No. Movimiento: ", noMovimiento);
        console.log("Tipo Movimiento: ", tipoMovimiento);

        $.ajax({
            url: "generacion.php",
            type: "POST",
            data: { noMovimiento: noMovimiento, tipoMovimiento: tipoMovimiento },
            success: function (response) {
                console.log("Respuesta del servidor: ", response);

                try {
                    var data = JSON.parse(response);

                    if (Array.isArray(data) && data.length > 0) {
                        const elaboracion = data[0]["elaboracion"];
                        const aprobacion = data[0]["aprobacion"];
                        const validado = data[0]["validado"];

                        if (validado === "No Aprobado") {
                            alert("No se puede generar el PDF porque el movimiento no está aprobado.");
                            return;
                        }

                        if (elaboracion && aprobacion && validado) {
                            const { jsPDF } = window.jspdf;
                            const doc = new jsPDF("landscape");
                            const img = new Image();
                            img.src = "Imagen1.jpg";

                            img.onload = function () {
                                doc.addImage(img, "PNG", 50, 5, 200, 23);
                                doc.setFontSize(12);

                                let yPosition = 39;
                                const marginLeft = 8;

                                // Función para abreviar encabezados
                                const abbreviateHeader = (text) => {
                                    const abbreviations = {
                                        "ACTA No.": "ACTA",
                                        "Proveedor": "PROV.",
                                        "FACTURA No.": "FACT.",
                                        "FECHA OC": "F. OC",
                                        "FECHA FACTURA": "F. FACT.",
                                        "FECHA RECIBIDO": "F. RECIB.",
                                        "FECHA RECEPCION": "F. RECEP.",
                                        "OBSERVACIÓN GENERAL": "OBS. GEN.",
                                        "Condiciones de Transporte": "COND. TRANS.",
                                        "Forma Farmaceútica": "FORM. FARM.",
                                        "Cadena de frío": "CAD. FRÍO",
                                        "Presentación": "PRESENT.",
                                        "Fabricante": "FABRIC.",
                                        "Fecha Vencimiento": "F. VENC.",
                                        "Cantidad Recibida": "CANT. REC.",
                                        "Cantidad Solicitada": "CANT. SOL.",
                                        "Precio Pactado en OC": "PRECIO OC",
                                        "Registro Sanitario": "REG. SAN.",
                                        "Vigencia Registro": "VIG. REG.",
                                        "Código CUM/IUM": "CUM/IUM",
                                        "Clasificación Riesgo/ATC": "CLAS. ATC",
                                        "Tamaño Muestra": "TAM. MUEST.",
                                        "Validación": "VALID.",
                                        "Observacion": "OBS."
                                    };
                                    return abbreviations[text] || text;
                                };

                                // Primera tabla con encabezados abreviados
                                const headers1 = [
                                    "ACTA",
                                    "PROV.",
                                    "FACT.",
                                    "F. OC",
                                    "F. FACT.",
                                    "F. RECIB.",
                                    "F. RECEP."
                                ];

                                const rows1 = data.map((row) => [
                                    row["ID"],
                                    row["Proveedor"],
                                    row["Cod. Producto"],
                                    new Date(row["fecha_oc"]["date"]).toISOString().split("T")[0],
                                    new Date(row["fecha_factura"]["date"]).toISOString().split("T")[0],
                                    new Date(row["Fecha Movimiento"]["date"]).toISOString().split("T")[0],
                                    new Date(row["fecha_re"]["date"]).toISOString().split("T")[0]
                                ]);

                                doc.autoTable({
                                    startY: yPosition,
                                    head: [headers1],
                                    body: rows1,
                                    tableWidth: "auto",
                                    margin: { left: 30 },
                                    styles: {
                                        fontSize: 7,
                                        lineWidth: 0.1, // grosor del borde
                                        lineColor: [0, 0, 0], // color del borde (negro)
                                        cellPadding: 1,
                                        halign: 'center'
                                    },
                                    headStyles: {
                                        fillColor: [201, 201, 201],
                                        textColor: [0, 0, 0],
                                        fontStyle: "bold",
                                        halign: 'center'
                                    }
                                });

                                yPosition = doc.lastAutoTable.finalY + 10;

                                // Segunda tabla con encabezados abreviados
                                const headers2 = [
                                    "CÓDIGO",
                                    "DESCRIP.",
                                    "COND. TRANS.",
                                    "FORM. FARM.",
                                    "CAD. FRÍO",
                                    "MCE",
                                    "PRESENT.",
                                    "FABRIC.",
                                    "LOTE",
                                    "F. VENC.",
                                    "CANT. REC.",
                                    "CANT. SOL.",
                                    "PRECIO OC",
                                    "REG. SAN.",
                                    "VIG. REG.",
                                    "CUM/IUM",
                                    "CLAS. ATC",
                                    "TAM. MUEST.",
                                    "DEFECTO",
                                    "VALID.",
                                    "OBS."
                                ];

                                const rows2 = data.map((row) => [
                                    row["Cod. Producto"],
                                    row["Producto_Comercial"],
                                    row["condi"],
                                    row["Forma Farmaceutica"],
                                    row["cadena"],
                                    row["mce"],
                                    row["Presentacion"],
                                    row["Fabricante"],
                                    row["Lote"],
                                    new Date(row["Fecha Vencimiento"]["date"]).toISOString().split("T")[0],
                                    row["Cantidad Mov"],
                                    row["cant_soli"],
                                    row["pac"],
                                    row["Registro Sanitario"],
                                    row["Vigencia Registro Sanitario"],
                                    row["CUM"],
                                    row["Codigo Clasificacion"],
                                    row["muestra"],
                                    row["defecto"],
                                    row["validado"],
                                    row["observacion_usu"]
                                ]);

                                doc.autoTable({
                                    startY: yPosition,
                                    head: [headers2],
                                    body: rows2,
                                    tableWidth: "auto",
                                    margin: { left: marginLeft },
                                    styles: {
                                        fontSize: 7,
                                        cellPadding: 1,
                                        halign: 'center',
                                        lineWidth: 0.1, // grosor del borde
                                        lineColor: [0, 0, 0] // color del borde (negro)
                                    },
                                    headStyles: {
                                        fillColor: [201, 201, 201],
                                        textColor: [0, 0, 0],
                                        fontStyle: "bold",
                                        halign: 'center'
                                    }
                                });

                                // Agregar observación general en la parte derecha
                                yPosition = doc.lastAutoTable.finalY + 10;
                                const observacion = data[0]["obser_gen"];

                                if (observacion && observacion.trim() !== "") {
                                    // Si la observación es muy larga y no cabe, agregar nueva página
                                    if (yPosition > doc.internal.pageSize.height - 50) {
                                        doc.addPage();
                                        yPosition = 20;
                                    }

                                    doc.setFontSize(9);
                                    doc.text("Observación General:", doc.internal.pageSize.width - 70, yPosition);
                                    doc.setFontSize(8);

                                    // Dividir el texto en líneas si es muy largo
                                    const splitLines = doc.splitTextToSize(observacion, 60);

                                    // Calcular la posición y el tamaño del borde
                                    const startX = doc.internal.pageSize.width - 70;
                                    const startY = yPosition + 5;
                                    const borderWidth = 60; // Ancho del borde
                                    const borderHeight = splitLines.length * 5 + 10; // Altura del borde

                                    // Dibujar el borde
                                    doc.rect(startX - 2, startY - 5, borderWidth + 4, borderHeight, 'S'); // 'S' para borde sólido

                                    // Agregar el texto dentro del borde
                                    doc.text(splitLines, startX, startY);
                                    yPosition += borderHeight; // Actualizar la posición Y

                                }

                                // Agregar firmas
                                const addFirmas = async () => {
                                    const pageHeight = doc.internal.pageSize.height;

                                    // Verificar si hay espacio para las firmas
                                    if (yPosition > pageHeight - 50) {
                                        doc.addPage();
                                        yPosition = 20;
                                    }

                                    doc.setFontSize(8.5);

                                    try {
                                        const firmaElaboracion = await loadImage(data[0]["elaboracionRutaImagen"]);
                                        const firmaAprobacion = await loadImage(data[0]["aprobacionRutaImagen"]);

                                        const elaboraX = 50;
                                        doc.text("Elabora:", elaboraX, yPosition);
                                        doc.line(elaboraX, yPosition + 5, elaboraX + 60, yPosition + 5);
                                        doc.addImage(firmaElaboracion, "JPEG", elaboraX + 20, yPosition - 10, 40, 20);
                                        doc.text(data[0]["elaboracion"], elaboraX + 10, yPosition + 10);
                                        doc.text(data[0]["elaboracionNombre"], elaboraX + 10, yPosition + 15);

                                        const apruebaX = doc.internal.pageSize.width - 150;
                                        doc.text("Aprueba:", apruebaX, yPosition);
                                        doc.line(apruebaX, yPosition + 5, apruebaX + 60, yPosition + 5);
                                        doc.addImage(firmaAprobacion, "JPEG", apruebaX + 20, yPosition - 10, 40, 20);
                                        doc.text(data[0]["aprobacion"], apruebaX + 10, yPosition + 10);
                                        doc.text(data[0]["aprobacionNombre"], apruebaX + 10, yPosition + 15);

                                        doc.save("reporte_insumos.pdf");
                                    } catch (error) {
                                        console.error("Error al cargar las imágenes de las firmas:", error);
                                        alert("Hubo un problema al cargar las imágenes de las firmas.");
                                    }
                                };

                                addFirmas();
                            };

                            img.onerror = function () {
                                console.error("Error al cargar la imagen principal.");
                                alert("No se pudo cargar la imagen para el encabezado.");
                            };
                        } else {
                            alert("No se puede generar el PDF porque faltan datos en los campos de elaboración o aprobación");
                        }
                    } else {
                        alert("No se encontraron registros para el No. Movimiento.");
                    }
                } catch (e) {
                    alert("Error al procesar la respuesta: " + e.message);
                }
            },
            error: function (xhr, status, error) {
                alert("Ocurrió un error en la solicitud: " + error);
            },
        });
    } else {
        alert("El No. Movimiento es obligatorio.");
    }
});

// Función auxiliar para cargar imágenes
function loadImage(ruta) {
    return new Promise((resolve, reject) => {
        if (!ruta || ruta === "") {
            ruta = "/recepcion/imagenes/default.jpeg";
        }
        const img = new Image();
        img.src = ruta;
        img.onload = () => resolve(img);
        img.onerror = (err) => reject(err);
    });
}