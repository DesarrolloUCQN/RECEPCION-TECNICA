$("#generatePDFBtn").click(function () {
  var noMovimiento = $("#searchInput").val();
  var tipoMovimiento = $("#tipoMovimiento").val();

  // Mapeo de abreviaturas para tipos de movimiento
  const tipoMovimientoAbreviado = {
    "Compra Directa": "Cd",
    Remisión: "R",
    "Ingreso por Préstamo de Otra Institución": "Ipp",
    "Ingreso por Aprovechamiento": "Ipa",
    "Ingreso Devolución Préstamo": "Ipd",
    "Compra por Orden": "OC",
  };

  if (
    noMovimiento &&
    noMovimiento.trim() !== "" &&
    tipoMovimiento &&
    tipoMovimiento.trim() !== ""
  ) {
    console.log("No. Movimiento: ", noMovimiento);
    console.log("Tipo Movimiento: ", tipoMovimiento);

    // Obtener abreviatura para el nombre del archivo
    const abreviatura = tipoMovimientoAbreviado[tipoMovimiento] || "Mov";
    const nombreArchivo = `${abreviatura}_${noMovimiento}.pdf`;

    $.ajax({
      url: "generacion.php",
      type: "POST",
      data: { noMovimiento: noMovimiento, tipoMovimiento: tipoMovimiento },
      success: function (response) {
        console.log("Respuesta del servidor: ", response);

        try {
          var data = JSON.parse(response);

          if (Array.isArray(data) && data.length > 0) {
            const elaboracion = data[0]["elaboracion"];
            const aprobacion = data[0]["aprobacion"];
            const validado = data[0]["validado"];

            if (validado === "No Aprobado") {
              alert(
                "No se puede generar el PDF porque el movimiento no está aprobado."
              );
              return;
            }

            if (elaboracion && aprobacion && validado) {
              const { jsPDF } = window.jspdf;
              const doc = new jsPDF("landscape");
              const img = new Image();
              img.src = "captura2.png";

              img.onload = function () {
                doc.addImage(img, "PNG",5, 5, 280, 15); //configuracion
                doc.setFontSize(12);

                let yPosition = 39;
                const marginLeft = 8;

                // Función para abreviar encabezados
                const abbreviateHeader = (text) => {
                  const abbreviations = {
                    "ACTA No.": "ACTA",
                    Proveedor: "PROV.",
                    "FACTURA No.": "FACT.",
                    "FECHA OC": "F. OC",
                    "FECHA FACTURA": "F. FACT.",
                    "FECHA RECIBIDO": "F. RECIB.",
                    "FECHA RECEPCION": "F. RECEP.",
                    "OBSERVACIÓN GENERAL": "OBS. GEN.",
                    "Condiciones de Transporte": "COND. TRANS.",
                    "Forma Farmaceútica": "FORM. FARM.",
                    "Cadena de frío": "CAD. FRÍO",
                    "Condiciones de Almacenamiento": "",
                    Presentación: "PRESENT.",
                    Fabricante: "FABRIC.",
                    "Fecha Vencimiento": "F. VENC.",
                    "Cantidad Recibida": "CANT. REC.",
                    "Cantidad Solicitada": "CANT. SOL.",
                    "Precio Pactado en OC": "PRECIO OC",
                    "Registro Sanitario": "REG. SAN.",
                    "Vigencia Registro": "VIG. REG.",
                    "Código CUM/IUM": "CUM/IUM",
                    "Clasificación Riesgo/ATC": "CLAS. ATC",
                    "Tamaño Muestra": "TAM. MUEST.",
                    Validación: "VALID.",
                    Observacion: "OBS.",
                  };
                  return abbreviations[text] || text;
                };

                // Primera tabla con encabezados abreviados
                const headers1 = [
                  "Número de Movimiento",
                  "Proveedor",
                  "Número de Factura",
                  "Fecha de Orden de Compra",
                  "Fecha de Factura",
                  "Fecha de Recibido",
                  "Fecha de Recepción",
                ];

                const rows1 = [data[0]].map((row) => [
                  row["No. Movimiento"],
                  row["Proveedor"],
                  row["Cod. Producto"],
                  new Date(row["fecha_oc"]["date"]).toISOString().split("T")[0],
                  new Date(row["fecha_factura"]["date"])
                    .toISOString()
                    .split("T")[0],
                  new Date(row["Fecha Movimiento"]["date"])
                    .toISOString()
                    .split("T")[0],
                  new Date(row["fecha_re"]["date"]).toISOString().split("T")[0],
                ]);

                // 🔼 Subimos la tabla -X unidades
                const tablaStartY = yPosition -15;

                doc.autoTable({
                  startY: tablaStartY,
                  head: [headers1],
                  body: rows1,
                  tableWidth: "auto", // 👈 Ensures table width is based on content, not stretched
                  margin: { left: 8}, // para mover ala derecha o izquierda
                  styles: {
                    fontSize: 5,
                    cellPadding: 1,
                    halign: "center",
                  },
                  headStyles: {
                    fillColor: [201, 201, 201],
                    textColor: [0, 0, 0],
                    fontStyle: "bold",
                    halign: "center",
                  },
                });

                // 🔁 Ajustar yPosition con base en el final de la tabla
                yPosition = doc.lastAutoTable.finalY + 10;

                // -----------2---Segunda tabla con encabezados abreviados
                const headers2 = [
                  "CÓDIGO",
                  "DESCRIPCIÓN",
                  "CONDICIÓN DE TRANSPORTE",
                  "FORMA FARMACÉUTICA",
                  "CADENA DE FRÍO",
                  "CONDICIONES DE ALMACENAMIENTO",
                  "MCE",
                  "PRESENTACIÓN",
                  "FABRICANTE",
                  "LOTE",
                  "FECHA DE VENCIMIENTO",
                  "CANTIDAD RECIBIDA ",
                  "CANTIDAD SOLICITADA",
                  "PRECIO OC",
                  "REGISTRO SANITARIO",
                  "VIGENCIA DEL REGISTRO SANITARIO",
                  "CUM/IUM",
                  "ATC/RIESGO",
                  "TAMAÑO DE MUESTRA",
                  "DEFECTO",
                  "APROBADO/RECHAZADA",
                  "OBSERVACIÓN DE USUARIO",
                ];

                const rows2 = data.map((row) => [
                  row["Cod. Producto"],
                  row["Producto_Comercial"],
                  row["condi"],
                  row["Forma Farmaceutica"],
                  row["cadena"],
                  row["condiciones_de_almacenamiento"],
                  row["mce"],
                  row["Presentacion"],
                  row["Fabricante"],
                  row["Lote"],
                  new Date(row["Fecha Vencimiento"]["date"])
                    .toISOString()
                    .split("T")[0],
                  row["Cantidad Mov"],
                  row["cant_soli"],
                  row["pac"],
                  row["Registro Sanitario"],
                  row["Vigencia Registro Sanitario"],
                  row["CUM"],
                  row["Codigo Clasificacion"],
                  row["muestra"],
                  row["defecto"],
                  row["validado"],
                  row["observacion_usu"],
                ]);

                // 🔼 Subimos la tabla 8 unidades
                yPosition = yPosition - 8;

                doc.autoTable({
                  startY: yPosition,
                  head: [headers2],
                  body: rows2,
                  tableWidth: "auto",
                  margin: { left: marginLeft },
                  styles: {
                    fontSize: 4,
                    cellPadding: 1,
                    halign: "center",
                  },
                  headStyles: {
                    fillColor: [201, 201, 201],
                    textColor: [0, 0, 0],
                    fontStyle: "bold",
                    halign: "center",
                  },
                });

                yPosition = doc.lastAutoTable.finalY + 10;

                // ----------------- TABLA DE CONVENCIONES ULTRA COMPACTA -----------------//
                const addTablaConvencionesCompacta = (doc, yPosition) => {
                  // Configuración ultra compacta
                  const headers = [
                    {
                      content: "COLUMNA",
                      styles: {
                        fillColor: [220, 220, 220],
                        fontStyle: "bold",
                        halign: "center",
                        fontSize: 5,
                      },
                    },
                    {
                      content: "CONVENCIÓN",
                      styles: {
                        fillColor: [220, 220, 220],
                        fontStyle: "bold",
                        halign: "center",
                        fontSize: 5,
                      },
                    },
                    {
                      content: "SIGNIFICADO",
                      styles: {
                        fillColor: [220, 220, 220],
                        fontStyle: "bold",
                        halign: "center",
                        fontSize: 5,
                      },
                    },
                  ];

                  const rows = [
                    ["Condicion.", "C / NC", "Cumple / No cumple"],
                    ["", "MCE", "Medicamento de Control Especial"],
                    ["Precio", "Sí / No", "Precio pactado"],
                    ["Clasificacion.", "ATC / Riesgo", "Medicamento / Dispositivo"],
                    ["Defecto", "Cr / My / Mn", "Crítico / Mayor / Menor"],
                    ["Aprobado / Rechazada", "", "Aprobado / Rechazado"],
                  ];

                  // 1. CALCULAR ALTURA DE LA TABLA (más preciso)
                  const alturaPorFila = 4.5; // altura estimada por fila en mm
                  const alturaEncabezado = 5;
                  const alturaTotal =
                    alturaEncabezado + rows.length * alturaPorFila;

                  // 2. DEFINIR POSICIÓN DESEADA (ajusta estos valores)
                  const margenInferiorDeseado = 15; // espacio entre tabla y final de página
                  const posicionDeseada =
                    doc.internal.pageSize.height -
                    margenInferiorDeseado -
                    alturaTotal;

                  // 3. DECIDIR LA POSICIÓN REAL DE LA TABLA (la mayor entre posición actual y deseada)
                  const startY = yPosition - 30; // 🔼 O el valor que necesites// +10 para asegurar espacio para hacwr mas abajo la tabla

                  // 4. VERIFICAR SI NECESITAMOS NUEVA PÁGINA
                  if (
                    startY + alturaTotal >
                    doc.internal.pageSize.height - 10
                  ) {
                    doc.addPage();
                    yPosition = 15;
                    // Repetir cálculo para nueva página
                    const nuevaPosicionDeseada =
                      doc.internal.pageSize.height -
                      margenInferiorDeseado -
                      alturaTotal;
                    startY = Math.max(yPosition, nuevaPosicionDeseada);
                  }

                  // 5. GENERAR TABLA EN POSICIÓN CALCULADA
                  doc.autoTable({
                    startY: startY,
                    head: [headers],
                    body: rows,
                    margin: {
                      left: doc.internal.pageSize.width - 280,
                      right: 5,
                    }, // 🔼 AJUSTARA MAS ALA DERECHA
                    styles: {
                      fontSize: 4,
                      cellPadding: 1,
                      halign: "left",
                      lineColor: [180, 180, 180],
                      lineWidth: 0.1,
                    },
                    headStyles: {
                      fillColor: [220, 220, 220],
                      textColor: [0, 0, 0],
                      fontStyle: "bold",
                      fontSize: 4,
                    },
                    columnStyles: {
                      0: { cellWidth: 18, fontStyle: "bold" },
                      1: { cellWidth: 15, halign: "center" },
                      2: { cellWidth: 30 },
                    },
                    pageBreak: "avoid",
                    tableWidth: "wrap",
                    theme: "grid",
                  });

                  return doc.lastAutoTable.finalY;
                };

                // Agregar observación general en la parte derecha
                yPosition = doc.lastAutoTable.finalY + 5; // 🔹 Mantenemos la posición vertical original

                const observacion = data[0]["obser_gen"];

                if (observacion && observacion.trim() !== "") {
                  const splitLines = doc.splitTextToSize(observacion, 100); // 🔹 Reducimos el ancho para que quede más a la derecha
                  const totalHeight = splitLines.length * 5 + 10;

                  if (
                    yPosition + totalHeight >
                    doc.internal.pageSize.height - 20
                  ) {
                    doc.addPage();
                    yPosition = 20;
                  }

                  // 🔹 Movemos TODO el bloque (título y texto) más a la derecha
                  const rightMargin = 65; // 🔄 Ajusta este valor para moverlo más o menos (ej: 80, 90, 110)
                  const observacionX =
                    doc.internal.pageSize.width - rightMargin;

                  doc.setFontSize(6);
                  doc.text("Observación General:", observacionX, yPosition);
                  doc.setFontSize(6);
                  doc.text(splitLines, observacionX, yPosition + 5);

                  yPosition += totalHeight;
                }

                // Agregar firmas - Versión simplificada sin procesamiento de fondo
                async function loadSignatureImage(ruta) {
                  return new Promise((resolve) => {
                    try {
                      if (!ruta || ruta === "") {
                        ruta = "/recepcion/FIR.pngdfgh nm,cvb nm,.-";
                      }

                      const img = new Image();
                      img.crossOrigin = "Anonymous";
                      img.src = ruta;

                      img.onload = () => resolve(img);
                      img.onerror = () => {
                        const defaultImg = new Image();
                        defaultImg.src = "/recepcion/FIR.pngdfgh nm,cvb nm,.-";
                        defaultImg.onload = () => resolve(defaultImg);
                      };
                    } catch (error) {
                      console.error("Error cargando firma:", error);
                      const defaultImg = new Image();
                      defaultImg.src = "/recepcion/FIR.pngdfgh nm,cvb nm,.-";
                      defaultImg.onload = () => resolve(defaultImg);
                    }
                  });
                }

                // Función para agregar firmas al documento
                const addFirmas = async () => {
                  try {
                    // Cargar firmas directamente sin procesamiento
                    const firmaElaboracion = await loadSignatureImage(
                      data[0]["elaboracionRutaImagen"]
                    );
                    const firmaAprobacion = await loadSignatureImage(
                      data[0]["aprobacionRutaImagen"]
                    );

                    // Configuración de posición
                    const desplazamientoDerecha = 100;
                    const separacionFirmas = 70;
                    const firmaY = yPosition;
                    const elaboraX = desplazamientoDerecha;
                    const apruebaX = elaboraX + separacionFirmas;
                    const desplazamientoImagenes = 1; // Píxeles a bajar las imágenes

                    // Agregar firmas al PDF

                    doc.text("Elabora:", elaboraX, firmaY);
                    doc.line(elaboraX, firmaY + 3, elaboraX + 45, firmaY + 3);
                    // Imagen bajada (solo cambia el parámetro Y)
                    doc.addImage(
                      firmaElaboracion,
                      "PNG",
                      elaboraX + 14,
                      firmaY - 12 + desplazamientoImagenes,
                      30,
                      12
                    );
                    doc.setFontSize(6.5);
                    doc.text(data[0]["elaboracion"], elaboraX + 3, firmaY + 7);
                    doc.text(
                      data[0]["elaboracionNombre"],
                      elaboraX + 3,
                      firmaY + 11
                    );

                    // Firma Aprueba (texto y línea permanecen igual)
                    doc.setFontSize(6.5);
                    doc.text("Aprueba:", apruebaX, firmaY);
                    doc.line(apruebaX, firmaY + 3, apruebaX + 45, firmaY + 3);
                    // Imagen bajada (solo cambia el parámetro Y)
                    doc.addImage(
                      firmaAprobacion,
                      "PNG",
                      apruebaX + 14,
                      firmaY - 12 + desplazamientoImagenes,
                      30,
                      12
                    );
                    doc.setFontSize(6.5);
                    doc.text(data[0]["aprobacion"], apruebaX + 3, firmaY + 7);
                    doc.text(
                      data[0]["aprobacionNombre"],
                      apruebaX + 3,
                      firmaY + 11
                    );

                    yPosition = firmaY + 15;
                    yPosition = addTablaConvencionesCompacta(doc, yPosition);
                    doc.save(nombreArchivo);
                  } catch (error) {
                    console.error("Error al cargar firmas:", error);
                    alert("Error al generar firmas");
                  }
                };
                addFirmas();
              };

              img.onerror = function () {
                console.error("Error al cargar la imagen principal.");
                alert("No se pudo cargar la imagen para el encabezado.");
              };
            } else {
              alert(
                "No se puede generar el PDF porque faltan datos en los campos de elaboración o aprobación"
              );
            }
          } else {
            alert("No se encontraron registros para el No. Movimiento.");
          }
        } catch (e) {
          alert("Error al procesar la respuesta: " + e.message);
        }
      },
      error: function (xhr, status, error) {
        alert("Ocurrió un error en la solicitud: " + error);
      },
    });
  } else {
    alert("El No. Movimiento es obligatorio.");
  }
});

// Función auxiliar para cargar imágenes
function loadImage(ruta) {
  return new Promise((resolve, reject) => {
    if (!ruta || ruta === "") {
      ruta = "/recepcion/imagenes/default.jpeg";
    }
    const img = new Image();
    img.src = ruta;
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
  });
}
