$("#generatePDFBtn").click(function () {
  var noMovimiento = $("#searchInput").val();
  var tipoMovimiento = $("#tipoMovimiento").val(); // Obtener el tipo de movimiento

  if (noMovimiento && noMovimiento.trim() !== "" && tipoMovimiento && tipoMovimiento.trim() !== "") {
    console.log("No. Movimiento: ", noMovimiento);
    console.log("Tipo Movimiento: ", tipoMovimiento); // Mostrar el tipo de movimiento

    $.ajax({
      url: "generacion.php",
      type: "POST",
      data: { noMovimiento: noMovimiento, tipoMovimiento: tipoMovimiento },
      success: function (response) {
        console.log("Respuesta del servidor: ", response);

        try {
          var data = JSON.parse(response);

          if (Array.isArray(data) && data.length > 0) {
            // Verificar si los campos 'elaboracion', 'aprobacion' y 'validado' tienen datos
            const elaboracion = data[0]["elaboracion"];
            const aprobacion = data[0]["aprobacion"];
            const validado = data[0]["validado"];

            // Verificar si el campo 'validado' es "No Aprobado"
            if (validado === "No Aprobado") {
              alert(
                "No se puede generar el PDF porque el movimiento no está aprobado."
              );
              return; // Detener la ejecución
            }

            // Verificar si los campos 'elaboracion' y 'aprobacion' tienen datos
            if (elaboracion && aprobacion && validado) {
              const { jsPDF } = window.jspdf;
              const doc = new jsPDF("landscape");
              const img = new Image();
              img.src = "principal.png"; // Imagen principal del encabezado

              img.onload = function () {
                doc.addImage(img, "PNG", 30, 5, 230, 25);
                doc.setFontSize(12);

                let yPosition = 39;
                const marginLeft = 8;// Reducir este valor para mover las tablas más a la izquierda
                function splitLongText(text) {
                  // Comprobar si el valor es una cadena de texto válida
                  if (text && typeof text === 'string' && text.length > 20) {
                    return text.slice(0, 20) + "\n" + text.slice(20);
                  }
                  // Si no es válido o tiene menos de 20 caracteres, retornamos el texto tal cual
                  return text || ''; // Si es null o undefined, devolvemos un string vacío
                }

                // Primera tabla con 7 campos
                const headers1 = [
                  splitLongText("ACTA No.", 10),        // Abreviado
                  splitLongText("Proveedor", 10),       // Abreviado
                  splitLongText("FACTURA No.", 10),     // Abreviado
                  splitLongText("FECHA OC", 10),        // Abreviado
                  splitLongText("FECHA FACTURA", 10),   // Abreviado
                  splitLongText("FECHA RECIBIDO", 10),  // Abreviado
                  splitLongText("FECHA RECEPCION", 10),  // Abreviado
                  splitLongText("OBSERVACIÓN GENERAL", 10)
                ];

                const rows1 = data.map((row) => [
                  row["ID"],
                  row["Proveedor"],
                  row["Cod. Producto"],
                  new Date(row["fecha_oc"]["date"])
                    .toISOString()
                    .split("T")[0],
                  new Date(row["fecha_factura"]["date"])
                    .toISOString()
                    .split("T")[0],
                  new Date(row["Fecha Movimiento"]["date"])
                    .toISOString()
                    .split("T")[0],
                  new Date(row["fecha_re"]["date"])
                    .toISOString()
                    .split("T")[0],
                  row["obser_gen"]

                ]);

                doc.autoTable({
                  startY: yPosition,
                  head: [headers1],
                  body: rows1,
                  tableWidth: 220, // Ancho fijo de la tabla
                  margin: { left: 30 },
                  styles: {
                    fontSize: 7, cellPadding: 1,
                    halign: 'center' // Centrar celdas
                  },
                  headStyles: {
                    fillColor: [201, 201, 201],
                    textColor: [0, 0, 0],
                    fontStyle: "bold",
                    halign: 'center' // Centrar  encabezado
                  },
                  columnStyles: {
                    0: { cellWidth: "auto" }, // Ajustar el ancho de la columna según el contenido
                    1: { cellWidth: "auto" },
                    2: { cellWidth: "auto" },
                    3: { cellWidth: "auto" },
                    4: { cellWidth: "auto" },
                    5: { cellWidth: "auto" },
                    6: { cellWidth: "auto" },
                    7: { cellWidth: "auto" },
                    8: { cellWidth: "auto" },
                    9: { cellWidth: "auto" },
                    10: { cellWidth: "auto" },
                    11: { cellWidth: "auto" },
                  },

                });

                yPosition = doc.lastAutoTable.finalY + 10;

                // Segunda tabla con 12 campos (encabezados abreviados)
                const headers2 = [
                  splitLongText("Código", 10),
                  splitLongText("Descripción", 11),
                  splitLongText("Condiciones de Transporte", 11),
                  splitLongText("Forma Farmaceútica", 11),
                  splitLongText("Cadena de frío", 11),
                  splitLongText("condiciones_de_almacenamiento", 11),
                  splitLongText("Presentación", 11),
                  splitLongText("Fabricante", 11),
                  splitLongText("Lote", 11),
                  splitLongText("Fecha Vencimiento", 11),
                  splitLongText("Cantidad Recibida", 11),
                  splitLongText("Cantidad Solicitada", 11),
                  splitLongText("Precio Pactado en OC", 11),
                  splitLongText("Registro Sanitario", 11),
                  splitLongText("Vigencia Registro", 11),
                  splitLongText("Código CUM/IUM", 11),
                  splitLongText("Clasificación Riesgo/ATC", 11),
                  splitLongText("Tamaño Muestra", 11),
                  splitLongText("Defecto", 10),
                  splitLongText("Validación", 11),
                  splitLongText("Observacion", 11)
                ];

                const rows2 = data.map((row) => [
                  splitLongText(row["Cod. Producto"]),
                  splitLongText(row["Producto_Comercial"]),
                  splitLongText(row["condi"]),
                  splitLongText(row["Forma Farmaceutica"]),
                  splitLongText(row["cadena"]),
                  splitLongText(row["mce"]),
                  splitLongText(row["Presentacion"]),
                  splitLongText(row["Fabricante"]),
                  splitLongText(row["Lote"]),
                  new Date(row["Fecha Vencimiento"]["date"]).toISOString().split("T")[0],
                  splitLongText(row["Cantidad Mov"]),
                  splitLongText(row["cant_soli"]),
                  splitLongText(row["pac"]),
                  splitLongText(row["Registro Sanitario"]),
                  splitLongText(row["Vigencia Registro Sanitario"]),
                  splitLongText(row["CUM"]),
                  splitLongText(row["Codigo Clasificacion"]),
                  splitLongText(row["muestra"]),
                  splitLongText(row["defecto"]),
                  splitLongText(row["validado"]),
                  splitLongText(row["observacion_usu"])

                ]);

                doc.autoTable({
                  startY: yPosition,
                  head: [headers2],
                  body: rows2,
                  tableWidth: 280, // Ancho fijo de la tabla
                  margin: { left: marginLeft },
                  styles: {
                    fontSize: 7, cellPadding: 1,
                    halign: 'center' // Centrar celdas
                  }, // Reducir el tamaño de la fuente para que quepa todo
                  headStyles: {
                    fillColor: [201, 201, 201],
                    textColor: [0, 0, 0],
                    fontStyle: "bold",
                    halign: 'center' // Centrar  encabezado
                  },
                  columnStyles: {
                    0: { cellWidth: "auto" }, // Ajustar el ancho de la columna según el contenido
                    1: { cellWidth: "auto" },
                    2: { cellWidth: "auto" },
                    3: { cellWidth: "auto" },
                    4: { cellWidth: "auto" },
                    5: { cellWidth: "auto" },
                    6: { cellWidth: "auto" },
                    7: { cellWidth: "auto" },
                    8: { cellWidth: "auto" },
                    9: { cellWidth: "auto" },
                    10: { cellWidth: "auto" },
                    11: { cellWidth: "auto" },
                  },
                });

                yPosition = doc.lastAutoTable.finalY + 50;
                const elaboracionCedula = String(data[0]["elaboracion"]);
                const aprobacionCedula = String(data[0]["aprobacion"]);
                const elaboracionNombre = data[0]["elaboracionNombre"];
                const aprobacionNombre = data[0]["aprobacionNombre"];

                const loadImage = (ruta) => {
                  return new Promise((resolve, reject) => {
                    if (!ruta || ruta === "") {
                      // Si la ruta es nula o vacía, usar una imagen predeterminada
                      ruta = "/recepcion/imagenes/default.jpeg"; // Asegúrate de que esta imagen predeterminada exista en el servidor
                    }

                    const img = new Image();
                    img.src = ruta;
                    img.onload = () => resolve(img);
                    img.onerror = (err) => reject(err);
                  });
                };

                const addFirmas = async () => {
                  const pageHeight = doc.internal.pageSize.height;
                  const margin = 20;

                  doc.setFontSize(8.5); // Tamaño de fuente más pequeño para la cédula y el nombre

                  try {
                    // Intentar cargar las imágenes de la firma
                    const firmaElaboracion = await loadImage(
                      data[0]["elaboracionRutaImagen"]
                    );
                    const firmaAprobacion = await loadImage(
                      data[0]["aprobacionRutaImagen"]
                    );

                    // Añadir las firmas al documento PDF
                    const lineHeight = 10; // Espacio entre la firma y el texto


                    // Elabora (Firma a la izquierda)
                    const elaboraX = margin + 50; // Mover más a la izquierda
                    doc.text("Elabora:", elaboraX, yPosition);
                    doc.line(
                      elaboraX,
                      yPosition + 5,
                      elaboraX + 60,
                      yPosition + 5
                    ); // Línea para la firma
                    doc.addImage(
                      firmaElaboracion,
                      "JPEG",
                      elaboraX + 10,
                      yPosition - 10,
                      40,
                      20
                    ); // Firma (más a la izquierda)

                    // Cédula y nombre debajo de la firma (izquierda)
                    doc.text(elaboracionCedula, elaboraX + 10, yPosition + 10); // Cédula
                    doc.text(elaboracionNombre, elaboraX + 10, yPosition + 15); // Nombre (más cerca de la cédula)

                    // Aprueba (Firma a la derecha)
                    const apruebaX = doc.internal.pageSize.width - 150; // Mover más a la derecha
                    doc.text("Aprueba:", apruebaX, yPosition);
                    doc.line(
                      apruebaX,
                      yPosition + 5,
                      apruebaX + 60,
                      yPosition + 5
                    ); // Línea para la firma
                    doc.addImage(
                      firmaAprobacion,
                      "JPEG",
                      apruebaX + 10,
                      yPosition - 10,
                      40,
                      20
                    ); // Firma (más a la izquierda)

                    // Cédula y nombre debajo de la firma (derecha)
                    doc.text(aprobacionCedula, apruebaX + 10, yPosition + 10); // Cédula
                    doc.text(aprobacionNombre, apruebaX + 10, yPosition + 15); // Nombre (más cerca de la cédula)

                    // Esperar a que las firmas se agreguen antes de guardar el PDF
                    doc.save("reporte_insumos.pdf");
                  } catch (error) {
                    console.error(
                      "Error al cargar las imágenes de las firmas:",
                      error
                    );
                    alert(
                      "Hubo un problema al cargar las imágenes de las firmas."
                    );
                  }
                };

                addFirmas(); // Llamar a la función que maneja las firmas
              };

              img.onerror = function () {
                console.error("Error al cargar la imagen principal.");
                alert("No se pudo cargar la imagen para el encabezado.");
              };
            } else {
              alert(
                "No se puede generar el PDF porque faltan datos en los campos de elaboración o aprobación"
              );
            }
          } else {
            alert("No se encontraron registros para el No. Movimiento.");
          }
        } catch (e) {
          alert("Error al procesar la respuesta: " + e.message);
        }
      },
      error: function (xhr, status, error) {
        alert("Ocurrió un error en la solicitud: " + error);
      },
    });
  } else {
    alert("El No. Movimiento es obligatorio.");
  }
});
