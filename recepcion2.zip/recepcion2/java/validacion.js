// Función para verificar la clave cuando el usuario escribe en el campo de clave
document.getElementById("clave_input").addEventListener("input", function() {
    // Obtener la clave ingresada por el usuario
    var claveIngresada = document.getElementById("clave_input").value;
    console.log("Clave Ingresada:", claveIngresada);  // Ver la clave que el usuario está escribiendo
    
    // Verificar que se han ingresado exactamente 3 caracteres
    if (claveIngresada.length === 3) {
        // Obtener la clave guardada en el campo oculto
        var claveGuardada = document.getElementById("clave_oculta").value;
        console.log("Clave Guardada:", claveGuardada);  // Ver la clave oculta
        
        // Asegurarnos de que la clave oculta no esté vacía
        if (claveGuardada === "") {
            console.log("La clave oculta está vacía.");
            alert("No se ha encontrado la clave. Recargando...");
            location.reload();
            return;
        }

        // Comparar las claves
        if (claveIngresada === claveGuardada) {
            // Si las claves coinciden, continuar con el script
            console.log("Las claves coinciden.");
            alert("Las claves coinciden. Continuando...");
            // Aquí iría el resto del script que quieras ejecutar
        } else {
            // Si no coinciden, recargar la página
            console.log("Las claves no coinciden.");
            alert("Las claves no coinciden. Recargando...");
            location.reload();
        }
    } else {
        console.log("La clave ingresada tiene menos de 3 caracteres.");
    }
});

// Función para verificar la clave cuando el usuario escribe en el campo de clave
document.getElementById("clave_aprueba").addEventListener("input", function() {
    // Obtener la clave ingresada por el usuario
    var claveIngresada1 = document.getElementById("clave_aprueba").value;
    console.log("Clave Ingresada:", claveIngresada1);  // Ver la clave que el usuario está escribiendo
    
    // Verificar que se han ingresado exactamente 3 caracteres
    if (claveIngresada1.length === 3) {
        // Obtener la clave guardada en el campo oculto
        var claveGuardada1 = document.getElementById("clave_oculta2").value;
        console.log("Clave Guardada:", claveGuardada1);  // Ver la clave oculta
        
        // Asegurarnos de que la clave oculta no esté vacía
        if (claveGuardada1 === "") {
            console.log("La clave oculta está vacía.");
            alert("No se ha encontrado la clave. Recargando...");
            location.reload();
            return;
        }

        // Comparar las claves
        if (claveIngresada1 === claveGuardada1) {
            // Si las claves coinciden, continuar con el script
            console.log("Las claves coinciden.");
            alert("Las claves coinciden. Continuando...");
            // Aquí iría el resto del script que quieras ejecutar
        } else {
            // Si no coinciden, recargar la página
            console.log("Las claves no coinciden.");
            alert("Las claves no coinciden. Recargando...");
            location.reload();
        }
    } else {
        console.log("La clave ingresada tiene menos de 3 caracteres.");
    }
});