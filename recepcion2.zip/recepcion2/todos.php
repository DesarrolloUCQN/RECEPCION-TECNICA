<?php
// Mostrar errores en caso de fallos
ini_set('display_errors', 1);
error_reporting(E_ALL);
ini_set('memory_limit', '2G'); // Aumentar el límite de memoria

// Configurar la conexión con la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array(
    "Database" => "recep_tec",
    "UID" => "sadumesm",
    "PWD" => "Dumes100%",
    "characterset" => "UTF-8"
);
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    echo json_encode(["status" => "error", "message" => "Error en la conexión con la base de datos"]);
    exit;
}

// Capturar el valor de búsqueda y los parámetros adicionales
$searchQuery = isset($_GET['searchQuery']) ? trim($_GET['searchQuery']) : '';
$tipoMovimiento = isset($_GET['tipoMovimiento']) ? trim($_GET['tipoMovimiento']) : ''; // Valor único seleccionado

// Validar que ambos filtros estén presentes
if (empty($searchQuery) || empty($tipoMovimiento)) {
    echo json_encode(["status" => "error", "message" => "Debe proporcionar el número de movimiento y seleccionar un tipo de movimiento"]);
    exit;
}

// Consulta SQL con filtros para número de movimiento y tipo de movimiento
$query = "
    SELECT 
        i.[ID],
        i.[No. Orden], 
        i.Proveedor, 
        i.[No. Movimiento], 
        ISNULL(i.[Tipo Movimiento], '') AS [Tipo Movimiento], 
        ISNULL(i.[Fecha Movimiento], NULL) AS [Fecha Movimiento], 
        ISNULL(i.[Tipo Documento], '') AS [Tipo Documento], 
        ISNULL(i.[No. Documento soporte], '') AS [No. Documento soporte], 
        ISNULL(i.[Cod. Producto], '') AS [Cod. Producto], 
        ISNULL(i.[Producto_Comercial], '') AS [Producto_Comercial], 
        ISNULL(i.[Forma Farmaceutica], '') AS [Forma Farmaceutica], 
        ISNULL(i.Presentacion, '') AS Presentacion, 
        ISNULL(i.Fabricante, '') AS Fabricante, 
        ISNULL(i.Lote, '') AS Lote, 
        ISNULL(i.[Fecha Vencimiento], NULL) AS [Fecha Vencimiento], 
        ISNULL(i.Valor, 0) AS Valor, 
        ISNULL(i.[Registro Sanitario], '') AS [Registro Sanitario], 
        ISNULL(i.[Vigencia registro Sanitario], '') AS [Vigencia registro Sanitario],
        ISNULL(i.CUM, '') AS CUM, 
        ISNULL(i.[Codigo Clasificacion], '') AS [Codigo Clasificacion], 
        ISNULL(i.Clasificacion, '') AS Clasificacion, 
        ISNULL(i.condi, '') AS condi,
        ISNULL(i.cadena, '') AS cadena,
        ISNULL(i.condiciones_de_almacenamiento, '') AS condiciones_de_almacenamiento,
        ISNULL(i.[Cantidad Mov], 0) AS [Cantidad Mov], 
        ISNULL(i.cant_soli, 0) AS cant_soli,
        ISNULL(i.pac, '') AS pac,
        ISNULL(i.muestra, 0) AS muestra,
        ISNULL(i.defecto, '') AS defecto,
        ISNULL(i.Observacion_usu, '') AS Observacion_usu, 
        ISNULL(i.elaboracion, '') AS elaboracion,
        e.NomYApellCmp AS ElaboracionNombre, 
        ISNULL(i.aprobacion, '') AS aprobacion,
        a.NomYApellCmp AS AprobacionNombre,
        ISNULL(i.validado, '') AS validado
    FROM insumos i
    LEFT JOIN firma_usuarios e ON i.elaboracion = e.Identificacion
    LEFT JOIN firma_usuarios a ON i.aprobacion = a.Identificacion
    WHERE 
        i.[No. Movimiento] LIKE ?  -- Búsqueda parcial por No. Movimiento
        AND i.[Tipo Movimiento] = ?  -- Filtro por tipo de movimiento
    ORDER BY i.[Fecha Movimiento] ASC
";

// Ejecutar la consulta
$params = array("%$searchQuery%", $tipoMovimiento); // Parámetros para búsqueda de No. Movimiento y Tipo Movimiento
$stmt = sqlsrv_query($conn, $query, $params);

if ($stmt === false) {
    echo json_encode(["status" => "error", "message" => "Error al ejecutar la consulta"]);
    sqlsrv_close($conn);
    exit;
}

$insumos = [];
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    // Convertir fechas a un formato compatible
    if ($row['Fecha Movimiento'] instanceof DateTime) {
        $row['Fecha Movimiento'] = $row['Fecha Movimiento']->format('Y-m-d H:i:s');
    }
    if ($row['Fecha Vencimiento'] instanceof DateTime) {
        $row['Fecha Vencimiento'] = $row['Fecha Vencimiento']->format('Y-m-d H:i:s');
    }

    // Agregar a la lista de resultados
    $insumos[] = $row;
}

// Cerrar conexión
sqlsrv_close($conn);

// Enviar respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode([
    "status" => "success", 
    "data" => $insumos,
    "searchQuery" => $searchQuery,
    "tipoMovimiento" => $tipoMovimiento
], JSON_NUMERIC_CHECK);
?>
