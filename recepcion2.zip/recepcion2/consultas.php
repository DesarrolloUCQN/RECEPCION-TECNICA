<?php
// Establecer la conexión con la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array("Database" => "recep_tec", "UID" => "sadumesm", "PWD" => "Dumes100%", "characterset" => "UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
}

// Obtener parámetros de búsqueda
$movimiento = isset($_GET['movimiento']) ? $_GET['movimiento'] : '';
$factura = isset($_GET['factura']) ? $_GET['factura'] : '';
$tipoMovimiento = isset($_GET['tipoMovimiento']) ? $_GET['tipoMovimiento'] : '';
$fechaDesde = isset($_GET['fechaDesde']) ? $_GET['fechaDesde'] : '';
$fechaHasta = isset($_GET['fechaHasta']) ? $_GET['fechaHasta'] : '';

// Obtener datos solo si hay filtros
$insumos = array();

// Construir la consulta base
$query = "SELECT 
    [ID],
    [No. Orden], 
    Proveedor, 
    [No. Movimiento], 
    [Tipo Movimiento], 
    [Fecha Movimiento], 
    [Tipo Documento], 
    [No. Documento soporte], 
    [Cod. Producto], 
    [Producto_Comercial], 
    [Forma Farmaceutica], 
    Presentacion, 
    Fabricante, 
    Lote, 
    [Fecha Vencimiento], 
    Valor, 
    [Registro Sanitario], 
    [Vigencia registro Sanitario], 
    CUM, 
    [Codigo Clasificacion], 
    Clasificacion, 
    condi,
    cadena,
    mce,
    [Cantidad Mov], 
    cant_soli,
    pac,
    muestra,
    defecto,
    Observacion_usu, 
    elaboracion,
    aprobacion,
    validado,
    Usuario 
FROM insumos 
WHERE 1=1"; // Condición siempre verdadera para facilitar la concatenación

// Añadir condiciones según los filtros
$params = array();
$hasFilters = false; // Bandera para saber si hay filtros aplicados

if (!empty($movimiento)) {
    $query .= " AND [No. Movimiento] = ?";
    $params[] = $movimiento;
    $hasFilters = true;
}

if (!empty($factura)) {
    $query .= " AND [No. Documento soporte] = ?";
    $params[] = $factura;
    $hasFilters = true;
}

if (!empty($tipoMovimiento)) {
    $query .= " AND [Tipo Movimiento] = ?";
    $params[] = $tipoMovimiento;
    $hasFilters = true;
}

if (!empty($fechaDesde)) {
    // Formato más seguro para fechas
    $query .= " AND [Fecha Vencimiento] >= CONVERT(DATETIME, ?, 120)";
    $params[] = $fechaDesde;
    $hasFilters = true;
}

if (!empty($fechaHasta)) {
    // Incluir todo el día hasta la última hora
    $query .= " AND [Fecha Vencimiento] <= CONVERT(DATETIME, ?, 120)";
    $params[] = $fechaHasta . ' 23:59:59';
    $hasFilters = true;
}

// Solo ejecutar la consulta si hay algún filtro
if ($hasFilters) {
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        // Reemplazar NULL por 0 en campos numéricos
        $row['Cantidad Mov'] = $row['Cantidad Mov'] ?? 0;
        $row['Valor'] = $row['Valor'] ?? 0;

        // Formatear fechas para evitar errores
        if ($row['Fecha Movimiento'] instanceof DateTime) {
            $row['Fecha Movimiento'] = $row['Fecha Movimiento']->format('Y-m-d H:i:s');
        }
        if ($row['Fecha Vencimiento'] instanceof DateTime) {
            $row['Fecha Vencimiento'] = $row['Fecha Vencimiento']->format('Y-m-d');
        }

        // Agregar el resto de los campos, asegurando que se manejen los NULL
        $insumos[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generación Excel - Sistema de Gestión</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.2.1/css/fixedHeader.dataTables.min.css">
    
    <!-- FontAwesome para iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <!-- Animate.css para animaciones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/fixedheader/3.2.1/js/dataTables.fixedHeader.min.js"></script>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- XLSX -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.4/xlsx.full.min.js"></script>
    
    <link rel="shortcut icon" href="img/icono.ico" type="image/x-icon">

    <style>
        :root {
            --primary-color: #007BFF;
            --success-color: #218838;
            --info-color: #138496;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
        }

        body {
            background: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding-top: 1rem;
            margin: 0;
            padding: 0;
        }

        .container-fluid {
            padding: 10px;
        }

        /* Loader Styles */
        .loader-wrapper {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: white;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            z-index: 9999;
        }

        .svg-container {
            display: flex;
            gap: 60px;
            align-items: center;
        }

        .loader-wrapper svg polyline,
        .loader-wrapper svg path {
            fill: none;
            stroke-width: 4;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        /* SVG RAYO */
        svg polyline#back {
            stroke: #ff4d5033;
        }

        svg polyline#front {
            stroke: #ff4d4f;
            stroke-dasharray: 300;
            stroke-dashoffset: 300;
            animation: dashAnim 2s linear infinite;
        }

        /* CORAZÓN */
        svg path#back-heart {
            stroke: #00b89433;
        }

        svg path#front-heart {
            stroke: #00b894;
            stroke-dasharray: 300;
            stroke-dashoffset: 300;
            animation: dashAnim 2s linear infinite;
        }

        /* Animación sincronizada */
        @keyframes dashAnim {
            70% {
                opacity: 0.2;
            }
            to {
                stroke-dashoffset: 0;
            }
        }

        /* Page Header */
        .page-header {
            background: var(--primary-color);
            color: white;
            padding: 1.5rem 0;
            margin-bottom: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.2);
            position: relative;
        }

        .page-header h1 {
            font-weight: 600;
            font-size: 2rem;
            margin: 0;
        }

        .page-header .subtitle {
            font-size: 1rem;
            opacity: 0.9;
            margin-top: 0.5rem;
        }

        /* Search Section */
        .search-section {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            border-left: 4px solid var(--success-color);
        }

        .search-section h4 {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }

        /* Form Controls */
        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            background: white;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.15);
            background: white;
        }

        .form-label {
            color: var(--dark-color);
            font-weight: 600;
            margin-bottom: 0.75rem;
        }

        /* Action Buttons Container */
        .action-buttons-container {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            border-left: 4px solid var(--warning-color);
        }

        .action-buttons-container h5 {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 1rem;
            font-size: 1.1rem;
        }

        /* Custom Buttons - Inspired by vista.css */
        .btn-custom {
            border-radius: 25px;
            padding: 8px 16px;
            font-weight: bold;
            transition: all 0.3s ease;
            border: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-transform: none;
            letter-spacing: normal;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
        }

        .btn-custom:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .btn-primary-custom {
            background-color: #007bff;
            color: white;
        }

        .btn-primary-custom:hover {
            background-color: #0056b3;
            box-shadow: 0 6px 12px rgba(0, 123, 255, 0.3);
        }

        .btn-success-custom {
            background-color: #28a745;
            color: white;
        }

        .btn-success-custom:hover {
            background-color: #218838;
            box-shadow: 0 6px 12px rgba(40, 167, 69, 0.3);
        }

        .btn-warning-custom {
            background-color: #ffc107;
            color: #212529;
        }

        .btn-warning-custom:hover {
            background-color: #e0a800;
            box-shadow: 0 6px 12px rgba(255, 193, 7, 0.3);
        }

        .btn-danger-custom {
            background-color: #dc3545;
            color: white;
        }

        .btn-danger-custom:hover {
            background-color: #c82333;
            box-shadow: 0 6px 12px rgba(220, 53, 69, 0.3);
        }

        /* Icon spacing in buttons */
        .btn-custom .fas {
            margin-right: 8px;
        }

        /* Search Filters Layout */
        .search-filters {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: end;
            margin-bottom: 20px;
        }

        .search-filters input[type="text"],
        .search-filters input[type="date"],
        .search-filters select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            background: white;
            flex: 1;
            min-width: 200px;
        }

        .search-filters input:focus,
        .search-filters select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.15);
        }

        .filtros-fecha {
            display: flex;
            flex-direction: column;
            gap: 10px;
            min-width: 200px;
        }

        .filtro-fecha {
            display: flex;
            flex-direction: column;
        }

        .filtro-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 5px;
            font-size: 0.9rem;
        }

        .filtro-input {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 10px 12px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .filtro-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.15);
        }

        /* Table Container */
        .table-container {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--info-color);
        }

        /* Table Styles */
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.05);
            max-height: 500px;
            overflow-y: auto;
            overflow-x: auto;
            width: 100%;
        }

        .table {
            margin-bottom: 0;
            font-size: 0.9rem;
            min-width: 100%;
            white-space: nowrap;
        }

        .table thead th {
            background: var(--primary-color);
            color: white;
            border: none;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.75rem;
            font-size: 0.8rem;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .table tbody tr {
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background-color: rgba(0, 123, 255, 0.05);
        }

        .table tbody td {
            padding: 0.75rem;
            vertical-align: middle;
            border-color: #e9ecef;
            white-space: nowrap;
        }

        /* Contenedor del botón Regresar */
        .regresar-container {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--danger-color);
            text-align: center;
        }

        /* Animation Classes */
        .fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Tooltip Styles */
        [data-tooltip] {
            position: relative;
        }

        [data-tooltip]:hover::after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.8rem;
            white-space: nowrap;
            z-index: 1000;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .page-header h1 {
                font-size: 1.75rem;
            }
            
            .search-section,
            .action-buttons-container,
            .table-container,
            .regresar-container {
                padding: 1rem;
            }

            .search-filters {
                flex-direction: column;
            }

            .search-filters input,
            .search-filters select {
                min-width: 100%;
            }

            .filtros-fecha {
                min-width: 100%;
            }
        }
    </style>
</head>

<body class="container-fluid" id="contenidocompleto">
    <!-- Loader con SVGs -->
    <div class="loader-wrapper" id="loader">
        <div class="svg-container">
            <!-- SVG tipo rayo -->
            <svg width="120px" height="90px">
                <polyline points="0.157 44.954, 26 44.954, 41.843 90, 80 0, 92 44, 120 44" id="back"></polyline>
                <polyline points="0.157 44.954, 26 44.954, 41.843 90, 80 0, 92 44, 120 44" id="front"></polyline>
            </svg>

            <!-- SVG de corazón -->
            <svg width="120px" height="90px">
                <path id="back-heart" d="M60 80s-24-20-36-36C12 28 20 10 40 10c8 0 20 10 20 10s12-10 20-10c20 0 28 18 16 34-12 16-36 36-36 36z"></path>
                <path id="front-heart" d="M60 80s-24-20-36-36C12 28 20 10 40 10c8 0 20 10 20 10s12-10 20-10c20 0 28 18 16 34-12 16-36 36-36 36z"></path>
            </svg>
        </div>
    </div>

    <div class="container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header text-center fade-in-up">
            <div class="container">
                <div class="d-flex align-items-center justify-content-center">
                    <img src="img/icono.ico" alt="Icono" style="position: absolute;right: 94%;top: 25px;width: 4%;">
                    <div>
                        <h1 class="mb-0"><i class="fas fa-file-excel me-3"></i>Generación Excel</h1>
                        <p class="subtitle mb-0">Consulta y exportación de datos de insumos</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search Section -->
        <div class="search-section fade-in-up" style="animation-delay: 0.2s">
            <h4><i class="fas fa-search me-2"></i>Filtros de Búsqueda</h4>
            
            <!-- Filtros con botón de buscar en la misma fila -->
            <div class="row g-2 mb-3">
                <div class="col-md-2">
                    <label class="form-label"><i class="fas fa-hashtag me-1"></i>No. Movimiento:</label>
                    <input type="text" id="searchMovimiento" class="form-control form-control-sm" placeholder="No. Movimiento">
                </div>

                <div class="col-md-2">
                    <label class="form-label"><i class="fas fa-filter me-1"></i>Tipo de Movimiento:</label>
                    <select id="searchTipoMovimiento" class="form-select form-select-sm">
                        <option value="" selected>Seleccionar tipo</option>
                        <option value="Compra Directa">Compra Directa</option>
                        <option value="Remisión">Remisión</option>
                        <option value="Ingreso por Préstamo de Otra Institución">Ingreso por Préstamo</option>
                        <option value="Ingreso por Aprovechamiento">Ingreso por Aprovechamiento</option>
                        <option value="Ingreso Devolución Préstamo">Devolución Préstamo</option>
                        <option value="Compra por Orden">Compra por Orden</option>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label"><i class="fas fa-file-invoice me-1"></i>No. Factura:</label>
                    <input type="text" id="searchfactura" class="form-control form-control-sm" placeholder="No. Factura">
                </div>

                <div class="col-md-2">
                    <label class="form-label"><i class="fas fa-calendar-alt me-1"></i>Fecha Desde:</label>
                    <input type="date" id="searchFechaDesde" class="form-control form-control-sm">
                </div>

                <div class="col-md-2">
                    <label class="form-label"><i class="fas fa-calendar-alt me-1"></i>Fecha Hasta:</label>
                    <input type="date" id="searchFechaHasta" class="form-control form-control-sm">
                </div>

                <!-- Botón Buscar al lado de los filtros -->
                <div class="col-md-2 d-flex align-items-end">
                    <button id="searchButton" class="btn btn-custom btn-primary-custom btn-sm w-100">
                        <i class="fas fa-search me-1"></i>Buscar
                    </button>
                </div>
            </div>

            <!-- Segunda fila con botones Excel y Limpiar abajo a la izquierda -->
            <div class="row">
                <div class="col-md-6">
                    <div class="d-flex gap-2">
                        <button id="generateExcel" class="btn btn-custom btn-success-custom btn-sm" data-tooltip="Generar Excel">
                            <i class="fas fa-file-excel me-1"></i>Excel
                        </button>

                        <button id="limpiarFiltros" class="btn btn-custom btn-warning-custom btn-sm" data-tooltip="Limpiar Filtros">
                            <i class="fas fa-broom me-1"></i>Limpiar
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Table Container -->
        <div class="table-container fade-in-up" style="animation-delay: 0.3s">
            <h4><i class="fas fa-table me-2"></i>Resultados de Consulta</h4>
            <div class="table-responsive">
                <table id="insumosTable" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>No. Orden</th>
                            <th>Proveedor</th>
                            <th>No. Movimiento</th>
                            <th>Tipo Movimiento</th>
                            <th>Fecha Movimiento</th>
                            <th>Tipo Documento</th>
                            <th>No. Documento Soporte</th>
                            <th>Cod. Producto</th>
                            <th>Producto Comercial</th>
                            <th>Forma Farmacéutica</th>
                            <th>Presentación</th>
                            <th>Fabricante</th>
                            <th>Lote</th>
                            <th>Fecha Vencimiento</th>
                            <th>Valor</th>
                            <th>Registro Sanitario</th>
                            <th>Vigencia Registro Sanitario</th>
                            <th>CUM</th>
                            <th>Código Clasificación</th>
                            <th>Clasificación</th>
                            <th>Condición</th>
                            <th>Cadena de Frío</th>
                            <th>MCE</th>
                            <th>Cantidad Recibida</th>
                            <th>Cantidad Solicitada</th>
                            <th>Precio Pactado en OC</th>
                            <th>Tamaño Muestra</th>
                            <th>Defecto</th>
                            <th>Observación</th>
                            <th>Usuario Elabora</th>
                            <th>Usuario Aprobación</th>
                            <th>Validación</th>
                            <th>Usuario</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($insumos as $movimiento): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($movimiento['ID']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['No. Orden']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Proveedor']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['No. Movimiento']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Tipo Movimiento']); ?></td>
                                <td><?php echo htmlspecialchars((new DateTime($movimiento['Fecha Movimiento']))->format('Y-m-d H:i:s')); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Tipo Documento']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['No. Documento soporte']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Cod. Producto']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Producto_Comercial']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Forma Farmaceutica']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Presentacion']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Fabricante']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Lote']); ?></td>
                                <td><?php echo htmlspecialchars(!empty($movimiento['Fecha Vencimiento']) ? (new DateTime($movimiento['Fecha Vencimiento']))->format('Y-m-d') : ''); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Valor']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Registro Sanitario']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Vigencia registro Sanitario']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['CUM']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Codigo Clasificacion']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Clasificacion']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['condi']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['cadena']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['mce']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Cantidad Mov']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['cant_soli']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['pac']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['muestra']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['defecto']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Observacion_usu']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['elaboracion']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['aprobacion']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['validado']); ?></td>
                                <td><?php echo htmlspecialchars($movimiento['Usuario']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Contenedor del botón Regresar -->
        
            <a href="index.php" class="btn btn-custom btn-danger-custom">
                <i class="fas fa-home me-2"></i>Regresar al Menú Principal
            </a>
        
    </div>

    <script>
        window.addEventListener('load', function () {
            const loader = document.getElementById('loader');
            const contenido = document.getElementById('contenidocompleto');

            // Espera opcional de 1.5s (puedes ajustar si quieres un efecto más suave)
            setTimeout(() => {
                loader.style.display = 'none';
                contenido.style.display = 'block';
            }, 1500);
        });

        $(document).ready(function () {
            // Inicializar DataTable vacío
            const table = $('#insumosTable').DataTable({
                "paging": true,
                "searching": true,
                "ordering": true,
                "scrollY": "400px",
                "scrollX": true,
                "scrollCollapse": true,
                "autoWidth": false,
                "fixedHeader": true,
                "language": {
                    "search": "Buscar:",
                    "lengthMenu": "Mostrar _MENU_ registros por página",
                    "zeroRecords": "No se encontraron resultados",
                    "info": "Mostrando página _PAGE_ de _PAGES_",
                    "infoEmpty": "No hay registros disponibles",
                    "infoFiltered": "(filtrado de _MAX_ registros totales)",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
            });

            $('#searchButton').on('click', function () {
                // Obtener valores de los campos de búsqueda
                const movimiento = $('#searchMovimiento').val().trim();
                const factura = $('#searchfactura').val().trim();
                const tipoMovimiento = $('#searchTipoMovimiento').val();
                const fechaDesde = $('#searchFechaDesde').val();
                const fechaHasta = $('#searchFechaHasta').val();

                // Construir URL con parámetros
                let urlParams = new URLSearchParams();
                if (movimiento) urlParams.append('movimiento', movimiento);
                if (factura) urlParams.append('factura', factura);
                if (tipoMovimiento) urlParams.append('tipoMovimiento', tipoMovimiento);
                if (fechaDesde) urlParams.append('fechaDesde', fechaDesde);
                if (fechaHasta) urlParams.append('fechaHasta', fechaHasta);

                // Hacer petición AJAX para obtener datos filtrados
                $.ajax({
                    url: window.location.pathname + '?' + urlParams.toString(),
                    type: 'GET',
                    dataType: 'html',
                    success: function (data) {
                        // Parsear el HTML para extraer los datos
                        let $response = $(data);
                        let nuevosDatos = [];

                        $response.find('#insumosTable tbody tr').each(function () {
                            let rowData = [];
                            $(this).find('td').each(function () {
                                rowData.push($(this).text());
                            });
                            nuevosDatos.push(rowData);
                        });

                        // Limpiar y actualizar la tabla
                        table.clear().rows.add(nuevosDatos).draw();

                        if (nuevosDatos.length === 0) {
                            Swal.fire({
                                icon: 'info',
                                title: 'Sin resultados',
                                text: 'No se encontraron resultados para los criterios de búsqueda.',
                                confirmButtonColor: '#007BFF'
                            });
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Búsqueda completada',
                                text: `Se encontraron ${nuevosDatos.length} registro(s).`,
                                confirmButtonColor: '#007BFF',
                                timer: 2000,
                                showConfirmButton: false
                            });
                        }
                    },
                    error: function () {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Error al realizar la búsqueda.',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                });
            });

            // Función para generar Excel
            $('#generateExcel').on('click', function () {
                // Obtener valores de los campos de búsqueda
                const movimiento = $('#searchMovimiento').val().trim();
                const factura = $('#searchfactura').val().trim();
                const tipoMovimiento = $('#searchTipoMovimiento').val();
                const fechaDesde = $('#searchFechaDesde').val();
                const fechaHasta = $('#searchFechaHasta').val();

                // Verificar si no se ha aplicado ningún filtro
                if (!movimiento && !factura && !tipoMovimiento && !fechaDesde && !fechaHasta) {
                    Swal.fire({
                        title: '¿Está seguro?',
                        text: "¿Desea generar un Excel con toda la base de datos?",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#007BFF',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: 'Sí, generar',
                        cancelButtonText: 'Cancelar'
                    }).then((result) => {
                        if (!result.isConfirmed) return;
                        generarExcel(movimiento, factura, tipoMovimiento, fechaDesde, fechaHasta);
                    });
                } else {
                    generarExcel(movimiento, factura, tipoMovimiento, fechaDesde, fechaHasta);
                }
            });

            function generarExcel(movimiento, factura, tipoMovimiento, fechaDesde, fechaHasta) {
                // Obtener la fecha actual en formato YYYY-MM-DD
                const fechaActual = new Date().toISOString().split('T')[0];

                // Determinar el nombre del archivo según el tipo de búsqueda
                let nombreArchivo;
                if (movimiento) {
                    nombreArchivo = `Consulta_NumMovimiento_${movimiento}_${fechaActual}.xlsx`;
                } else if (factura) {
                    nombreArchivo = `Consulta_NumFactura_${factura}_${fechaActual}.xlsx`;
                } else if (tipoMovimiento) {
                    nombreArchivo = `Consulta_TipoMovimiento_${tipoMovimiento.replace(/ /g, '_')}_${fechaActual}.xlsx`;
                } else if (fechaDesde || fechaHasta) {
                    nombreArchivo = `Consulta_Fechas_${fechaDesde || ''}_${fechaHasta || ''}_${fechaActual}.xlsx`;
                } else {
                    nombreArchivo = `Consulta_Completa_${fechaActual}.xlsx`;
                }

                // Obtener los datos filtrados de la tabla
                const datosFiltrados = table.rows({ search: 'applied' }).data().toArray();

                // Crear un array con los encabezados de la tabla
                const encabezados = [
                    "ID", "No. Orden", "Proveedor", "No. Movimiento", "Tipo Movimiento", "Fecha Movimiento",
                    "Tipo Documento", "No. Documento soporte", "Cod. Producto", "Producto_Comercial", 
                    "Forma Farmaceutica", "Presentacion", "Fabricante", "Lote", "Fecha Vencimiento", "Valor",
                    "Registro Sanitario", "Vigencia registro Sanitario", "CUM", "Codigo Clasificacion", 
                    "Clasificacion", "condi", "cadena", "mce", "Cantidad Mov", "cant_soli", "pac", 
                    "muestra", "defecto", "Observacion_usu", "elaboracion", "aprobacion", "validado", "Usuario"
                ];

                // Crear un array con los datos de la tabla, reemplazando valores vacíos con "null"
                const datosExcel = datosFiltrados.map(row => 
                    row.map(cell => cell !== undefined && cell !== "" ? cell : "null")
                );

                // Crear un libro de Excel
                const workbook = XLSX.utils.book_new();
                const worksheet = XLSX.utils.aoa_to_sheet([encabezados, ...datosExcel]);

                // Ajustar el ancho de las columnas automáticamente
                const columnWidths = encabezados.map((header, index) => {
                    const maxLength = Math.max(
                        header.length,
                        ...datosExcel.map(row => String(row[index]).length)
                    );
                    return { wch: maxLength + 2 };
                });

                worksheet['!cols'] = columnWidths;

                // Agregar la hoja al libro
                XLSX.utils.book_append_sheet(workbook, worksheet, "Insumos");

                // Generar el archivo Excel
                XLSX.writeFile(workbook, nombreArchivo);

                // Mostrar mensaje de éxito
                Swal.fire({
                    icon: 'success',
                    title: 'Excel generado',
                    text: `Archivo ${nombreArchivo} descargado correctamente.`,
                    confirmButtonColor: '#218838',
                    timer: 3000,
                    showConfirmButton: false
                });
            }

            // Función para limpiar filtros
            $('#limpiarFiltros').on('click', function() {
                // Limpiar los valores de los inputs
                $('#searchMovimiento').val('');
                $('#searchfactura').val('');
                $('#searchTipoMovimiento').val('');
                $('#searchFechaDesde').val('');
                $('#searchFechaHasta').val('');

                // Limpiar la tabla
                table.clear().draw();

                // Mostrar mensaje de confirmación
                Swal.fire({
                    icon: 'success',
                    title: 'Filtros limpiados',
                    text: 'Todos los filtros han sido limpiados correctamente.',
                    confirmButtonColor: '#ffc107',
                    timer: 2000,
                    showConfirmButton: false
                });
            });

            // Buscadores organizados de la tabla por defecto
            var table2 = $('#miTabla').DataTable({
                dom: '<"top"l<"clear">f>rt<"bottom"ip><"clear">', // Organiza los elementos
                lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]], // Opciones de "Mostrar X registros"
                pageLength: 25, // Número de registros por página por defecto
                language: {
                    search: "Buscar:", // Personaliza el texto del buscador
                    lengthMenu: "Mostrar _MENU_ registros por página", // Personaliza el texto del menú de longitud
                    info: "Mostrando _START_ a _END_ de _TOTAL_ registros", // Personaliza la información de paginación
                    paginate: {
                        first: "Primero",
                        last: "Último",
                        next: "Siguiente",
                        previous: "Anterior"
                    }
                }
            });

            // Búsqueda con tipo movimiento
            $('#searchButton').on('click', function () {
                // Obtener valores de los campos de búsqueda
                const movimiento = $('#searchMovimiento').val().trim();
                const factura = $('#searchfactura').val().trim();
                const tipoMovimiento = $('#searchTipoMovimiento').val(); // Esto será "" si no se seleccionó nada
                const fechaDesde = $('#searchFechaDesde').val();
                const fechaHasta = $('#searchFechaHasta').val();

                // Construir URL con parámetros (solo agregar tipoMovimiento si tiene valor)
                let urlParams = new URLSearchParams();
                if (movimiento) urlParams.append('movimiento', movimiento);
                if (factura) urlParams.append('factura', factura);
                if (tipoMovimiento) urlParams.append('tipoMovimiento', tipoMovimiento); // Solo si se seleccionó algo
                if (fechaDesde) urlParams.append('fechaDesde', fechaDesde);
                if (fechaHasta) urlParams.append('fechaHasta', fechaHasta);

                // Resto del código AJAX ya está implementado arriba
            });

            // Limpiar filtros alternativo
            document.getElementById('limpiarFiltros')?.addEventListener('click', () => {
                // Limpiar los valores de los inputs (si existen)
                ['searchMovimiento', 'searchfactura', 'searchTipoMovimiento', 'searchFechaDesde', 'searchFechaHasta'].forEach(id => {
                    const input = document.getElementById(id);
                    if (input) input.value = '';
                });

                // Recargar la página
                // location.reload();
            });
        });
    </script>

</body>

</html> 