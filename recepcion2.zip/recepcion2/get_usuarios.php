<?php
// Configurar el tipo de contenido como JSON
header('Content-Type: application/json; charset=utf-8');

// Deshabilitar el reporte de errores para evitar que aparezcan en el JSON
error_reporting(0);
ini_set('display_errors', 0);

try {
    // Conexión a la base de datos
    $serverName = "PA-S1-DATA\\UCQNDATA";
    $connectionInfo = array(
        "Database" => "recep_tec", 
        "UID" => "sadumesm", 
        "PWD" => "Dumes100%", 
        "characterset" => "UTF-8"
    );
    
    $conn = sqlsrv_connect($serverName, $connectionInfo);

    if (!$conn) {
        throw new Exception("Error de conexión a la base de datos");
    }

    // Obtener parámetros de DataTables
    $draw = intval($_POST['draw'] ?? 1);
    $start = intval($_POST['start'] ?? 0);
    $length = intval($_POST['length'] ?? 25);
    $searchValue = $_POST['search']['value'] ?? '';
    $identificacionFilter = $_POST['identificacion'] ?? '';

    // Construir consulta base
    $whereClause = "WHERE 1=1";
    $params = array();
    
    // Filtro por identificación exacta
    if (!empty($identificacionFilter) && is_numeric($identificacionFilter)) {
        $whereClause .= " AND Identificacion = ?";
        $params[] = $identificacionFilter;
    }
    
    // Búsqueda global en DataTables
    if (!empty($searchValue)) {
        $whereClause .= " AND (NomYApellCmp LIKE ? OR Identificacion LIKE ?)";
        $params[] = "%$searchValue%";
        $params[] = "%$searchValue%";
    }

    // Contar total de registros sin filtros
    $queryTotal = "SELECT COUNT(*) as total FROM firma_usuarios";
    $stmtTotal = sqlsrv_query($conn, $queryTotal);
    $rowTotal = sqlsrv_fetch_array($stmtTotal, SQLSRV_FETCH_ASSOC);
    $recordsTotal = $rowTotal['total'] ?? 0;

    // Contar registros filtrados
    $queryFiltered = "SELECT COUNT(*) as total FROM firma_usuarios $whereClause";
    $stmtFiltered = sqlsrv_query($conn, $queryFiltered, $params);
    $rowFiltered = sqlsrv_fetch_array($stmtFiltered, SQLSRV_FETCH_ASSOC);
    $recordsFiltered = $rowFiltered['total'] ?? 0;

    // Obtener datos con paginación
    $orderColumn = $_POST['order'][0]['column'] ?? 3; // Default: FechaRegistro
    $orderDir = $_POST['order'][0]['dir'] ?? 'desc';
    
    // Mapear columnas
    $columns = ['NomYApellCmp', 'Identificacion', 'RutaImagen', 'FechaRegistro'];
    $orderByColumn = $columns[$orderColumn] ?? 'FechaRegistro';
    
    $queryData = "SELECT NomYApellCmp, Identificacion, RutaImagen, FechaRegistro 
                  FROM firma_usuarios 
                  $whereClause 
                  ORDER BY $orderByColumn $orderDir 
                  OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
    
    $paramsData = array_merge($params, [$start, $length]);
    $stmtData = sqlsrv_query($conn, $queryData, $paramsData);

    if (!$stmtData) {
        throw new Exception("Error al consultar datos de usuarios");
    }

    $data = array();
    while ($row = sqlsrv_fetch_array($stmtData, SQLSRV_FETCH_ASSOC)) {
        // Formatear fecha
        $fechaRegistro = '';
        if ($row['FechaRegistro'] && is_object($row['FechaRegistro'])) {
            $fechaRegistro = $row['FechaRegistro']->format('d/m/Y H:i:s');
        }

        $data[] = array(
            'NomYApellCmp' => $row['NomYApellCmp'] ?? '',
            'Identificacion' => $row['Identificacion'] ?? '',
            'RutaImagen' => $row['RutaImagen'] ?? '',
            'FechaRegistro' => $fechaRegistro
        );
    }

    // Cerrar conexión
    sqlsrv_close($conn);

    // Respuesta para DataTables
    $response = array(
        "draw" => $draw,
        "recordsTotal" => intval($recordsTotal),
        "recordsFiltered" => intval($recordsFiltered),
        "data" => $data
    );

    echo json_encode($response);

} catch (Exception $e) {
    // En caso de error, devolver respuesta de error para DataTables
    $response = array(
        "draw" => intval($_POST['draw'] ?? 1),
        "recordsTotal" => 0,
        "recordsFiltered" => 0,
        "data" => array(),
        "error" => $e->getMessage()
    );
    
    echo json_encode($response);
}
?>