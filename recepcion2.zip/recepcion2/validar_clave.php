<?php
// Conexión a la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array(
    "Database" => "recep_tec",
    "UID" => "sadumesm",
    "PWD" => "Dumes100%",
    "CharacterSet" => "UTF-8"
);

$conn = sqlsrv_connect($serverName, $connectionInfo);

// Verificar si la conexión fue exitosa
if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
}

// Validar las claves
if (isset($_POST['cedula_elabora'], $_POST['clave_elabora'], $_POST['cedula_aprueba'], $_POST['clave_aprueba'])) {
    $cedulaElabora = $_POST['cedula_elabora'];
    $claveElabora = $_POST['clave_elabora'];
    $cedulaAprueba = $_POST['cedula_aprueba'];
    $claveAprueba = $_POST['clave_aprueba'];

    // Consulta SQL para verificar la clave de quien elabora
    $sqlElabora = "SELECT clave, ruta_imagen FROM firma_usuarios WHERE Identificacion = ?";
    $stmtElabora = sqlsrv_prepare($conn, $sqlElabora, array(&$cedulaElabora));

    if (sqlsrv_execute($stmtElabora)) {
        if (sqlsrv_has_rows($stmtElabora)) {
            $rowElabora = sqlsrv_fetch_array($stmtElabora, SQLSRV_FETCH_ASSOC);
            if ($rowElabora['clave'] != $claveElabora) {
                echo json_encode(array("success" => false, "error" => "Clave de Elabora incorrecta"));
                exit;
            }

            // Si la cédula y la clave son correctas, obtenemos la ruta de la imagen
            $rutaImagenElabora = $rowElabora['ruta_imagen'];
        } else {
            echo json_encode(array("success" => false, "error" => "Cédula de Elabora no encontrada"));
            exit;
        }
    } else {
        echo json_encode(array("success" => false, "error" => "Error al ejecutar la consulta para Elabora"));
        exit;
    }

    // Consulta SQL para verificar la clave de quien aprueba
    $sqlAprueba = "SELECT clave FROM firma_usuarios WHERE Identificacion = ?";
    $stmtAprueba = sqlsrv_prepare($conn, $sqlAprueba, array(&$cedulaAprueba));

    if (sqlsrv_execute($stmtAprueba)) {
        if (sqlsrv_has_rows($stmtAprueba)) {
            $rowAprueba = sqlsrv_fetch_array($stmtAprueba, SQLSRV_FETCH_ASSOC);
            if ($rowAprueba['clave'] != $claveAprueba) {
                echo json_encode(array("success" => false, "error" => "Clave de Aprueba incorrecta"));
                exit;
            }
        } else {
            echo json_encode(array("success" => false, "error" => "Cédula de Aprueba no encontrada"));
            exit;
        }
    } else {
        echo json_encode(array("success" => false, "error" => "Error al ejecutar la consulta para Aprueba"));
        exit;
    }

    // Responder con los datos de éxito y la ruta de la imagen
    echo json_encode(array(
        "success" => true,
        "ruta_imagen" => $rutaImagenElabora // Incluir la ruta de la imagen en la respuesta
    ));
} else {
    echo json_encode(array("success" => false, "error" => "Cédula y clave no proporcionada"));
}
?>
