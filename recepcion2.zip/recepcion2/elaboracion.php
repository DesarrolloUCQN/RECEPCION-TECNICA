<?php
// Establecer la conexión con la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array("Database" => "recep_tec", "UID" => "sadumesm", "PWD" => "Dumes100%", "characterset" => "UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
}

// Función mejorada para validar y formatear fechas
// Función corregida para devolver objetos DateTime
function formatDateForSQL($dateString, $isDateTime = false)
{
    if (empty($dateString)) {
        return null;
    }

    try {
        if ($isDateTime) {
            $date = DateTime::createFromFormat('Y-m-d\TH:i', $dateString);
            if (!$date) {
                throw new Exception("Formato de fecha/hora inválido: $dateString");
            }
            return $date;  // Devuelve objeto DateTime
            // Dentro del try/catch, después de crear el objeto:

            if ($date === false) {
                throw new Exception("Fecha inválida: $dateString");
            }
        } else {
            return new DateTime($dateString);  // Devuelve objeto DateTime
        }
    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}

// Verificar si se ha enviado el número de movimiento y tipo de movimiento
if (isset($_GET['movimiento']) && isset($_GET['tipoMovimiento'])) {
    $noMovimiento = $_GET['movimiento'];
    $tipoMovimiento = $_GET['tipoMovimiento'];

    // Consulta para verificar los registros
    $query = "SELECT * FROM insumos WHERE [No. Movimiento] = ? AND [Tipo Movimiento] = ?";
    $params = array($noMovimiento, $tipoMovimiento);
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        die("Error al ejecutar la consulta: " . print_r(sqlsrv_errors(), true));
    }

    if (sqlsrv_has_rows($stmt)) {
        $allFieldsComplete = true;
        $missingData = [];

        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $missingFields = [];

            if (empty($row['condi'])) $missingFields[] = 'Condición de transporte';
            if (empty($row['cadena'])) $missingFields[] = 'Cadena de Frío';
            if (empty($row['cant_soli'])) $missingFields[] = 'Cantidad Solicitada';

            if (!empty($missingFields)) {
                $allFieldsComplete = false;
                $missingData[] = [
                    'Cod. Producto' => $row['Cod. Producto'],
                    'Producto Comercial' => $row['Producto_Comercial'],
                    'Campos Faltantes' => $missingFields
                ];
            }
        }

        if ($allFieldsComplete) {
            // Mostrar formulario con campos de fecha
            echo '<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificación de Movimiento</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="diseño/elaboracion2.css?<?php echo time(); ?>">
    
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header text-center">
                <h4>Verificación de Movimiento #' . $noMovimiento . '</h4>
            </div>
            <div class="card-body">
                <p class="text-center mb-4">Ingrese su cédula y clave para completar el proceso</p>
                <form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="POST">
                    <input type="hidden" name="NoMovimiento" value="' . $noMovimiento . '">
                    <input type="hidden" name="tipoMovimiento" value="' . $tipoMovimiento . '">
                    
                    <div class="form-group">
                        <label for="fecha_factura"><i class="fas fa-file-invoice"></i> Fecha de Factura:</label>
                        <input type="date" id="fecha_factura" name="fecha_factura" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="fecha_oc"><i class="fas fa-shopping-cart"></i> Fecha de Orden de Compra:</label>
                        <input type="date" id="fecha_oc" name="fecha_oc" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="fecha_re"><i class="fas fa-truck-loading"></i> Fecha de Recepción:</label>
                        <input type="date" id="fecha_re" name="fecha_re" class="form-control" required>
                    </div>
                    

                    <!--  aqui va fecha Movimiento que sera  fecha de recibido-->
                    <div class="form-group">
                        <label for="fecha_movimiento"><i class="fas fa-calendar-alt"></i> Fecha de Recibido:</label>
                        <input type="datetime-local" id="fecha_movimiento" name="fecha_movimiento" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="cedula"><i class="fas fa-id-card"></i> Cédula:</label>
                        <input type="text" id="cedula" name="cedula" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="clave"><i class="fas fa-lock"></i> Contraseña:</label>
                        <input type="password" id="clave" name="clave" class="form-control" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-check"></i> Registrar Cédula y Clave
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>';
        } else {
            // Mostrar datos faltantes
            echo '<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datos Faltantes</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link rel="stylesheet" href="diseño/elaboracion2.css?<?php echo time(); ?>">
    
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header text-center">
                <h4>Datos Faltantes para Movimiento #' . $noMovimiento . '</h4>
            </div>
            <div class="card-body">
                <div class="alert alert-warning">
                    <strong><i class="fas fa-exclamation-triangle"></i> Atención:</strong> Los siguientes campos están vacíos y deben completarse antes de continuar.
                </div>
                
                <table id="missingDataTable" class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Código Producto</th>
                            <th>Producto Comercial</th>
                            <th>Campos Faltantes</th>
                        </tr>
                    </thead>
                    <tbody>';

            $uniqueMissingData = [];
            foreach ($missingData as $data) {
                $key = $data['Cod. Producto'] . $data['Producto Comercial'];
                if (!isset($uniqueMissingData[$key])) {
                    $uniqueMissingData[$key] = $data;
                }
            }

            foreach ($uniqueMissingData as $data) {
                echo "<tr>
                        <td>{$data['Cod. Producto']}</td>
                        <td>{$data['Producto Comercial']}</td>
                        <td>";
                foreach ($data['Campos Faltantes'] as $field) {
                    echo "<div class='missing-field'><i class='fas fa-times-circle'></i> {$field}</div>";
                }
                echo "</td></tr>";
            }

            echo '</tbody>
                </table>
                
                <div class="text-center mt-4">
                    <a href="javascript:window.close();" class="btn btn-primary">
                        <i class="fas fa-times"></i> Cerrar Ventana
                    </a>
                </div>
            </div>
        </div>
    </div>
    <link rel="stylesheet" href="diseño/elaboracion2.css?<?php echo time(); ?>">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#missingDataTable").DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Spanish.json"
                }
            });
        });
    </script>
</body>
</html>';
        }
    } else {
        echo '<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="diseño/elaboracion2.css?<?php echo time(); ?>">
   
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header text-center">
                <h4>Movimiento No Encontrado</h4>
            </div>
            <div class="card-body text-center">
                <p>No se encontraron registros para el número de movimiento <strong>' . $noMovimiento . '</strong>.</p>
                <div class="mt-4">
                    <a href="javascript:window.close();" class="btn btn-primary">
                        <i class="fas fa-times"></i> Cerrar Ventana
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>';
    }
}
// Procesar formulario de credenciales
elseif (isset($_POST['cedula']) && isset($_POST['NoMovimiento']) && isset($_POST['clave']) && isset($_POST['tipoMovimiento'])) {
    // Obtener datos del formulario
    $cedula = trim($_POST['cedula']);
    $clave = trim($_POST['clave']);
    $noMovimiento = $_POST['NoMovimiento'];
    $tipoMovimiento = $_POST['tipoMovimiento'];

    // Validar fechas
    $requiredDates = ['fecha_factura', 'fecha_oc', 'fecha_re', 'fecha_movimiento'];
    foreach ($requiredDates as $dateField) {
        if (empty($_POST[$dateField])) {
            die("Error: El campo de fecha '$dateField' es requerido");
        }
    }

    // Formatear fechas para SQL Server
    $fecha_factura = formatDateForSQL($_POST['fecha_factura']);
    $fecha_oc = formatDateForSQL($_POST['fecha_oc']);
    $fecha_re = formatDateForSQL($_POST['fecha_re']);
    $fecha_movimiento = formatDateForSQL($_POST['fecha_movimiento'], true); // DateTime

    // Consulta para actualizar fechas
    $queryUpdateFechas = "UPDATE insumos SET 
                         fecha_factura = ?, 
                         fecha_oc = ?,
                         fecha_re = ?,
                         [Fecha Movimiento] = ?
                         WHERE [No. Movimiento] = ? AND [Tipo Movimiento] = ?";

    // Parámetros para la consulta
    $paramsUpdateFechas = array(
        $fecha_factura,
        $fecha_oc,
        $fecha_re,
        $fecha_movimiento,
        $noMovimiento,
        $tipoMovimiento
    );

    $stmtUpdateFechas = sqlsrv_query($conn, $queryUpdateFechas, $paramsUpdateFechas);

    // Manejo de errores con información detallada
    if ($stmtUpdateFechas === false) {
        $errors = sqlsrv_errors();
        $errorMessage = "Error al actualizar fechas:<br>";
        foreach ($errors as $error) {
            $errorMessage .= "SQLSTATE: " . $error['SQLSTATE'] . "<br>";
            $errorMessage .= "Código: " . $error['code'] . "<br>";
            $errorMessage .= "Mensaje: " . $error['message'] . "<br><br>";
        }

        $errorMessage .= "Valores enviados:<br>";
        $errorMessage .= "Fecha Factura: $fecha_factura<br>";
        $errorMessage .= "Fecha OC: $fecha_oc<br>";
        $errorMessage .= "Fecha Recepción: $fecha_re<br>";
        $errorMessage .= "Fecha Movimiento: $fecha_movimiento<br>";
        $errorMessage .= "No. Movimiento: $noMovimiento<br>";
        $errorMessage .= "Tipo Movimiento: $tipoMovimiento";

        die($errorMessage);
    }

    // Validar usuario
    $queryUser = "SELECT * FROM firma_usuarios WHERE Identificacion = ? AND clave = ?";
    $paramsUser = array($cedula, $clave);
    $stmtUser = sqlsrv_query($conn, $queryUser, $paramsUser);

    if ($stmtUser === false) {
        die("Error en consulta de usuario: " . print_r(sqlsrv_errors(), true));
    }

    if (sqlsrv_has_rows($stmtUser)) {
        // Actualizar elaboración
        $queryUpdateElab = "UPDATE insumos SET elaboracion = ? 
                    WHERE [No. Movimiento] = ? AND [Tipo Movimiento] = ?";
        $paramsUpdateElab = array($cedula, $noMovimiento, $tipoMovimiento);
        $stmtUpdateElab = sqlsrv_query($conn, $queryUpdateElab, $paramsUpdateElab);

        if ($stmtUpdateElab === false) {
            die("Error al actualizar elaboración: " . print_r(sqlsrv_errors(), true));
        }

        // Mostrar formulario para observación
        echo '<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Observación General</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="diseño/elaboracion2.css?<?php echo time(); ?>">
    
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header text-center">
                <h4>Observación General</h4>
            </div>
            <div class="card-body">
                <form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post">
                    <input type="hidden" name="NoMovimiento" value="' . $noMovimiento . '">
                    <input type="hidden" name="cedula" value="' . $cedula . '">
                    <input type="hidden" name="tipoMovimiento" value="' . $tipoMovimiento . '">
                    
                    <div class="form-group">
                        <label for="ob_gen">Ingrese la observación general para este movimiento:</label>
                        <textarea name="ob_gen" id="ob_gen" class="form-control" placeholder="Escriba aquí sus observaciones..." required></textarea>
                    </div>
                    
                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-check"></i> Registrar Observación
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>';
    } else {
        // Credenciales incorrectas
        echo '<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error de Autenticación</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="diseño/elaboracion2.css?<?php echo time(); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
</head>
<body>
    <script>
        Swal.fire({
            icon: "error",
            title: "Error de Autenticación",
            text: "La cédula o contraseña ingresada es incorrecta.",
            confirmButtonText: "Aceptar",
            customClass: {
                popup: "border-radius-15",
                confirmButton: "btn btn-primary"
            }
        }).then(() => {
            window.history.back();
        });
    </script>
</body>
</html>';
    }
}
// Procesar observación general
elseif (isset($_POST['ob_gen']) && isset($_POST['NoMovimiento']) && isset($_POST['cedula']) && isset($_POST['tipoMovimiento'])) {
    $observacion = $_POST['ob_gen'];
    $noMovimiento = $_POST['NoMovimiento'];
    $cedula = $_POST['cedula'];
    $tipoMovimiento = $_POST['tipoMovimiento'];

    // Actualizar la observación general
    $queryUpdateObs = "UPDATE insumos SET obser_gen = ? WHERE [No. Movimiento] = ? AND [Tipo Movimiento] = ?";
    $paramsUpdateObs = array($observacion, $noMovimiento, $tipoMovimiento);
    $stmtUpdateObs = sqlsrv_query($conn, $queryUpdateObs, $paramsUpdateObs);

    if ($stmtUpdateObs === false) {
        die("Error al actualizar observación: " . print_r(sqlsrv_errors(), true));
    }

    // Mostrar mensaje de éxito
    echo '<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proceso Completado</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="diseño/elaboracion2.css?<?php echo time(); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
</head>
<body>
    <script>
        Swal.fire({
            icon: "success",
            title: "¡Proceso Completado!",
            text: "El movimiento #' . $noMovimiento . ' ha sido registrado correctamente.",
            confirmButtonText: "Aceptar",
            customClass: {
                popup: "border-radius-10",
                confirmButton: "btn btn-success"
            }
        }).then(() => {
            window.close();
        });
        
    </script>
</body>
</html>';
}
