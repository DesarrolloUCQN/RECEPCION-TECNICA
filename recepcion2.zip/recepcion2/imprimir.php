<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Cédula</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.16/jspdf.plugin.autotable.min.js"></script>
   <link rel="stylesheet" href="diseño/imprimir.css?<?php echo time(); ?>">
</head>
<body>
    <h2>ELABORACION </h2>
    <div id="info_elabora" style="display:none;">
    <img id="imagen_elabora" src="imagenes/default.jpeg" alt="Imagen Elabora" style="max-width: 100px; max-height: 100px;" />
</div>
<!-- Cédula Elabora -->
<label for="cedula_elabora">Cédula (Elabora):</label>
<input type="number" id="cedula_elabora" placeholder="Ingresa cédula de quien elabora" >
<label for="nombre_elabora">Nombre (Elabora):</label>
<input type="text" id="nombre_elabora" disabled placeholder="Nombre de quien elabora" />
<!-- Campo hidden donde guardarás la clave -->
<input type="hidden" id="clave_oculta"> <!-- Aquí ya tienes la clave guardada dinámicamente -->
<br>
<!-- Campo para ingresar la clave -->
<label for="clave_input">Ingresa la clave (Elabora)</label>
<input type="password" id="clave_input" maxlength="3" placeholder="Ingresa la clave de quien aprueba"> <!-- Máximo de 3 caracteres -->


<hr>
<hr>
<hr>

<script>
// Función para verificar la clave cuando el usuario escribe en el campo de clave
document.getElementById("clave_input").addEventListener("input", function() {
    // Obtener la clave ingresada por el usuario
    var claveIngresada = document.getElementById("clave_input").value;
    console.log("Clave Ingresada:", claveIngresada);  // Ver la clave que el usuario está escribiendo
    
    // Verificar que se han ingresado exactamente 3 caracteres
    if (claveIngresada.length === 3) {
        // Obtener la clave guardada en el campo oculto
        var claveGuardada = document.getElementById("clave_oculta").value;
        console.log("Clave Guardada:", claveGuardada);  // Ver la clave oculta
        
        // Asegurarnos de que la clave oculta no esté vacía
        if (claveGuardada === "") {
            console.log("La clave oculta está vacía.");
            alert("No se ha encontrado la clave. Recargando...");
            location.reload();
            return;
        }

        // Comparar las claves
        if (claveIngresada === claveGuardada) {
            // Si las claves coinciden, continuar con el script
            console.log("Las claves coinciden.");
            alert("Las claves coinciden. Continuando...");
            // Aquí iría el resto del script que quieras ejecutar
        } else {
            // Si no coinciden, recargar la página
            console.log("Las claves no coinciden.");
            alert("Las claves no coinciden. Recargando...");
            location.reload();
        }
    } else {
        console.log("La clave ingresada tiene menos de 3 caracteres.");
    }
});
</script>
    <div id="info_aprueba" style="display:none;">
    <img id="imagen_apruebas" src="imagenes/default.jpeg" alt="Imagen Aprueba" style="max-width: 100px; max-height: 100px;" />
</div>
<H2>APROBACIÓN</H2>
    <!-- Cédula Aprueba -->
    <label for="cedula_aprueba">Cédula (Aprueba):</label>
    <input type="number" id="cedula_aprueba" placeholder="Ingresa cédula de quien aprueba" >
    <label for="nombre_aprueba">Nombre (Aprueba):</label>
    <input type="hidden" id="clave_oculta2">
    <input type="text" id="nombre_aprueba" disabled placeholder="Nombre de quien aprueba" />
<label for="clave_aprueba">Clave (Aprueba):</label>
<input type="password" id="clave_aprueba" placeholder="Ingresa la clave de quien aprueba"  maxlenght="3"/>
<script>
// Función para verificar la clave cuando el usuario escribe en el campo de clave
document.getElementById("clave_aprueba").addEventListener("input", function() {
    // Obtener la clave ingresada por el usuario
    var claveIngresada1 = document.getElementById("clave_aprueba").value;
    console.log("Clave Ingresada:", claveIngresada1);  // Ver la clave que el usuario está escribiendo
    
    // Verificar que se han ingresado exactamente 3 caracteres
    if (claveIngresada1.length === 3) {
        // Obtener la clave guardada en el campo oculto
        var claveGuardada1 = document.getElementById("clave_oculta2").value;
        console.log("Clave Guardada:", claveGuardada1);  // Ver la clave oculta
        
        // Asegurarnos de que la clave oculta no esté vacía
        if (claveGuardada1 === "") {
            console.log("La clave oculta está vacía.");
            alert("No se ha encontrado la clave. Recargando...");
            location.reload();
            return;
        }

        // Comparar las claves
        if (claveIngresada1 === claveGuardada1) {
            // Si las claves coinciden, continuar con el script
            console.log("Las claves coinciden.");
            alert("Las claves coinciden. Continuando...");
            // Aquí iría el resto del script que quieras ejecutar
        } else {
            // Si no coinciden, recargar la página
            console.log("Las claves no coinciden.");
            alert("Las claves no coinciden. Recargando...");
            location.reload();
        }
    } else {
        console.log("La clave ingresada tiene menos de 3 caracteres.");
    }
});
</script>



    <br><br>

    <!-- Selector de Observación -->
    <label for="observacion_select">¿Hay observación?</label>
    <select id="observacion_select">
        <option value="no">No</option>
        <option value="si">Sí</option>
    </select>
    
    <br><br>
    <label for="condicion"> Condiciones de transporte</label>
   SI <input type="radio" name="condicion" id="condicion" value='sincondi'><br>
   NO<input type="radio" name="condicion" id="condicion"value='concondi'>

    <!-- Campo de Observación -->
    <label for="observaciones">Observaciones:</label>
    <textarea id="observaciones" rows="4" cols="50" disabled placeholder="Escribe tus observaciones aquí..."></textarea>

    <br><br>

    <!-- Botón para generar el PDF -->
    <button id="generatePDF" style="display:none;">Generar PDF</button>

    <script>
     
     let rutaImagenElabora = '';
function init(filteredData) {
    $('#generatePDF').hide(); // Escondemos el botón de generar PDF hasta que todo esté listo

    let timeout;  // Variable para almacenar el timeout

$('#cedula_elabora').on('input', function() {
    const cedulaValue = $(this).val();

    // Limpiar el timeout anterior si existe
    clearTimeout(timeout);

    // Si el campo tiene algún valor
    if (cedulaValue) {
        // Establecer un timeout para ejecutar la validación después de 500ms
        timeout = setTimeout(function() {
            $.ajax({
                url: 'nombre.php', // URL del servidor para buscar el nombre y la imagen
                type: 'GET',
                data: { cedula: cedulaValue },
                success: function(response) {
                    const data = JSON.parse(response);  // Convertir la respuesta a JSON
                    if (data.success) {
                        $('#nombre_elabora').val(data.nombre);  // Llenar el campo nombre
                        $('#nombre_elabora_display').text(data.nombre); // Mostrar el nombre
                        // Mostrar la imagen
                        $('#imagen_elabora').attr('src', data.ruta_imagen); 
                        $('#info_elabora').show(); // Mostrar el bloque con la imagen y nombre
                        $('#clave_oculta').val(data.clave);
                        console.log("Clave Elabora: " + data.clave);
                    } else {
                        alert('Cédula de quien elabora no encontrada');
                        $('#nombre_elabora').val('');
                        $('#info_elabora').hide(); // Ocultar el bloque de nombre e imagen
                    }
                    validateButton();  // Validar si mostrar el botón de PDF
                },
                error: function() {
                    alert('Error al buscar la cédula de quien elabora');
                }
            });
        }, 1000); // Espera 500ms después de que el usuario haya dejado de escribir
    } else {
        $('#nombre_elabora').val('');
        $('#imagen_elabora').attr('src', 'imagenes/default.jpeg');  // Establecer imagen por defecto
        $('#info_elabora').hide(); // Ocultar el bloque de nombre e imagen
        validateButton();  // Validar si mostrar el botón de PDF
    }
});

let timeout2;  // Variable para almacenar el timeout para la cédula aprueba

$('#cedula_aprueba').on('input', function() {
    const cedulaValue = $(this).val();

    // Limpiar el timeout anterior si existe
    clearTimeout(timeout2);

    // Si el campo tiene algún valor
    if (cedulaValue) {
        // Establecer un timeout para ejecutar la validación después de 500ms
        timeout2 = setTimeout(function() {
            $.ajax({
                url: 'nombre.php', // URL del servidor para buscar el nombre y la imagen
                type: 'GET',
                data: { cedula: cedulaValue },
                success: function(response) {
                    const data = JSON.parse(response);  // Convertir la respuesta a JSON
                    if (data.success) {
                        $('#nombre_aprueba').val(data.nombre);  // Llenar el campo nombre
                        $('#nombre_aprueba_display').text(data.nombre); // Mostrar el nombre
                        // Mostrar la imagen
                        $('#imagen_apruebas').attr('src', data.ruta_imagen); 
                        $('#info_aprueba').show(); // Mostrar el bloque con la imagen y nombre
                        $('#clave_oculta2').val(data.clave);
                        console.log("Clave Aprueba: " + data.clave);
                    } else {
                        alert('Cédula de quien aprueba no encontrada');
                        $('#nombre_aprueba').val('');
                        $('#info_aprueba').hide(); // Ocultar el bloque de nombre e imagen
                    }
                    validateButton();  // Validar si mostrar el botón de PDF
                },
                error: function() {
                    alert('Error al buscar la cédula de quien aprueba');
                }
            });
        }, 1000); // Espera 500ms después de que el usuario haya dejado de escribir
    } else {
        $('#nombre_aprueba').val('');
        $('#imagen_apruebas').attr('src', 'imagenes/default.jpeg');  // Establecer imagen por defecto
        $('#info_aprueba').hide(); // Ocultar el bloque de nombre e imagen
        validateButton();  // Validar si mostrar el botón de PDF
    }
});

// Habilitar/Deshabilitar el campo de observaciones dependiendo del selector
$('#observacion_select').on('change', function() {
    if ($(this).val() === 'si') {
        $('#observaciones').prop('disabled', false);  // Habilitar el textarea
    } else {
        $('#observaciones').prop('disabled', true);  // Deshabilitar el textarea
        $('#observaciones').val('');  // Limpiar el textarea si no hay observaciones
    }
});


    // Función para validar si se deben mostrar los datos y habilitar el botón
    function validateButton() {
        const cedulaElabora = $('#cedula_elabora').val();
        const cedulaAprueba = $('#cedula_aprueba').val();
        const nombreElabora = $('#nombre_elabora').val();
        const nombreAprueba = $('#nombre_aprueba').val();

        // Validamos que ambos campos (cedula y nombre) estén completos
        if (cedulaElabora && nombreElabora && cedulaAprueba && nombreAprueba) {
            $('#generatePDF').show();  // Mostrar el botón de generar PDF
        } else {
            $('#generatePDF').hide();  // Ocultar el botón si no están completos
        }
    }

    $('#generatePDF').on('click', function () {
    const cedulaElabora = $('#cedula_elabora').val();
    const nombreElabora = $('#nombre_elabora').val();
    const cedulaAprueba = $('#cedula_aprueba').val();
    const nombreAprueba = $('#nombre_aprueba').val();

    const observaciones = $('#observaciones').val() || 'Ninguna';

    // Capturar la opción seleccionada para la condición de transporte
    const condicionTransporte = $('input[name="condicion"]:checked').val() || 'No seleccionado';

    // Validar que ambas cédulas y los nombres estén presentes
    if (!cedulaElabora || !cedulaAprueba || !nombreElabora || !nombreAprueba) {
        alert('Ambas cédulas y los nombres deben estar completos y válidos.');
        return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('landscape');

    // Cargar la imagen para el encabezado
    const img = new Image();
    img.src = 'principal.png';  // Cambia esto por la ruta correcta de tu imagen
    img.onload = function () {
        console.log("Imagen principal cargada correctamente.");

        // Una vez que la imagen se haya cargado, la agregamos al PDF
        doc.addImage(img, 'PNG', 5, 5, 300, 30);  // Puedes ajustar la posición y tamaño

        // Obtener la imagen de "Aprueba" y "Elabora" desde el DOM
        const imagenAprueba = document.getElementById('imagen_apruebas');
        const imagenElabora = document.getElementById('imagen_elabora'); // Nueva imagen para "Elabora"

        console.log("Imagen 'Aprueba' obtenida del DOM:", imagenAprueba);
        console.log("Imagen 'Elabora' obtenida del DOM:", imagenElabora);

        // Crear un canvas para convertir la imagen en base64
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        // Cuando la imagen de "Aprueba" esté cargada
        imagenAprueba.onload = function () {
            console.log("Imagen 'Aprueba' cargada correctamente.");

            // Establecer el tamaño del canvas según el tamaño de la imagen de "Aprueba"
            canvas.width = imagenAprueba.naturalWidth;
            canvas.height = imagenAprueba.naturalHeight;

            // Dibujar la imagen en el canvas
            ctx.drawImage(imagenAprueba, 0, 0);

            // Obtener la imagen en formato base64
            const imgDataAprueba = canvas.toDataURL('image/png'); // Convertir a base64
            console.log("Imagen 'Aprueba' convertida a base64:", imgDataAprueba);

            // Obtén el tamaño original de la imagen
            const originalWidthAprueba = imagenAprueba.naturalWidth;
            const originalHeightAprueba = imagenAprueba.naturalHeight;

            // Define un factor de escala para ajustar el tamaño de la imagen al PDF
            const scaleFactorAprueba = 0.2;
            const scaledWidthAprueba = originalWidthAprueba * scaleFactorAprueba;
            const scaledHeightAprueba = originalHeightAprueba * scaleFactorAprueba;

            // Agregar la imagen al PDF con el tamaño escalado y bajándola 25 unidades
            doc.addImage(imgDataAprueba, 'PNG', 170, 135 + 25, scaledWidthAprueba, scaledHeightAprueba);

            // Ahora manejamos la imagen para "Elabora"
            imagenElabora.onload = function () {
                console.log("Imagen 'Elabora' cargada correctamente.");

                // Establecer el tamaño del canvas según el tamaño de la imagen de "Elabora"
                canvas.width = imagenElabora.naturalWidth;
                canvas.height = imagenElabora.naturalHeight;

                // Dibujar la imagen en el canvas
                ctx.drawImage(imagenElabora, 0, 0);

                // Obtener la imagen en formato base64
                const imgDataElabora = canvas.toDataURL('image/png');
                console.log("Imagen 'Elabora' convertida a base64:", imgDataElabora);

                // Obtener el tamaño de la imagen
                const originalWidthElabora = imagenElabora.naturalWidth;
                const originalHeightElabora = imagenElabora.naturalHeight;

                // Define un factor de escala para la imagen de "Elabora"
                const scaleFactorElabora = 0.2; 
                const scaledWidthElabora = originalWidthElabora * scaleFactorElabora;
                const scaledHeightElabora = originalHeightElabora * scaleFactorElabora;

                // Agregar la imagen de "Elabora" al PDF con el tamaño escalado
                doc.addImage(imgDataElabora, 'PNG', 28, 135 + 25, scaledWidthElabora, scaledHeightElabora);

                // Tabla 1 - Datos generales
                const startY = 50;
                const headers = ['ACTA No.', 'PROVEEDOR', 'Factura Número', 'FECHA OC', 'Fecha Factura', 'Fecha Recibido', 'Usuario'];

                const data = filteredData.map(row => [
                    row[2],  // No. Movimiento
                    row[1],  // Proveedor
                    row[6],  // Factura Número
                    row[13], // Fecha OC
                    new Date().toLocaleDateString(), // Fecha Recibido
                    row[22]  // Usuario
                ]);

                // Verificar si autoTable está disponible y generar la tabla principal
                if (typeof doc.autoTable === 'function') {
                    doc.autoTable({
                        startY: startY,
                        head: [headers],
                        body: data,
                        theme: 'grid',
                        headStyles: { fillColor: [22, 160, 133] },
                        styles: { fontSize: 10 },
                    });
                }

                // Tabla 2 - Detalles del movimiento
                const secondTableStartY = doc.lastAutoTable.finalY + 10;  // Esto coloca la nueva tabla después de la primera
                const secondTableHeaders =
                    ['Codigo',
                        'Descripción',
                        'Condición',
                        'Forma Farmaceutica',
                        'Cadena De Llegadac°T Llegada',
                        'CM',
                        'Precentacion',
                        'Fabicante',
                        'Lote',
                    ];

                const secondTableData = filteredData.map(row => [
                    row[7],  // Codigo
                    row[8],  // Descripción
                    condicionTransporte,  // Condición de transporte (SI o NO)
                    row[9], //  FORMA  FARMACEUTICA
                    row[0], //  CADENA DE LLEGADA °T LLEGADA
                    row[18], // CM
                    row[10], // PRECENTACION
                    row[11], // Fabricante
                    row[12], // LOTE
                ]);

                // Generar la segunda tabla
                if (typeof doc.autoTable === 'function') {
                    doc.autoTable({
                        startY: secondTableStartY,
                        head: [secondTableHeaders],
                        body: secondTableData,
                        theme: 'grid',
                        headStyles: { fillColor: [22, 160, 133] },
                        styles: { fontSize: 10 },
                    });
                }

                // Agregar Observaciones
                // doc.text('Observaciones: ' + observaciones, 10, lineY - 18);

                // Agregar firma en el PDF
                const pageHeight = doc.internal.pageSize.height;
                const lineY = pageHeight - 30;

                // Ajustar la posición vertical para bajar más la firma y cédula
                const ajusteY = 20;

                // Elabora
                doc.setFontSize(11);
                doc.text('Elabora: ' + nombreElabora, 10, lineY + ajusteY);
                doc.text('Cédula: ' + cedulaElabora, 10, lineY + ajusteY + 8);

                // Agregar línea y texto "Firma" para Elabora
                doc.setFontSize(16);
                const firmaElaboraY = lineY + ajusteY - 10;
                doc.text('Firma: __________', 10, firmaElaboraY);

                // Aprueba
                doc.setFontSize(11);
                doc.text('Aprueba: ' + nombreAprueba, 150, lineY + ajusteY);
                doc.text('Cédula: ' + cedulaAprueba, 150, lineY + ajusteY + 8);

                // Agregar línea y texto "Firma" para Aprueba
                doc.setFontSize(16);
                const firmaApruebaY = lineY + ajusteY - 10;
                doc.text('Firma: __________', 150, firmaApruebaY);

                // Generar y guardar el PDF
                doc.save('movimiento.pdf');

                // Limpiar los campos después de generar el PDF
                $('#cedula_elabora').val('');
                $('#nombre_elabora').val('');
                $('#cedula_aprueba').val('');
                $('#nombre_aprueba').val('');
                $('#observacion_select').val('no');
                $('#observaciones').val('');
                $('#observaciones').prop('disabled', true);

                window.close();
            };

            // Si la imagen de "Elabora" ya está cargada, ejecutamos el código directamente
            if (imagenElabora.complete) {
                imagenElabora.onload();
            }
        };

        // Si la imagen de "Aprueba" ya está cargada, ejecutamos el código directamente
        if (imagenAprueba.complete) {
            imagenAprueba.onload();
        }
    };
});

 }


</script>

</body>
</html>