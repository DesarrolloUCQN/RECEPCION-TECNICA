<?php
// Configurar el tipo de contenido como JSON
header('Content-Type: application/json; charset=utf-8');

// Deshabilitar el reporte de errores para evitar que aparezcan en el JSON
error_reporting(0);
ini_set('display_errors', 0);

try {
    // Verificar que se envió la identificación
    if (!isset($_POST['identificacion']) || empty($_POST['identificacion'])) {
        throw new Exception("Identificación no proporcionada");
    }

    $identificacion = $_POST['identificacion'];

    // Conexión a la base de datos
    $serverName = "PA-S1-DATA\\UCQNDATA";
    $connectionInfo = array(
        "Database" => "recep_tec", 
        "UID" => "sadumesm", 
        "PWD" => "Dumes100%", 
        "characterset" => "UTF-8"
    );
    
    $conn = sqlsrv_connect($serverName, $connectionInfo);

    if (!$conn) {
        throw new Exception("Error de conexión a la base de datos");
    }

    // Consultar datos del usuario específico
    $query = "SELECT NomYApellCmp, Identificacion, RutaImagen, FechaRegistro 
              FROM firma_usuarios 
              WHERE Identificacion = ?";
    
    $params = array($identificacion);
    $stmt = sqlsrv_query($conn, $query, $params);

    if (!$stmt) {
        throw new Exception("Error al consultar datos del usuario");
    }

    $usuario = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

    if (!$usuario) {
        throw new Exception("Usuario no encontrado");
    }

    // Formatear fecha si existe
    $fechaRegistro = '';
    if ($usuario['FechaRegistro'] && is_object($usuario['FechaRegistro'])) {
        $fechaRegistro = $usuario['FechaRegistro']->format('d/m/Y H:i:s');
    }

    // Cerrar conexión
    sqlsrv_close($conn);

    // Respuesta exitosa
    echo json_encode([
        'success' => true,
        'data' => [
            'NomYApellCmp' => $usuario['NomYApellCmp'] ?? '',
            'Identificacion' => $usuario['Identificacion'] ?? '',
            'RutaImagen' => $usuario['RutaImagen'] ?? '',   
            'FechaRegistro' => $fechaRegistro
        ]
    ]);

} catch (Exception $e) {
    // En caso de error
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>