import reflex as rx

# Datos de ejemplo para usuarios
usuarios = {
    "usuario1": "contraseña123",
    "usuario2": "secreta456"
}

# Función para verificar el login
def verificar_login(username, password):
    if username in usuarios and usuarios[username] == password:
        return True
    return False

# Definir la interfaz de usuario
def app():
    return rx.center(
        rx.column(
            rx.text("Login", font_size="xl", font_weight="bold"),
            rx.input(placeholder="Usuario", id="usuario", width="300px"),
            rx.input(placeholder="Contraseña", id="password", type="password", width="300px"),
            rx.button("Iniciar sesión", on_click=verificar_login_event, width="300px"),
            rx.text(id="mensaje", color="red", font_size="sm"),
        )
    )

# Función para manejar el evento de login
def verificar_login_event(state):
    username = state["usuario"]
    password = state["password"]
    
    if verificar_login(username, password):
        state["mensaje"] = "Login exitoso"
    else:
        state["mensaje"] = "Usuario o contraseña incorrectos"

# Ejecutar la aplicación con Reflex
if __name__ == "__main__":
    # Usar rx.app() para ejecutar la aplicación correctamente
    rx.app(app).run()
