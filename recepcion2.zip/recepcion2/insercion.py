import pyodbc
import time
from datetime import datetime
import logging

# Configurar el logger para guardar las salidas en un archivo
logging.basicConfig(filename='console.txt', level=logging.INFO, format='%(asctime)s - %(message)s')

# Credenciales y conexión a las bases de datos
source_server = 'svr-imedicalcloud-db-prd01-west2-us-replica.database.windows.net'
source_database = 'iMedicalCentral'
source_username = 'iMedicalUCQN'
source_password = '$iMedical@0@$%'

dest_server = 'PA-S1-DATA\\UCQNDATA'  # Cambia a tu servidor de destino
dest_database = 'recep_tec'
dest_username = 'prue'
dest_password = 'JUQV4k45;?£'

# Conexión a la base de datos de origen (iMedicalCentral)
source_conn = pyodbc.connect(f'DRIVER={{ODBC Driver 17 for SQL Server}};'
                             f'SERVER={source_server};'
                             f'DATABASE={source_database};'
                             f'UID={source_username};'
                             f'PWD={source_password}')
source_cursor = source_conn.cursor()

# Conexión a la base de datos de destino (recep_tec)
dest_conn = pyodbc.connect(f'DRIVER={{ODBC Driver 17 for SQL Server}};'
                           f'SERVER={dest_server};'
                           f'DATABASE={dest_database};'
                           f'UID={dest_username};'
                           f'PWD={dest_password}')
dest_cursor = dest_conn.cursor()

# Función para validar y convertir la fecha en formato datetime adecuado para SQL Server
def formatear_fecha(fecha_str):
    try:
        fecha = datetime.strptime(fecha_str, "%Y-%m-%d %H:%M:%S")
        return fecha
    except ValueError:
        logging.error(f"Fecha inválida: {fecha_str}")  # Guardar el error en el log
        return None

# Función para insertar datos en la tabla firma_usuarios
def insertar_firma_usuarios():
    query_firma = """
    SELECT top 100 NomYApellCmp, Identificacion
    FROM gusuarios
    WHERE NomYApellCmp IS NOT NULL AND NomYApellCmp <> '' and Identificacion='1030024419'
    ORDER BY NomYApellCmp ASC ;
    """
    
    source_cursor.execute(query_firma)
    usuarios = source_cursor.fetchall()

    for usuario in usuarios:
        nom_y_apell_cmp = usuario[0]
        identificacion = usuario[1]
        fecha_registro = time.strftime('%Y-%m-%d %H:%M:%S')  # Fecha actual en formato DATETIME

        # Validar y formatear la fecha para SQL Server
        fecha_registro = formatear_fecha(fecha_registro)
        if fecha_registro is None:
            continue  # Si la fecha no es válida, omite este registro

        # Verificar si el usuario ya existe en la base de datos de destino
        check_query = """
        SELECT COUNT(*) FROM firma_usuarios
        WHERE NomYApellCmp = ? AND Identificacion = ?;
        """
        dest_cursor.execute(check_query, (nom_y_apell_cmp, identificacion))
        count = dest_cursor.fetchone()[0]

        if count == 0:
            # Insertar en la tabla firma_usuarios en la base de datos de destino si no existe
            insert_query = """
            INSERT INTO firma_usuarios (NomYApellCmp, Identificacion, FechaRegistro)
            VALUES (?, ?, ?);
            """
            dest_cursor.execute(insert_query, (nom_y_apell_cmp, identificacion, fecha_registro))
            dest_conn.commit()  # Aseguramos que el dato se guarde en la base de datos de destino
            logging.info(f"Usuario {nom_y_apell_cmp} insertado correctamente en firma_usuarios.")  # Guardar en el log
        else:
            logging.info(f"Usuario {nom_y_apell_cmp} ya existe en firma_usuarios, no se inserta.")  # Guardar en el log

def insertar_movimientos_inventario():
    query_movimientos = """
 SELECT
    f.numorden as [No. Orden],
    a.nomdestino as [Proveedor],
    a.nummovimiento as [No. Movimiento],
    g.nomtipomovimiento as [Tipo Movimiento],
    a.fecharegistro as [Fecha Movimiento],
    c.nombretipodocumento as [Tipo Documento],
    a.numdocumentosoporte as [No. Documento soporte],
    b.codigoproducto as [Cod. Producto],
    b.nombreproducto as [Producto_Comercial],
    case when i.proidtipoproducto = 1 then m.[nombreFormaFarma] else '' end as [Forma Farmaceutica],
    p.PreNombrePresentacion as [Presentacion],
    q.FabNombreFabricante as [Fabricante],
    d.lotenumero as [Lote],
    d.fechavencimiento as [Fecha Vencimiento],
    b.cantmovimiento as [Cantidad Mov],
    b.valorProducto as [Valor],
    e.codigohomologado as [Registro Sanitario],
    j.CodigoHomologado as [Vigencia registro Sanitario],
    n.CodigoHomologado as [CUM],
    o.codigo as [Codigo Clasificacion],
    o.nombreClasificacion as [Clasificacion],
    a.desobservacion as [Observacion],
    h.nombreprimer +' '+ h.nombresegundo +' '+ h.apellidoprimer +' '+ h.apellidosegundo as [Usuario]
    FROM dbo.iRAMovimientosInventario a
    INNER JOIN dbo.iRAMovimientosInventariodetalle b with (nolock) on b.idmovimiento = a.idmovimiento and identidad= a.idEntidad
    INNER JOIN dbo.gBasicoTipoDocumentosInventario c with (nolock) on c.idtipodocumentosoporte=a.idtipodocumentosoporte
    INNER JOIN dbo.gBasicoLotes d with (nolock) on d.idproductolote = b.idproductolote
    LEFT JOIN dbo.gBasicoHomologacionProductos e with (nolock) on e.idproducto = b.idproducto and idhomologacion = 2
    LEFT JOIN dbo.gBasicoHomologacionProductos j with (nolock) on j.IdProducto = b.idproducto and j.IdHomologacion= 20
    LEFT JOIN dbo.gBasicoHomologacionProductos n with (nolock) on n.IdProducto = b.idproducto and n.IdHomologacion=1
    LEFT JOIN dbo.iRAOrdenes f with (nolock) on f.idorden = a.iddocumentoorigen
    INNER JOIN dbo.iRAMovimientosInventarioTipos g with (nolock) on g.idtipomovimiento = a.idtipomovimiento
    INNER JOIN gusuarios h with (nolock) on h.idusuario = a.idusuariosregistra
    INNER JOIN gproducto i with (nolock) on i.proid = b.idproducto
    LEFT JOIN gproductomedicamento k on k.medid=i.proidgenerico
    LEFT JOIN [dbo].[gProductoMedicamentoConfigConcentracion] l on l.[idConcentracion] = k.[MedIdConcentracion]
    LEFT JOIN [dbo].[gProductoMedicamentoConfigForma] m on m.[idFormaFarmaceutica] = k.[MedIdFormaFarmaceutica]
    INNER JOIN gProductoClasificacion o on o.idProductoClasifica=i.ProIdClasificacion
    INNER JOIN gBasicoPresentacion p on p.PreIdPresentacion=b.idpresentacion
    INNER JOIN gBasicoFabricantes q on q.FabIdFabricante=i.ProIdFabricante
    WHERE a.identidad = 1178151 and a.fecharegistro>'2024-12-12';
    """

    source_cursor.execute(query_movimientos)
    movimientos = source_cursor.fetchall()

    logging.info(f"Total de movimientos recuperados: {len(movimientos)}")  # Agrega el log aquí

    for movimiento in movimientos:
        data = tuple(movimiento)

        # Verificar si el movimiento ya existe en la base de datos de destino
        check_query = """
        SELECT COUNT(*) FROM insumos
        WHERE [No. Movimiento] = ? 
          AND [Fecha Movimiento] = ? 
          AND [Cod. Producto] = ? 
          AND [Lote] = ? 
          AND [Cantidad Mov] = ?;
        """
        dest_cursor.execute(check_query, (movimiento[2], movimiento[4], 
                            movimiento[7], movimiento[12], movimiento[14]))
        count = dest_cursor.fetchone()[0]

        logging.info(f"Verificando movimiento {movimiento[2]}: {count} registros encontrados en destino.")  # Agregar log

        if count == 0:
            # Insertar en la tabla insumos (movimientos_inventario)
            insert_query = """
            INSERT INTO insumos ([No. Orden], [Proveedor], [No. Movimiento], [Tipo Movimiento], [Fecha Movimiento], 
            [Tipo Documento], [No. Documento soporte], [Cod. Producto], [Producto_Comercial], [Forma Farmaceutica], 
            [Presentacion], [Fabricante], [Lote], [Fecha Vencimiento], [Cantidad Mov], [Valor], [Registro Sanitario], 
            [Vigencia registro Sanitario], [CUM], [Codigo Clasificacion], [Clasificacion], [Observacion], [Usuario])
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """
            dest_cursor.execute(insert_query, data)
            dest_conn.commit()  # Aseguramos que el dato se guarde
            logging.info(f"Movimiento {movimiento[2]} insertado correctamente en movimientos_inventario.")  # Guardar en el log
        else:
            logging.info(f"Movimiento {movimiento[2]} ya existe en movimientos_inventario, no se inserta.")  # Guardar en el log


# Función principal para ejecutar las inserciones
def main():
    while True:
        insertar_firma_usuarios()
        insertar_movimientos_inventario()
        time.sleep(20)  # Espera 20 segundos antes de la siguiente ejecución

# Cerrar conexiones al finalizar
    source_conn.close()
    dest_conn.close()

# Ejecutar la función principal
if __name__ == "__main__":
    main()
