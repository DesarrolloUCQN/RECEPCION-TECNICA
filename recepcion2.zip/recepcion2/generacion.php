<?php
// Establecer la conexión con la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";  
$connectionInfo = array("Database" => "recep_tec", "UID" => "sadumesm", "PWD" => "Dumes100%", "characterset"=> "UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
}

// Comprobar si se recibió el No. Movimiento
if (isset($_POST['noMovimiento'])) {
    $noMovimiento = $_POST['noMovimiento'];
    $tipoMovimiento = $_POST['tipoMovimiento'];

    // Consultar los datos de insumos filtrados por No. Movimiento
    $query = "SELECT 
        [ID],
        [No. Orden], 
        Proveedor, 
        [No. Movimiento], 
        [Tipo Movimiento], 
        [Fecha Movimiento], 
        [Tipo Documento], 
        [No. Documento soporte], 
        [Cod. Producto], 
        [Producto_Comercial], 
        [Forma Farmaceutica], 
        Presentacion, 
        Fabricante, 
        Lote, 
        [Fecha Vencimiento], 
        Valor, 
        [Registro Sanitario], 
        [Vigencia Registro Sanitario], 
        CUM, 
        [Codigo Clasificacion], 
        Clasificacion, 
        condi,
        cadena,
        [condiciones_de_almacenamiento],
        mce,
        [Cantidad Mov], 
        cant_soli,
        pac,
        muestra,
        defecto,
        observacion_usu, 
        elaboracion,
        aprobacion,
        validado,
        Usuario,
        fecha_factura,
        fecha_oc,
        fecha_re,
        obser_gen
    FROM insumos
    WHERE [No. Movimiento] = ? AND [Tipo Movimiento] = ?";  // Filtrar por No. Movimiento

    $params = array($noMovimiento, $tipoMovimiento);  // Asignar el valor del No. Movimiento
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    // Recoger los resultados de la tabla "insumos"
    $insumos = array();
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        // Obtener los nombres y rutas de las firmas de las cédulas de "firma_usuarios"
        $elaboracionIdentificacion = $row['elaboracion'];
        $aprobacionIdentificacion = $row['aprobacion'];

        // Consulta para obtener el nombre y la ruta de la firma para "Elaboración"
        $queryElaboracion = "SELECT NomYApellCmp, RutaImagen FROM firma_usuarios WHERE Identificacion = ?";
        $paramsElaboracion = array($elaboracionIdentificacion);
        $stmtElaboracion = sqlsrv_query($conn, $queryElaboracion, $paramsElaboracion);
        $elaboracionNombre = "";
        $elaboracionRutaImagen = "";
        if ($stmtElaboracion && $rowElaboracion = sqlsrv_fetch_array($stmtElaboracion, SQLSRV_FETCH_ASSOC)) {
            $elaboracionNombre = $rowElaboracion['NomYApellCmp'];
            // Reemplazar las barras invertidas por barras normales
            $elaboracionRutaImagen = str_replace("\\", "/", $rowElaboracion['RutaImagen']);
        }

        // Consulta para obtener el nombre y la ruta de la firma para "Aprobación"
        $queryAprobacion = "SELECT NomYApellCmp, RutaImagen FROM firma_usuarios WHERE Identificacion = ?";
        $paramsAprobacion = array($aprobacionIdentificacion);
        $stmtAprobacion = sqlsrv_query($conn, $queryAprobacion, $paramsAprobacion);
        $aprobacionNombre = "";
        $aprobacionRutaImagen = "";
        if ($stmtAprobacion && $rowAprobacion = sqlsrv_fetch_array($stmtAprobacion, SQLSRV_FETCH_ASSOC)) {
            $aprobacionNombre = $rowAprobacion['NomYApellCmp'];
            // Reemplazar las barras invertidas por barras normales
            $aprobacionRutaImagen = str_replace("\\", "/", $rowAprobacion['RutaImagen']);
        }

        // Agregar la información de los nombres y las rutas de las firmas a los datos
        $row['elaboracionNombre'] = $elaboracionNombre;
        $row['aprobacionNombre'] = $aprobacionNombre;
        $row['elaboracionRutaImagen'] = $elaboracionRutaImagen;
        $row['aprobacionRutaImagen'] = $aprobacionRutaImagen;

        $insumos[] = $row;
    }

    // Devolver los resultados en formato JSON sin barras invertidas
    echo json_encode($insumos, JSON_UNESCAPED_SLASHES);
} else {
    // Si no se recibe el No. Movimiento, devolver error
    echo json_encode(array('error' => 'No. Movimiento es obligatorio.'));
}
?>
