<?php
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array("Database" => "recep_tec", "UID" => "sadumesm", "PWD" => "Dumes100%", "characterset" => "UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión: ' . print_r(sqlsrv_errors(), true)]);
    exit;
}

try {
    // Validar que se recibieron los datos necesarios
    if (!isset($_POST['Identificacion']) || empty($_POST['Identificacion'])) {
        echo json_encode(['success' => false, 'message' => 'La identificación es requerida.']);
        exit;
    }


    // Recibir los datos del formulario
    $identificacion = trim($_POST['Identificacion']);
    $clave = trim($_POST['clave']);
    $imagenSubida = false;
    $rutaRelativa = '';

    // Verificar si se subió una imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == 0) {
        // Validar el tamaño del archivo (máximo 5MB)
        $maxSize = 5 * 1024 * 1024; // 5MB en bytes
        if ($_FILES['imagen']['size'] > $maxSize) {
            echo json_encode(['success' => false, 'message' => 'La imagen es demasiado grande. Máximo 5MB permitido.']);
            exit;
        }

        $directorioDestino = 'C:/xampp/htdocs/recepcion2/imagenes/';
        
        // Verificar que el directorio existe, si no, crearlo
        if (!is_dir($directorioDestino)) {
            if (!mkdir($directorioDestino, 0755, true)) {
                echo json_encode(['success' => false, 'message' => 'No se pudo crear el directorio de imágenes.']);
                exit;
            }
        }

        $imagenTmpName = $_FILES['imagen']['tmp_name'];
        $imagenName = $_FILES['imagen']['name'];
        
        // Obtener la extensión del archivo
        $extensionArchivo = strtolower(pathinfo($imagenName, PATHINFO_EXTENSION));
        
        // Validar que sea PNG, JPG o JPEG
        $extensionesPermitidas = ['png', 'jpg', 'jpeg'];
        
        if (in_array($extensionArchivo, $extensionesPermitidas)) {
            // Verificar que el archivo sea realmente una imagen válida
            $verificarImagen = getimagesize($imagenTmpName);
            
            if ($verificarImagen !== false) {
                // Generar un nombre único para evitar conflictos
                $nombreUnico = $identificacion . '_' . time() . '.' . $extensionArchivo;
                $rutaDestino = $directorioDestino . $nombreUnico;

                // Mover el archivo a la carpeta de destino
                if (move_uploaded_file($imagenTmpName, $rutaDestino)) {
                    $rutaRelativa = 'imagenes/' . $nombreUnico;
                    $imagenSubida = true;
                } else {
                    echo json_encode(['success' => false, 'message' => 'Error al subir la imagen al servidor. Verificar permisos del directorio.']);
                    exit;
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'El archivo no es una imagen válida.']);
                exit;
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Solo se permiten archivos PNG, JPG y JPEG.']);
            exit;
        }
    }

    // Preparar la consulta de actualización
    if ($imagenSubida) {
        // Actualizar con imagen
        $query = "UPDATE firma_usuarios 
                  SET FechaRegistro = GETDATE(), 
                      clave = ?,
                      RutaImagen = ?
                  WHERE Identificacion = ?";
        $params = array($clave, $rutaRelativa, $identificacion);
    } else {
        // Actualizar solo la clave
        $query = "UPDATE firma_usuarios 
                  SET FechaRegistro = GETDATE(), 
                      clave = ?
                  WHERE Identificacion = ?";
        $params = array($clave, $identificacion);
    }

    // Ejecutar la consulta
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        $errors = sqlsrv_errors();
        echo json_encode(['success' => false, 'message' => 'Error en la consulta SQL: ' . print_r($errors, true)]);
        exit;
    }

    $rowsAffected = sqlsrv_rows_affected($stmt);
    
    if ($rowsAffected > 0) {
        echo json_encode([
            'success' => true, 
            'imagenSubida' => $imagenSubida,
            'message' => 'Usuario actualizado correctamente.',
            'rutaImagen' => $imagenSubida ? $rutaRelativa : null
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No se encontró el usuario con la identificación proporcionada.']);
    }

    // Liberar recursos
    sqlsrv_free_stmt($stmt);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error inesperado: ' . $e->getMessage()]);
} finally {
    // Cerrar conexión
    if ($conn) {
        sqlsrv_close($conn);
    }
}
?>