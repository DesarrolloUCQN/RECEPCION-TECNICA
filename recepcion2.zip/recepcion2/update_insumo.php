<?php
// Configuración de la conexión a la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array("Database" => "recep_tec", "UID" => "sadumesm", "PWD" => "Dumes100%", "characterset" => "UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    die(json_encode(array("status" => "error", "message" => "No se pudo conectar a la base de datos")));
}

// Recibir los datos enviados por AJAX
$id = isset($_POST['id']) ? $_POST['id'] : null;
$column = isset($_POST['column']) ? $_POST['column'] : null;
$value = isset($_POST['value']) ? $_POST['value'] : null;

// Verificar que los parámetros son válidos
if ($id === null || $column === null || $value === null) {
    die(json_encode(array("status" => "error", "message" => "Faltan parámetros")));
}

// Validar que la columna existe en la tabla
$validColumns = array("condi", "cadena", "mce", "can_rec", "pac", "muestra", "defecto", "observacion");

if (!in_array($column, $validColumns)) {
    die(json_encode(array("status" => "error", "message" => "Columna no válida")));
}

// Construir la consulta SQL para actualizar el valor en la columna correspondiente
$query = "UPDATE insumos SET [$column] = ? WHERE ID = ?";

// Preparar la consulta
$params = array($value, $id);
$stmt = sqlsrv_query($conn, $query, $params);

if ($stmt === false) {
    // Error en la consulta
    die(json_encode(array("status" => "error", "message" => sqlsrv_errors())));
} else {
    // Si todo salió bien, devolver una respuesta de éxito
    echo json_encode(array("status" => "success", "message" => "Datos actualizados correctamente"));
}

// Cerrar la conexión
sqlsrv_close($conn);
?>
