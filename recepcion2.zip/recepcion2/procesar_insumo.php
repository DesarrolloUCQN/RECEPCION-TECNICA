<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Establecer la conexión con la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";  
$connectionInfo = array(
    "Database" => "recep_tec", 
    "UID" => "sadumesm", 
    "PWD" => "Dumes100%", 
    "characterset" => "UTF-8"
);
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    echo json_encode(["status" => "error", "message" => "Error en la conexión con la base de datos"]);
    exit;
}

// Obtener y validar los datos del formulario
$insumoId = $_POST['ID'] ?? null;
if (!$insumoId) {
    echo json_encode(["status" => "error", "message" => "ID de insumo no proporcionado"]);
    exit;
}

$condi = isset($_POST['condi']) ? $_POST['condi'] : 'NO';
$cadena = isset($_POST['cadena']) ? $_POST['cadena'] : 'N/A';
$condicionesAlm = $_POST['condiciones_de_almacenamiento'] ?? 'N/A';
$cant_soli = $_POST['cant_soli'] ?? '';
$pac = isset($_POST['pac']) ? $_POST['pac'] : 'N/C';
$muestra = isset($_POST['muestra']) ? (int)$_POST['muestra'] : 0;
$defecto = isset($_POST['defecto']) ? $_POST['defecto'] : 'NO';
$mce = in_array($_POST['mce'] ?? '', ['Aplica', 'N/A']) ? $_POST['mce'] : 'N/A';
$validado = $_POST['validado'] ?? 'Aprobado';
$observacion = $_POST['observacion'] ?? '';

// Validar formato de cantidad solicitada (corregido)
if (!is_numeric($cant_soli) || $cant_soli < 1) {
    echo json_encode(["status" => "error", "message" => "La cantidad solicitada debe ser un número mayor a 0"]);
    exit;
}

// Validar que la muestra sea un número positivo
if ($muestra < 0) {
    echo json_encode(["status" => "error", "message" => "El tamaño de muestra debe ser un número positivo"]);
    exit;
}

// Preparar la consulta SQL
$query = "UPDATE insumos SET 
    condi = ?, 
    cadena = ?, 
    condiciones_de_almacenamiento = ?,
    cant_soli = ?, 
    pac = ?,    
    muestra = ?, 
    defecto = ?,
    mce = ?,
    observacion_usu = ?,
    validado = ?
WHERE ID = ?";

// Parámetros en el orden correcto
$params = array(
    $condi, 
    $cadena, 
    $condicionesAlm,
    $cant_soli, 
    $pac, 
    $muestra, 
    $defecto,
    $mce,
    $observacion,
    $validado,
    $insumoId
);

// Ejecutar la consulta
$stmt = sqlsrv_query($conn, $query, $params);

if ($stmt === false) {
    $errors = sqlsrv_errors();
    echo json_encode([
        "status" => "error", 
        "message" => "Error al actualizar: " . $errors[0]['message']
    ]);
    sqlsrv_close($conn);
    exit;
}

// Éxito
echo json_encode([
    "status" => "success", 
    "message" => "Actualización exitosa",
    "data" => [
        "id" => $insumoId,
        "muestra" => $muestra,
        "cant_soli" => $cant_soli
    ]
]);

sqlsrv_close($conn);
?>