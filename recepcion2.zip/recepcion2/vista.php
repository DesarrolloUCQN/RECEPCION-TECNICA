<?php
// Establecer la conexión con la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array("Database" => "recep_tec", "UID" => "sadumesm", "PWD" => "Dumes100%", "characterset" => "UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
}

// Inicializar array de insumos vacío - No cargar datos inicialmente
$insumos = array();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestión - Lista de Insumos</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.2.1/css/fixedHeader.dataTables.min.css">
    
    <!-- FontAwesome para iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <!-- Animate.css para animaciones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <!-- Estilos específicos para botones -->
    <link rel="stylesheet" href="diseño/vista.css">
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/fixedheader/3.2.1/js/dataTables.fixedHeader.min.js"></script>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jsPDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.27/jspdf.plugin.autotable.min.js"></script>
    
    <link rel="shortcut icon" href="img/icono.ico" type="image/x-icon">
    <link rel="stylesheet" href="diseño/loader.css">
    

    <style>
        :root {
            --primary-color: #007BFF;
            --success-color: #218838;
            --info-color: #138496;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
        }

        body {
            background: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding-top: 1rem;
            margin: 0;
            padding: 0;
        }

        .container-fluid {
            padding: 10px;
        }


        /* Page Header */
        .page-header {
            background: var(--primary-color);
            color: white;
            padding: 1.5rem 0;
            margin-bottom: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.2);
            position: relative;
        }

        .page-header h1 {
            font-weight: 600;
            font-size: 2rem;
            margin: 0;
        }

        .page-header .subtitle {
            font-size: 1rem;
            opacity: 0.9;
            margin-top: 0.5rem;
        }

        .header-icon-left {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 50px;
            height: 50px;
            border-radius: 6px;
            box-shadow: 0 3px 10px rgba(255, 255, 255, 0.3);
            background: rgba(255, 255, 255, 0.1);
            padding: 6px;
            transition: all 0.3s ease;
        }

        .header-icon-left:hover {
            transform: translateY(-50%) scale(1.1);
        }

        @media (max-width: 768px) {
            .header-icon-left {
                width: 35px;
                height: 35px;
                left: 15px;
            }
        }

        /* Search Section */
        .search-section {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            border-left: 4px solid var(--success-color);
        }

        .search-section h4 {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }

        /* Form Controls */
        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            background: white;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.15);
            background: white;
        }

        .form-label {
            color: var(--dark-color);
            font-weight: 600;
            margin-bottom: 0.75rem;
        }

        /* Input Group Styles */
        .input-group {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            transition: all 0.3s ease;
        }

        .input-group:hover {
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.15);
        }

        .input-group .form-control {
            border: none;
            border-radius: 0;
            margin: 0;
        }

        .input-group-text {
            border: none;
            background-color: var(--primary-color);
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .input-group-text:hover {
            background-color: #0056b3;
        }

        /* Action Buttons Container */
        .action-buttons-container {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            border-left: 4px solid var(--warning-color);
        }

        .action-buttons-container h5 {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 1rem;
            font-size: 1.1rem;
        }

        /* Table Container */
        .table-container {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--info-color);
        }

        .table-container h4 {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.25rem;
        }

        /* Contenedor para botón Regresar debajo del datatable */
        .regresar-container {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--danger-color);
            text-align: center;
        }

        /* Table Styles */
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.05);
            max-height: 500px;
            overflow-y: auto;
            overflow-x: auto;
            width: 100%;
        }

        .table {
            margin-bottom: 0;
            font-size: 0.9rem;
            min-width: 100%;
            white-space: nowrap;
        }

        .table thead th {
            background: var(--primary-color);
            color: white;
            border: none;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.75rem;
            font-size: 0.8rem;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .table tbody tr {
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background-color: rgba(0, 123, 255, 0.05);
        }

        .table tbody td {
            padding: 0.75rem;
            vertical-align: middle;
            border-color: #e9ecef;
            white-space: nowrap;
        }

        .table tbody tr {
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background-color: rgba(0, 123, 255, 0.05);
        }

        .table tbody td {
            padding: 0.75rem;
            vertical-align: middle;
            border-color: #e9ecef;
        }

        /* Modal Styles */
        .modal-content {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 123, 255, 0.15);
            overflow: hidden;
        }

        .modal-header {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 1.5rem 2rem;
            position: relative;
        }

        .modal-header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: rgba(255, 255, 255, 0.2);
        }

        .modal-header h5 {
            font-weight: 600;
            margin: 0;
            font-size: 1.25rem;
        }

        .modal-body {
            padding: 2rem;
            background: #fafbfc;
        }

        .modal-footer {
            border: none;
            padding: 1.5rem 2rem;
            background: white;
            border-top: 1px solid #e9ecef;
        }

        .btn-close {
            background: rgba(255,255,255,0.9);
            border-radius: 50%;
            opacity: 1;
            width: 32px;
            height: 32px;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-close:hover {
            background: white;
            transform: scale(1.1);
        }

        /* Custom close button styles */
        .btn-close-custom {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            padding: 0;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            opacity: 0.8;
        }

        .btn-close-custom:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: scale(1.1);
            opacity: 1;
        }

        .btn-close-custom:focus {
            outline: none;
            box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.3);
        }

        /* Form Check Styles */
        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .form-check-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.15);
        }

        /* Estilos para el layout horizontal de Cadena de Frío */
        .cadena-frio-layout {
            display: flex;
            gap: 20px;
            align-items: flex-start;
            margin-top: 20px;
        }

        .cadena-frio-layout .border {
            flex: 1;
            min-width: 200px;
        }

        /* Animation Classes */
        .fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* DataTables Custom Styles */
        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_filter,
        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_paginate {
            font-size: 0.875rem;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            padding: 0.375rem 0.75rem;
            margin-left: 2px;
            border-radius: 6px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: var(--primary-color) !important;
            border-color: var(--primary-color) !important;
            color: white !important;
        }

        /* Initial Message */
        .initial-message {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--info-color);
        }

        .initial-message i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .page-header h1 {
                font-size: 1.75rem;
            }
            
            .search-section,
            .action-buttons-container,
            .table-container,
            .regresar-container {
                padding: 1rem;
            }

            .modal-body {
                padding: 1.5rem;
            }

            .cadena-frio-layout {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>

<body id="contenidocompleto">
    <!-- Loader con Hamster -->
    <div class="loader-wrapper" id="loader">
        <div aria-label="Orange and tan hamster running in a metal wheel" role="img" class="wheel-and-hamster">
            <div class="wheel"></div>
            <div class="hamster">
                <div class="hamster__body">
                    <div class="hamster__head">
                        <div class="hamster__ear"></div>
                        <div class="hamster__eye"></div>
                        <div class="hamster__nose"></div>
                    </div>
                    <div class="hamster__limb hamster__limb--fr"></div>
                    <div class="hamster__limb hamster__limb--fl"></div>
                    <div class="hamster__limb hamster__limb--br"></div>
                    <div class="hamster__limb hamster__limb--bl"></div>
                    <div class="hamster__tail"></div>
                </div>
            </div>
            <div class="spoke"></div>
        </div>
        <img src="img/UCQN LOGO.png" alt="UCQN Logo" class="loader-logo">
    </div>


    <div class="container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header text-center fade-in-up">
            <div class="container">
                <div class="d-flex align-items-center justify-content-center">
                    <img src="img/icono.ico" alt="Icono" style="position: absolute;right: 94%;top: 25px;width: 4%;">
                    <div>
                        <h1 class="mb-0"><i class="fas fa-boxes me-3"></i>Sistema de Gestión de Insumos</h1>
                        <p class="subtitle mb-0">Control y administración de inventario médico</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search Section -->
        <div class="search-section fade-in-up" style="animation-delay: 0.2s">
            <h4><i class="fas fa-search me-2"></i>Búsqueda de Insumos</h4>
            
            <!-- Formulario de búsqueda -->
            <form action="recargar.php" method="get" id="searchForm">
                <div class="row align-items-end g-3">
                    <!-- Filtro de selección para tipo de movimiento -->
                    <div class="col-md-4 col-sm-12">
                        <div class="form-group">
                            <label for="tipoMovimiento" class="form-label">
                                <i class="fas fa-filter me-1"></i>Tipo de Movimiento:
                            </label>
                            <select id="tipoMovimiento" name="tipoMovimiento" class="form-select" required>
                                <option value="">Seleccione un tipo de movimiento</option>
                                <option value="Compra Directa">Compra Directa</option>
                                <option value="Remisión">Remisión</option>
                                <option value="Ingreso por Préstamo de Otra Institución">Ingreso por Préstamo de Otra Institución</option>
                                <option value="Ingreso por Aprovechamiento">Ingreso por Aprovechamiento</option>
                                <option value="Ingreso Devolución Préstamo">Ingreso Devolución Préstamo</option>
                                <option value="Compra por Orden">Compra por Orden</option>
                            </select>
                        </div>
                    </div>

                    <!-- Campo de búsqueda por No. Movimiento -->
                    <div class="col-md-6 col-sm-12">
                        <label for="searchInput" class="form-label">
                            <i class="fas fa-hashtag me-1"></i>Número de Movimiento:
                        </label>
                        <div class="input-group">
                            <input type="text" id="searchInput" name="searchQuery" class="form-control" 
                                   placeholder="Buscar por No. Movimiento" required>
                            <button type="submit" class="btn btn-primary input-group-text">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Botón de limpiar -->
                    <div class="col-md-2 col-sm-12">
                        <button type="button" id="limpiarBtn" class="btn btn-warning w-100">
                            <i class="fas fa-eraser me-2"></i>Limpiar
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Initial Message -->
        <div class="initial-message fade-in-up" id="initialMessage" style="animation-delay: 0.3s">
            <i class="fas fa-search-plus"></i>
            <h5>Buscar Insumos</h5>
            <p class="mb-0">Seleccione un tipo de movimiento e ingrese un número de movimiento para comenzar la búsqueda.</p>
        </div>

        <!-- Action Buttons -->
        <div class="action-buttons-container fade-in-up" id="actionButtons" style="display: none; animation-delay: 0.4s">
            <h5><i class="fas fa-cogs me-2"></i>Acciones Disponibles</h5>
            <div class="d-flex flex-wrap gap-3">
                <a href="#" id="elaborarLink" class="btn btn-primary">
                    <i class="fas fa-edit me-2"></i>Elaborar
                </a>
                <a href="#" id="aprobarLink" class="btn btn-success">
                    <i class="fas fa-check me-2"></i>Aprobar
                </a>
                <button id="generatePDFBtn" class="btn btn-danger">
                    <i class="fas fa-file-pdf me-2"></i>Generar PDF
                </button>
            </div>
        </div>

        <!-- Table Container -->
        <div class="table-container fade-in-up" id="tableContainer" style="display: none; animation-delay: 0.5s">
            <h4><i class="fas fa-table me-2"></i>Resultados de Búsqueda</h4>
            <div class="table-responsive">
                <table id="insumosTable" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Mas</th>
                            <th>ID</th>
                            <th>No. Orden</th>
                            <th>Proveedor</th>
                            <th>No. Movimiento</th>
                            <th>Tipo Movimiento</th>
                            <th>Fecha Movimiento</th>
                            <th>Tipo Documento</th>
                            <th>No. Documento Soporte</th>
                            <th>Cod. Producto</th>
                            <th>Producto Comercial</th>
                            <th>Forma Farmacéutica</th>
                            <th>Presentación</th>
                            <th>Fabricante</th>
                            <th>Lote</th>
                            <th>Fecha Vencimiento</th>
                            <th>Valor</th>
                            <th>Registro Sanitario</th>
                            <th>Vigencia Registro Sanitario</th>
                            <th>CUM</th>
                            <th>Código Clasificación</th>
                            <th>Clasificación</th>
                            <th>condicion</th>
                            <th>cadena de frio</th>
                            <th>MCE</th>
                            <th>Condiciones de Almacenamiento</th>
                            <th>Cantidad Recibida</th>
                            <th>Cantidad Solicitada</th>
                            <th>Precio Pactado en OC</th>
                            <th>Tamaño Muestra</th>
                            <th>Defecto</th>
                            <th>Observación</th>
                            <th>CC Elabora</th>
                            <th>Usuario Elabora</th>
                            <th>CC Aprobación</th>
                            <th>Usuario Aprueba</th>
                            <th>Validacion</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Los datos se cargarán dinámicamente -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Contenedor del botón Regresar - Siempre visible -->
        
            <a href="index.php" class="btn btn-danger">
                <i class="fas fa-home me-2"></i>Regresar al Menú Principal
            </a>
        
    </>

    <!-- Modal para agregar o editar insumo -->
    <div class="modal fade" id="addInsumoModal" tabindex="-1" aria-labelledby="addInsumoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addInsumoModalLabel">
                        <i class="fas fa-edit me-2"></i>Actualizar Condición
                    </h5>
                    <button type="button" class="btn-close-custom" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="insumoForm" method="POST">
                        <div class="row">
                            <div class="mb-3 col-md-6">
                                <label for="ID" class="form-label">
                                    <i class="fas fa-hashtag me-1 text-primary"></i>ID:
                                </label>
                                <input type="text" id="ID" name="ID" class="form-control" readonly required />
                            </div>

                            <div class="mb-3 col-md-6">
                                <label for="NoMovimiento" class="form-label">
                                    <i class="fas fa-barcode me-1 text-primary"></i>No. Movimiento:
                                </label>
                                <input type="text" id="NoMovimiento" name="NoMovimiento" class="form-control" readonly required />
                            </div>

                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="condi_si">
                                    <i class="fas fa-truck me-1 text-primary"></i>Condiciones de transporte:
                                </label><br />
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="condi" id="condi_si" value="C" required>
                                    <label class="form-check-label" for="condi_si">SÍ</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="condi" id="condi_no" value="NC" required>
                                    <label class="form-check-label" for="condi_no">NO</label>
                                </div>
                            </div>

                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="pac_aplica">
                                    <i class="fas fa-dollar-sign me-1 text-primary"></i>Precio pactado en OC:
                                </label><br />
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="pac" id="pac_aplica" value="Cumple" required>
                                    <label class="form-check-label" for="pac_aplica">Cumple</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="pac" id="pac_noaplica" value="N/C" required>
                                    <label class="form-check-label" for="pac_noaplica">No Cumple</label>
                                </div>
                            </div>

                            <div class="mb-3 col-md-6">
                                <label for="cant_soli" class="form-label">
                                    <i class="fas fa-calculator me-1 text-primary"></i>Cantidad Solicitada:
                                </label>
                                <input type="number" name="cant_soli" id="cant_soli" class="form-control" required min="1">
                            </div>

                            <div class="mb-3 col-md-6">
                                <label for="muestra" class="form-label">
                                    <i class="fas fa-vial me-1 text-primary"></i>Tamaño Muestra:
                                </label>
                                <input type="number" name="muestra" id="muestra" class="form-control" required min="1">
                            </div>

                            <script>
                                // Variable para controlar si el usuario ha editado manualmente el tamaño muestra
                                let muestraEditadaManual = false;

                                document.getElementById('cant_soli').addEventListener('input', function() {
                                    const cantidad = parseInt(this.value) || 0;
                                    let muestraCalculada = 0;

                                    // Definición de rangos y valores de muestra (según tu tabla original)
                                    if (cantidad >= 2 && cantidad <= 8) muestraCalculada = 2;
                                    else if (cantidad >= 9 && cantidad <= 15) muestraCalculada = 3;
                                    else if (cantidad >= 16 && cantidad <= 25) muestraCalculada = 5;
                                    else if (cantidad >= 26 && cantidad <= 50) muestraCalculada = 8;
                                    else if (cantidad >= 51 && cantidad <= 90) muestraCalculada = 13;
                                    else if (cantidad >= 91 && cantidad <= 150) muestraCalculada = 20;
                                    else if (cantidad >= 151 && cantidad <= 280) muestraCalculada = 32;
                                    else if (cantidad >= 281 && cantidad <= 500) muestraCalculada = 50;
                                    else if (cantidad >= 501 && cantidad <= 1200) muestraCalculada = 80;
                                    else if (cantidad >= 1201 && cantidad <= 3200) muestraCalculada = 125;
                                    else if (cantidad >= 3201 && cantidad <= 10000) muestraCalculada = 200;
                                    else if (cantidad >= 10001 && cantidad <= 35000) muestraCalculada = 315;
                                    else if (cantidad >= 35001 && cantidad <= 150000) muestraCalculada = 500;
                                    else if (cantidad >= 150001 && cantidad <= 500000) muestraCalculada = 800;
                                    else if (cantidad >= 500001) muestraCalculada = 1250;

                                    // Si el usuario no ha editado manualmente o si borró el valor
                                    if (!muestraEditadaManual || document.getElementById('muestra').value === '') {
                                        document.getElementById('muestra').value = muestraCalculada > 0 ? muestraCalculada : '';
                                    }
                                });

                                // Controlamos si el usuario edita manualmente el campo muestra
                                document.getElementById('muestra').addEventListener('input', function() {
                                    const cantSoli = document.getElementById('cant_soli').value;
                                    const muestraActual = this.value;

                                    // Si hay cantidad solicitada y el usuario cambia el valor de muestra
                                    if (cantSoli && muestraActual) {
                                        muestraEditadaManual = true;
                                    } else {
                                        muestraEditadaManual = false;
                                    }
                                });

                                // Si el campo muestra se vacía, permitimos que se autocomplete de nuevo
                                document.getElementById('muestra').addEventListener('change', function() {
                                    if (this.value === '') {
                                        muestraEditadaManual = false;
                                        // Disparamos el evento input para recalcular
                                        document.getElementById('cant_soli').dispatchEvent(new Event('input'));
                                    }
                                });
                            </script>

                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="defecto_si">
                                    <i class="fas fa-exclamation-triangle me-1 text-primary"></i>Defecto:
                                </label><br />
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="defecto" id="defecto_si" value="SI" required>
                                    <label class="form-check-label" for="defecto_si">SÍ</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="defecto" id="defecto_no" value="NO" required checked>
                                    <label class="form-check-label" for="defecto_no">NO</label>
                                </div>

                                <div id="defectoOptionsContainer" style="display: none; margin-top: 10px;">
                                    <label class="form-label" for="tipo_defecto">Tipo de Defecto:</label>
                                    <select class="form-select" id="tipo_defecto" name="tipo_defecto">
                                        <option value="" selected>Seleccionar</option>
                                        <option value=" (CR)">CR (crítico)</option>
                                        <option value=" (MY)">MY (mayor)</option>
                                        <option value=" (MN)">MN (menor)</option>
                                    </select>
                                </div>

                                <!-- Campo oculto que contendrá el valor final -->
                                <input type="hidden" id="defecto_final" name="defecto_final" value="NO">
                            </div>

                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="estado_aprobado">
                                    <i class="fas fa-check-circle me-1 text-primary"></i>Estado:
                                </label><br />
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="validado" id="estado_aprobado" value="Aprobado" checked>
                                    <label class="form-check-label" for="estado_aprobado">Aprobado</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="validado" id="estado_rechazado" value="Rechazado">
                                    <label class="form-check-label" for="estado_rechazado">Rechazado</label>
                                </div>
                            </div>

                            <div class="mb-3 col-md-12">
                                <label class="form-label" for="mce_aplica">
                                    <i class="fas fa-clipboard-check me-1 text-primary"></i>MCE
                                </label>
                                <div class="d-flex gap-4 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="mce" id="mce_aplica" value="Aplica" required style="transform: scale(1.3); margin-right: 8px;">
                                        <label class="form-check-label" for="mce_aplica">Aplica</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="mce" id="mce_noaplica" value="N/A" required style="transform: scale(1.3); margin-right: 8px;">
                                        <label class="form-check-label" for="mce_noaplica">No Aplica</label>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3 col-md-12">
                                <label class="form-label" for="cadena_aplica">
                                    <i class="fas fa-thermometer-half me-1 text-primary"></i>Cadena de Frío
                                </label>
                                <div class="d-flex gap-4 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="cadena" id="cadena_aplica" value="Aplica" required style="transform: scale(1.3); margin-right: 8px;">
                                        <label class="form-check-label" for="cadena_aplica">Aplica</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="cadena" id="cadena_noaplica" value="N/A" required style="transform: scale(1.3); margin-right: 8px;">
                                        <label class="form-check-label" for="cadena_noaplica">No Aplica</label>
                                    </div>
                                </div>

                                <!-- Contenedor para los campos dinámicos con layout horizontal -->
                                <div id="cadena_campos" class="cadena-frio-layout" style="display: none;">
                                    <div class="border p-3 rounded bg-light">
                                        <label class="form-label d-block mb-2" for="temperatura">Temperatura:</label>
                                        <div class="input-group" style="width: 100%;">
                                            <input type="number" class="form-control" id="temperatura" name="temperatura" placeholder="Ej: 2">
                                            <span class="input-group-text bg-gray">°C</span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Campo oculto que contendrá el valor final -->
                                <input type="hidden" id="cadena_final" name="cadena_final" value="N/A">
                            </div>

                            <div class="mb-3 col-md-12">
                                <label class="form-label" for="condiciones_aplica">
                                    <i class="fas fa-warehouse me-1 text-primary"></i>Condiciones de Almacenamiento
                                </label>
                                <div class="d-flex gap-4 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="condiciones_alm" id="condiciones_aplica" value="Aplica" required style="transform: scale(1.3); margin-right: 8px;">
                                        <label class="form-check-label" for="condiciones_aplica">Aplica</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="condiciones_alm" id="condiciones_noaplica" value="N/A" required style="transform: scale(1.3); margin-right: 8px;">
                                        <label class="form-check-label" for="condiciones_noaplica">No Aplica</label>
                                    </div>
                                </div>

                                <!-- Contenedor para los campos dinámicos -->
                                <div id="condiciones_campos" style="display: none; margin-top: 20px;">
                                    <div class="border p-3 rounded bg-light">
                                        <textarea class="form-control" id="condiciones_alm_texto" name="condiciones_alm_texto" rows="3" placeholder="Ej: Mantener en lugar fresco y seco"></textarea>
                                    </div>
                                </div>

                                <!-- Campo oculto que contendrá el valor final -->
                                <input type="hidden" id="condiciones_final" name="condiciones_de_almacenamiento" value="N/A">
                            </div>

                            <div class="mb-3 col-md-12">
                                <label for="observacion" class="form-label">
                                    <i class="fas fa-comment-alt me-1 text-primary"></i>Observación:
                                </label>
                                <textarea name="observacion" id="observacion" class="form-control" rows="3"
                                    placeholder="Registra Observación si es necesario"></textarea>
                            </div>

                            <div class="mb-3 col-md-12">
                                <button type="button" id="submitFormBtn" class="btn btn-primary w-100">
                                    <i class="fas fa-save me-2"></i>Guardar Condición
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Loader Script
        window.addEventListener('load', function () {
            const loader = document.getElementById('loader');
            const contenido = document.getElementById('contenidocompleto');

            setTimeout(() => {
                loader.style.display = 'none';
                contenido.style.display = 'block';
            }, 1500);
        });

        $(document).ready(function() {
            // Inicializar DataTable con opciones
            var table = $('#insumosTable').DataTable({
                "pageLength": 10,
                "lengthMenu": [10, 25, 50, 100],
                "order": [
                    [5, 'desc']
                ],
                "searching": false,
                "info": false,
                "fixedHeader": true
            });

            var searchValueGlobal = '';
            var actualizado = false;
            var elaboracionValue = '';

            // Función para limpiar filtros
            $('#limpiarBtn').on('click', function() {
                // Limpiar campos del formulario
                $('#tipoMovimiento').val('');
                $('#searchInput').val('');
                
                // Limpiar variables globales
                searchValueGlobal = '';
                elaboracionValue = '';
                
                // Ocultar tabla y botones, mostrar mensaje inicial
                $('#tableContainer').hide();
                $('#actionButtons').hide();
                $('#initialMessage').show();
                
                // Limpiar la tabla
                table.clear().draw();
                
                // Mostrar mensaje de confirmación
                alert('Filtros limpiados correctamente');
            });

            // Manejar el envío del formulario de búsqueda
            $('#searchForm').on('submit', function(e) {
                e.preventDefault();
                var searchValue = $('#searchInput').val().trim();
                var tipoMovimiento = $('#tipoMovimiento').val();

                if (!searchValue && !tipoMovimiento) {
                    alert('Por favor ingrese un número de movimiento');
                    return;
                }

                searchValueGlobal = searchValue;

                // Ocultar mensaje inicial y mostrar tabla y botones
                $('#initialMessage').hide();
                $('#tableContainer').show();
                $('#actionButtons').show();

                // Cargar datos iniciales
                cargarDatosEnTiempoReal();
            });

            // Función para habilitar/deshabilitar botones y actualizar URLs
            function validateButtons() {
                var searchValue = $('#searchInput').val();
                var tipoMovimiento = $('#tipoMovimiento').val();
                searchValueGlobal = searchValue;
                var row = table.rows().data().toArray();
                var found = false;
                elaboracionValue = '';

                // Buscar en la tabla
                for (var i = 0; i < row.length; i++) {
                    if (row[i][4] == searchValue) {
                        found = true;
                        elaboracionValue = row[i][32];
                        break;
                    }
                }
                console.log("El valor de elaboración es: " + elaboracionValue);

                // Habilitar/deshabilitar botones
                $('#elaborarLink').prop('disabled', !found);
                $('#aprobarLink').prop('disabled', !elaboracionValue || elaboracionValue.trim() === '');

                // Actualizar enlaces si se encuentra el número de movimiento
                if (found) {
                    $('#elaborarLink').off('click').on('click', function() {
                        var movimiento = searchValue;
                        // Agregar el parámetro tipoMovimiento a la URL
                        window.open('elaboracion.php?movimiento=' + movimiento + '&tipoMovimiento=' + tipoMovimiento, 'ventanaEmergente', 'width=800,height=600');
                        validateButtons();
                    });
                    $('#aprobarLink').off('click').on('click', function(e) {
                        e.preventDefault(); // Evitamos que el enlace se ejecute de inmediato

                        // Validamos si el campo de elaboración tiene contenido
                        if (!elaboracionValue || elaboracionValue.trim() === '') {
                            alert('La elaboración aún no está disponible. Por favor, espera.');
                            return;
                        }

                        // Validamos si se ha seleccionado un tipo de movimiento
                        var tipoMovimiento = $('#tipoMovimiento').val();
                        if (tipoMovimiento === "") {
                            alert('Por favor, seleccione un tipo de movimiento.');
                            return;
                        }

                        // Mostramos confirmación al usuario
                        var confirmar = confirm('¿Estás seguro que deseas aprobar este movimiento?');
                        if (confirmar) {
                            var movimiento = searchValue;
                            window.open(
                                'aprobacion.php?movimiento=' + movimiento + '&tipoMovimiento=' + tipoMovimiento,
                                'ventanaEmergente',
                                'width=800,height=600'
                            );
                            validateButtons(); // Validar botones tras la acción
                        }
                    });
                }
            }

            // Función para abrir el modal
            window.openModal = function(id, noMovimiento, condi, cadena, condicionesAlm, cant_soli, pac, muestra, defecto, observacion, mce, validado = "Aprobado") {
                console.log('🟢 Modal abierto con los siguientes datos:');
                console.log({
                    ID: id,
                    NoMovimiento: noMovimiento,
                    condi,
                    cadena,
                    condicionesAlm,
                    cant_soli,
                    pac,
                    muestra,
                    defecto,
                    observacion,
                    mce,
                    validado
                });

                $('#ID').val(id);
                $('#NoMovimiento').val(noMovimiento);
                $(`input[name="condi"][value="${condi}"]`).prop('checked', true);
                $(`input[name="cadena"][value="${cadena}"]`).prop('checked', true);
                $('#cant_soli').val(cant_soli)
                $(`input[name="pac"][value="${pac}"]`).prop('checked', true);
                $('#muestra').val(muestra);
                // Manejar el valor de MCE
                $(`input[name="mce"][value="${mce}"]`).prop('checked', true);

                // Manejar condiciones de almacenamiento
                if (condicionesAlm && condicionesAlm.trim() !== 'N/A') {
                    $('#condiciones_aplica').prop('checked', true);
                    $('#condiciones_campos').show();
                    $('#condiciones_alm_texto').val(condicionesAlm.trim());
                    $('#condiciones_final').val(condicionesAlm.trim());
                } else {
                    $('#condiciones_noaplica').prop('checked', true);
                    $('#condiciones_campos').hide();
                    $('#condiciones_alm_texto').val('');
                    $('#condiciones_final').val('N/A');
                }

                // Manejar el valor de cadena
                if (cadena && (cadena.includes('Temperatura') || cadena.includes('Humedad'))) {
                    $('#cadena_aplica').prop('checked', true);
                    $('#cadena_campos').show();

                    // Extraer tipo y valor si existe
                    const match = cadena.match(/(Temperatura|Humedad)\s*\((\d+)°\)/);
                    if (match) {
                        $('#tipo_cadena').val(match[1]);
                        $('#valor_cadena').val(match[2]);
                    }
                    $('#cadena_final').val(cadena);
                } else {
                    $('#cadena_noaplica').prop('checked', true);
                    $('#cadena_campos').hide();
                    $('#cadena_final').val(cadena || 'N/A');
                }

                if (defecto && defecto.startsWith('SI')) {
                    $('#defecto_si').prop('checked', true);
                    defectoOptionsContainer.style.display = 'block';

                    // Extraer el tipo de defecto si existe
                    const tipo = defecto.match(/\((.*?)\)/);
                    if (tipo && tipo[1]) {
                        $('#tipo_defecto').val(` (${tipo[1]})`);
                    }
                    $('#defecto_final').val(defecto);
                } else {
                    $('#defecto_no').prop('checked', true);
                    defectoOptionsContainer.style.display = 'none';
                    $('#defecto_final').val('NO');
                }
                $('#observacion').val(observacion);
                
                // Manejar el estado (validado)
                if (validado === 'Rechazado') {
                    $('#estado_rechazado').prop('checked', true);
                } else {
                    $('#estado_aprobado').prop('checked', true);
                }

                $('#addInsumoModal').modal('show');
            };

            // Función para cerrar el modal 
            window.closeModal = function() {
                $('#addInsumoModal').modal('hide');
            };

            // Enviar el formulario del modal con AJAX
            $('#submitFormBtn').on('click', function(e) {
                e.preventDefault();

                var formData = {
                    ID: $('#ID').val(),
                    NoMovimiento: $('#NoMovimiento').val(),
                    condi: $('input[name="condi"]:checked').val(),
                    cadena: $('#cadena_final').val(),
                    condiciones_de_almacenamiento: $('#condiciones_alm_texto').val(),
                    cant_soli: $('#cant_soli').val(),
                    muestra: $('#muestra').val(),
                    pac: $('input[name="pac"]:checked').val(),
                    muestra: $('#muestra').val(),
                    mce: $('input[name="mce"]:checked').val(),
                    defecto: $('#defecto_final').val(),
                    validado: $('input[name="validado"]:checked').val(),
                    observacion: $('textarea[name="observacion"]').val()
                };

                $.ajax({
                    type: 'POST',
                    url: 'procesar_insumo.php',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === "success") {
                            alert('Condición actualizada con éxito.');
                            closeModal();
                            cargarDatosEnTiempoReal();
                        } else {
                            alert('Error al actualizar la condición: ' + (response.message || 'Error desconocido'));
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error en la solicitud AJAX:', error);
                        alert('Ocurrió un error en la solicitud. Detalles en la consola.');
                    }
                });
            });

            // Función para cargar los datos en tiempo real
            function cargarDatosEnTiempoReal() {
                if (!searchValueGlobal) return;

                $.ajax({
                    type: 'GET',
                    url: 'recargar.php',
                    data: {
                        searchQuery: searchValueGlobal,
                        exactMatch: true,
                        tipoMovimiento: $('#tipoMovimiento').val()
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === "success" && Array.isArray(response.data)) {
                            table.clear();

                            response.data.forEach(function(item) {
                                table.row.add([
                                    `<button class="btn btn-info edit-btn" data-id="${limpiarValor(item['No. Movimiento'])}" data-realid="${limpiarValor(item.ID)}" onclick="openModal('${limpiarValor(item.ID)}', '${limpiarValor(item['No. Movimiento'])}', '${limpiarValor(item.condi)}', '${limpiarValor(item.cadena)}', '${limpiarValor(item.condiciones_de_almacenamiento)}', '${limpiarValor(item.cant_soli)}', '${limpiarValor(item.pac)}', '${limpiarValor(item.muestra)}', '${limpiarValor(item.defecto)}', '${limpiarValor(item.Observacion_usu)}')">
                                <i class="fas fa-plus"></i> Agregar
                            </button>`,
                                    limpiarValor(item.ID),
                                    limpiarValor(item['No. Orden']),
                                    limpiarValor(item.Proveedor),
                                    limpiarValor(item['No. Movimiento']),
                                    limpiarValor(item['Tipo Movimiento']),
                                    item['Fecha Movimiento'] ? new Date(item['Fecha Movimiento']).toLocaleString() : '',
                                    limpiarValor(item['Tipo Documento']),
                                    limpiarValor(item['No. Documento soporte']),
                                    limpiarValor(item['Cod. Producto']),
                                    limpiarValor(item['Producto_Comercial']),
                                    limpiarValor(item['Forma Farmaceutica']),
                                    limpiarValor(item.Presentacion),
                                    limpiarValor(item.Fabricante),
                                    limpiarValor(item.Lote),
                                    item['Fecha Vencimiento'] ? new Date(item['Fecha Vencimiento']).toLocaleDateString() : '',
                                    limpiarValor(item.Valor),
                                    limpiarValor(item['Registro Sanitario']),
                                    limpiarValor(item['Vigencia registro Sanitario']),
                                    limpiarValor(item.CUM),
                                    limpiarValor(item['Codigo Clasificacion']),
                                    limpiarValor(item.Clasificacion),
                                    limpiarValor(item.condi),
                                    limpiarValor(item.cadena),
                                    limpiarValor(item['mce']),
                                    limpiarValor(item.condiciones_de_almacenamiento),
                                    limpiarValor(item['Cantidad Mov']),
                                    limpiarValor(item.cant_soli),
                                    limpiarValor(item.pac),
                                    limpiarValor(item.muestra),
                                    limpiarValor(item.defecto),
                                    limpiarValor(item.Observacion_usu),
                                    limpiarValor(item.elaboracion),
                                    limpiarValor(item.ElaboracionNombre),
                                    limpiarValor(item.aprobacion),
                                    limpiarValor(item.AprobacionNombre),
                                    limpiarValor(item.validado)
                                ]).draw(false);
                            });

                            table.draw();
                            validateButtons();
                        } else {
                            console.warn('No se encontraron datos o la respuesta no es válida.');
                            $('#tableContainer').hide();
                            $('#actionButtons').hide();
                            $('#initialMessage').html('<i class="fas fa-search-minus"></i><h5>Sin Resultados</h5><p class="mb-0">No se encontraron resultados para el número de movimiento ingresado.</p>').show();
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error en la solicitud AJAX:', error);
                    }
                });
            }
        });

        // Función para limpiar valores
        function limpiarValor(valor) {
            return valor ? valor.toString().replace(/[^\w\sáéíóúüñÁÉÍÓÚÜÑ'/().,-_#°*$]/gi, '') : '';
        }

        // Scripts para manejar las funcionalidades del modal
        document.addEventListener('DOMContentLoaded', function() {
            // Manejo del defecto
            const defectoSi = document.getElementById('defecto_si');
            const defectoNo = document.getElementById('defecto_no');
            const defectoOptionsContainer = document.getElementById('defectoOptionsContainer');
            const tipoDefecto = document.getElementById('tipo_defecto');
            const defectoFinal = document.getElementById('defecto_final');

            // Mostrar/ocultar opciones cuando cambia la selección SI/NO
            defectoSi.addEventListener('change', function() {
                defectoOptionsContainer.style.display = this.checked ? 'block' : 'none';
                updateDefectoFinal();
            });

            defectoNo.addEventListener('change', function() {
                defectoOptionsContainer.style.display = 'none';
                tipoDefecto.value = ''; // Limpiar la selección
                defectoFinal.value = 'NO';
            });

            // Actualizar valor cuando cambia el tipo de defecto
            tipoDefecto.addEventListener('change', updateDefectoFinal);

            function updateDefectoFinal() {
                if (defectoSi.checked) {
                    // Solo asigna el valor del tipo de defecto (sin el "SI")
                    defectoFinal.value = tipoDefecto.value || '';
                } else {
                    defectoFinal.value = 'NO';
                }
            }

            // Manejo de cadena de frío
            const cadenaAplica = document.getElementById('cadena_aplica');
            const cadenaNoAplica = document.getElementById('cadena_noaplica');
            const cadenaCampos = document.getElementById('cadena_campos');
            const temperaturaInput = document.getElementById('temperatura');
            const cadenaFinal = document.getElementById('cadena_final');

            // Mostrar/ocultar campos cuando cambia la selección
            cadenaAplica.addEventListener('change', function() {
                cadenaCampos.style.display = this.checked ? 'flex' : 'none';
                updateCadenaFinal();
            });

            cadenaNoAplica.addEventListener('change', function() {
                cadenaCampos.style.display = 'none';
                cadenaFinal.value = 'N/A';
            });

            // Actualizar valor cuando cambia el campo de temperatura
            temperaturaInput.addEventListener('input', updateCadenaFinal);

            function updateCadenaFinal() {
                if (cadenaAplica.checked) {
                    const temp = temperaturaInput.value ? `${temperaturaInput.value}°C` : '';
                    cadenaFinal.value = temp ? `Temperatura: ${temp}` : '';
                } else {
                    cadenaFinal.value = 'N/A';
                }
            }

            // Manejo de condiciones de almacenamiento
            const condicionesAplica = document.getElementById('condiciones_aplica');
            const condicionesNoAplica = document.getElementById('condiciones_noaplica');
            const condicionesCampos = document.getElementById('condiciones_campos');
            const condicionesAlmTexto = document.getElementById('condiciones_alm_texto');
            const condicionesFinal = document.getElementById('condiciones_final');

            // Mostrar/ocultar campos cuando cambia la selección
            condicionesAplica.addEventListener('change', function() {
                condicionesCampos.style.display = this.checked ? 'block' : 'none';
                updateCondicionesFinal();
            });

            condicionesNoAplica.addEventListener('change', function() {
                condicionesCampos.style.display = 'none';
                condicionesAlmTexto.value = '';
                condicionesFinal.value = 'N/A';
            });

            // Actualizar valor cuando cambia el texto de condiciones de almacenamiento
            condicionesAlmTexto.addEventListener('input', updateCondicionesFinal);

            function updateCondicionesFinal() {
                if (condicionesAplica.checked) {
                    condicionesFinal.value = condicionesAlmTexto.value || '';
                } else {
                    condicionesFinal.value = 'N/A';
                }
            }
        });
    </script>

    <!-- Incluir librería jsPDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.27/jspdf.plugin.autotable.min.js"></script>
    <script src="java/pdf.js?<?php echo time(); ?>"></script>
</body>

</html>