<?php
// Establecer la conexión con la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array("Database" => "recep_tec", "UID" => "sadumesm", "PWD" => "Dumes100%", "characterset" => "UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
}

// Obtener datos de insumos
$query = "SELECT DISTINCT
    i.[ID],
    i.[No. Orden], 
    i.Proveedor, 
    i.[No. Movimiento], 
    i.[Tipo Movimiento], 
    i.[Fecha Movimiento], 
    i.[Tipo Documento], 
    i.[No. Documento soporte], 
    i.[Cod. Producto], 
    i.[Producto_Comercial], 
    i.[Forma Farmaceutica], 
    i.Presentacion, 
    i.Fabricante, 
    i.Lote, 
    i.[Fecha Vencimiento], 
    i.Valor, 
    i.[Registro Sanitario], 
    i.[Vigencia registro Sanitario], 
    i.CUM, 
    i.[Codigo Clasificacion], 
    i.Clasificacion, 
    i.condi,
    i.cadena,
    i.mce,
    i.[Cantidad Mov], 
    i.cant_soli,
    i.pac,
    i.muestra,
    i.defecto,
    i.Observacion_usu, 
    i.elaboracion,
    e.NomYApellCmp AS ElaboracionNombre, 
    i.aprobacion,
    a.NomYApellCmp AS AprobacionNombre,
    i.validado
FROM insumos i
LEFT JOIN firma_usuarios e 
    ON i.elaboracion = e.Identificacion
LEFT JOIN firma_usuarios a 
    ON i.aprobacion = a.Identificacion";
$stmt = sqlsrv_query($conn, $query);

$insumos = array();
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    // Asegúrate de que todos los campos estén presentes
    $insumos[] = array(
        "Mas" => "<button class='btn btn-info edit-btn' data-id='{$row['No. Movimiento']}'><i class='fas fa-plus'></i> Agregar</button>",
        "ID" => $row['ID'],
        "No. Orden" => $row['No. Orden'],
        "Proveedor" => $row['Proveedor'],
        "No. Movimiento" => $row['No. Movimiento'],
        "Tipo Movimiento" => $row['Tipo Movimiento'],
        "Fecha Movimiento" => $row['Fecha Movimiento']->format('Y-m-d H:i:s'),
        "Tipo Documento" => $row['Tipo Documento'],
        "No. Documento Soporte" => $row['No. Documento soporte'],
        "Cod. Producto" => $row['Cod. Producto'], // Corregí el nombre de la clave aquí
        "Producto Comercial" => $row['Producto_Comercial'],
        "Forma Farmaceutica" => $row['Forma Farmaceutica'],
        "Presentacion" => $row['Presentacion'],
        "Fabricante" => $row['Fabricante'],
        "Lote" => $row['Lote'],
        "Fecha Vencimiento" => $row['Fecha Vencimiento'] ? $row['Fecha Vencimiento']->format('Y-m-d') : '',
        "Valor" => $row['Valor'],
        "Registro Sanitario" => $row['Registro Sanitario'],
        "Vigencia registro Sanitario" => $row['Vigencia registro Sanitario'],
        "CUM" => $row['CUM'],
        "Codigo Clasificacion" => $row['Codigo Clasificacion'],
        "Clasificacion" => $row['Clasificacion'],
        "condi" => $row['condi'],
        "cadena" => $row['cadena'],
        "mce" => $row['mce'],
        "Cantidad Mov" => $row['Cantidad Mov'],
        "cant_soli" => $row['cant_soli'],
        "pac" => $row['pac'],
        "muestra" => $row['muestra'],
        "defecto" => $row['defecto'],
        "Observacion_usu" => $row['Observacion_usu'],
        "elaboracion" => $row['elaboracion'],
        "ElaboracionNombre" => $row['ElaboracionNombre'],
        "aprobacion" => $row['aprobacion'],
        "AprobacionNombre" => $row['AprobacionNombre'],
        "validado" => $row['validado']
    );
}

// Devolver los datos en formato JSON
header('Content-Type: application/json');
echo json_encode($insumos);
?>