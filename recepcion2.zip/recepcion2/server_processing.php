<?php
// Establecer conexión (igual que en vista.php)

$requestData = $_REQUEST;

// Columnas de la tabla
$columns = array(
    0 => 'i.[No. Movimiento]',
    1 => 'i.[No. Orden]',
    // listar todas las columnas ordenables
);

// Consulta base
$query = "SELECT SQL_CALC_FOUND_ROWS i.*, e.NomYApellCmp AS ElaboracionNombre, a.NomYApellCmp AS AprobacionNombre
          FROM insumos i
          LEFT JOIN firma_usuarios e ON i.elaboracion = e.Identificacion
          LEFT JOIN firma_usuarios a ON i.aprobacion = a.Identificacion";

// Filtrado
if (!empty($requestData['search']['value'])) {
    $query .= " WHERE i.[No. Movimiento] LIKE '".$requestData['search']['value']."%' ";
}

// Orden
if (isset($requestData['order'][0]['column'])) {
    $query .= " ORDER BY ".$columns[$requestData['order'][0]['column']]." ".$requestData['order'][0]['dir']." ";
} else {
    $query .= " ORDER BY i.[Fecha Movimiento] DESC ";
}

// Paginación
$query .= " LIMIT ".$requestData['start'].", ".$requestData['length']." ";

$stmt = sqlsrv_query($conn, $query);
$data = array();
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $data[] = $row;
}

// Total de registros
$totalQuery = "SELECT COUNT(*) FROM insumos";
$totalResult = sqlsrv_query($conn, $totalQuery);
$totalData = sqlsrv_fetch_array($totalResult)[0];

$json_data = array(
    "draw" => intval($requestData['draw']),
    "recordsTotal" => intval($totalData),
    "recordsFiltered" => intval($totalData),
    "data" => $data
);

echo json_encode($json_data);
?>