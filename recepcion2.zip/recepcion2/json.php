<?php
// Conexión a la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";
$connectionInfo = array("Database" => "recep_tec", "UID" => "sadumesm", "PWD" => "Dumes100%", "characterset" => "UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    die(json_encode([]));  // Si hay un error de conexión, devolvemos un JSON vacío.
}

// Obtener datos de la tabla Firma_Usuarios
$usuarios = array();
$query = "SELECT NomYApellCmp, Identificacion, clave FROM firma_usuarios";
$stmt = sqlsrv_query($conn, $query);

if ($stmt === false) {
    die(json_encode([]));  // Si hay error al obtener los datos, devolvemos un JSON vacío.
}

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $usuarios[] = $row;
}

// Devolvemos los datos en formato JSON
echo json_encode($usuarios);
?>
