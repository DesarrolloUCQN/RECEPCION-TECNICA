<?php
// Establecer la conexión con la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";  
$connectionInfo = array(
    "Database" => "recep_tec", 
    "UID" => "sadumesm", 
    "PWD" => "Dumes100%", 
    "CharacterSet" => "UTF-8"
);

// Establecer la conexión
$conn = sqlsrv_connect($serverName, $connectionInfo);

// Comprobar si la conexión es exitosa
if (!$conn) {
    die(print_r(sqlsrv_errors(), true)); // Mostrar errores de conexión si falla
} 

// Verificar si la cédula fue enviada por GET
if (isset($_GET['cedula'])) {
    $cedula = $_GET['cedula']; // Recoger la cédula enviada por GET

    // Preparamos la consulta SQL para buscar el nombre y la ruta de la imagen de la cédula
    $sql = "SELECT NomYApellCmp, RutaImagen, clave FROM firma_usuarios WHERE Identificacion = ?";
    $stmt = sqlsrv_prepare($conn, $sql, array(&$cedula));

    // Ejecutar la consulta
    if (sqlsrv_execute($stmt)) {
        // Verificar si encontramos resultados
        if (sqlsrv_has_rows($stmt)) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            // Si encontramos la cédula, devolver el nombre y la ruta de la imagen en formato JSON
            echo json_encode(array(
                "success" => true, 
                "nombre" => $row['NomYApellCmp'], 
                "ruta_imagen" => $row['RutaImagen'],
                "clave" => $row['clave']
            ));
        } else {
            // Si no encontramos la cédula
            echo json_encode(array("success" => false));
        }
    } else {
        // Si hay algún error al ejecutar la consulta
        echo json_encode(array("success" => false, "error" => "Error al ejecutar la consulta"));
    }

    // Cerrar la declaración
    sqlsrv_free_stmt($stmt);
} else {
    // Si no se recibe la cédula en el GET
    echo json_encode(array("success" => false, "error" => "Cédula no proporcionada"));
}

// Cerrar la conexión
sqlsrv_close($conn);
?>
