<?php
// Establecer la conexión con la base de datos
$serverName = "PA-S1-DATA\\UCQNDATA";  
$connectionInfo = array("Database" => "recep_tec", "UID" => "sadumesm", "PWD" => "Dumes100%", "characterset"=> "UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
}

$claveIncorrecta = false;  // Variable para controlar si la clave es incorrecta
$usuarioValido = false;    // Variable para controlar si el usuario es válido
$nombre = "";               // Variable para almacenar el nombre del usuario
$imagenSubida = false;      // Variable para controlar si la imagen fue subida

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verificar si se ha enviado la cédula y la clave
    if (isset($_POST['cedula']) && isset($_POST['clave'])) {
        $cedula = $_POST['cedula'];
        $clave = $_POST['clave'];
        
        // Consultar la cédula y la clave en la base de datos
        $query = "SELECT NomYApellCmp, clave FROM firma_usuarios WHERE Identificacion = ?";
        $params = array($cedula);
        $stmt = sqlsrv_query($conn, $query, $params);
        
        if ($stmt) {
            $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
            if ($row) {
                // Recuperar el nombre y la clave almacenada
                $nombre = $row['NomYApellCmp'];
                $claveCorrecta = $row['clave'];
                
                // Eliminar espacios en blanco antes y después de la clave
                if (trim($clave) === trim($claveCorrecta)) {
                    // La clave es correcta, podemos proceder
                    $usuarioValido = true; // Usuario válido
                } else {
                    // Si la clave es incorrecta, marcamos la variable
                    $claveIncorrecta = true;
                }
            } else {
                echo "<script>alert('No se encontró el usuario.'); </script>";
            }
        }
    }

    // Si el usuario es válido y se ha subido una imagen
    if ($usuarioValido && isset($_FILES['imagen']) && $_FILES['imagen']['error'] == 0) {
        // Subir la imagen
        $imagenTmpName = $_FILES['imagen']['tmp_name'];
        $imagenName = basename($_FILES['imagen']['name']);
        $directorioDestino = 'C:/xampp/htdocs/recepcion/imagenes/';
        $rutaDestino = $directorioDestino . $imagenName;

        // Mover el archivo a la carpeta de destino
        if (move_uploaded_file($imagenTmpName, $rutaDestino)) {
            // Ruta accesible desde el navegador
            $rutaRelativa = 'imagenes/' . $imagenName;

            // Actualizar los datos en la base de datos (guardar solo la ruta)
            $queryUpdate = "UPDATE firma_usuarios 
                            SET RutaImagen = ?, FechaRegistro = GETDATE() 
                            WHERE Identificacion = ?";
            $paramsUpdate = array($rutaRelativa, $cedula);
            $stmtUpdate = sqlsrv_query($conn, $queryUpdate, $paramsUpdate);

            if ($stmtUpdate) {
                $imagenSubida = true; // Marcar que la imagen fue subida
            } else {
                echo "Error al actualizar la ruta en la base de datos: " . print_r(sqlsrv_errors(), true);
            }
        } else {
            echo "Error al mover el archivo a la carpeta de destino.";
        }
    } elseif ($usuarioValido && isset($_FILES['imagen']) && $_FILES['imagen']['error'] != 0) {
        echo "Error en la carga de la imagen. Código de error: " . $_FILES['imagen']['error'];
    } elseif ($usuarioValido) {
        echo "No se ha seleccionado una imagen.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar Usuario y Subir Imagen</title>
    <script>
        // Verificar si la clave es incorrecta, si es así mostrar un alert
        <?php if ($claveIncorrecta): ?>
            alert('Contraseña incorrecta');
        <?php endif; ?>
        // Verificar si la imagen fue subida
        <?php if ($imagenSubida): ?>
            alert('Imagen subida correctamente.');
        <?php endif; ?>
    </script>
    <style>
        /* Estilo general para el cuerpo */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 20px;
}

/* Contenedor de formulario */
form {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    max-width: 500px;
    margin: 305px auto;
    display: flex;
    flex-direction: column;
}

/* Título */
h2 {
    text-align: center;
    font-size: 1.8em;
    color: #333;
}

/* Estilos para las etiquetas */
label {
    font-size: 1.1em;
    margin-bottom: 8px;
    color: #333;
}

/* Estilo para los inputs */
input[type="text"],
input[type="password"],
input[type="file"] {
    padding: 8px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 1em;
    color: #333;
    background-color: #f9f9f9;
}

/* Inputs con campos de solo lectura */
input[readonly] {
    background-color: #e9ecef;
    cursor: not-allowed;
    width: 300px;
}

/* Estilo para el botón de submit */
input[type="submit"] {
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1.1em;
    transition: background-color 0.3s;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}
 .o
/* Estilos para los divs */
div {
    margin-bottom: 15px;
}

/* Estilo para el archivo cargado */
input[type="file"] {
    font-size: 1em;
}

/* Estilo para la alerta (si no está validado el usuario) */
.alert {
    padding: 10px;
    background-color: #f44336;
    color: white;
    margin-bottom: 20px;
    border-radius: 5px;
    text-align: center;
}

/* Estilo para los mensajes de éxito (si se sube la imagen correctamente) */
.success {
    padding: 10px;
    background-color: #4CAF50;
    color: white;
    margin-bottom: 20px;
    border-radius: 5px;
    text-align: center;
}
button{
    padding: 10px;
    background-color:rgb(223, 35, 35);
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1.1em;
    transition: background-color 0.3s;
}
.regresar{
    position: fixed;
    top: 43%;
    right: 30%;
}
/* Estilo base para el enlace */
.lo {
    background-color:rgb(228, 19, 19); /* Color del texto */
    text-decoration: none; /* Quitar subrayado */
    font-size: 16px; /* Tamaño de fuente */
    padding: 10px; /* Espaciado alrededor del texto */
    transition: color 0.3s ease, background-color 0.3s ease; /* Transición suave */
    color: white;
    border-radius: 5px; /* Bordes redondeados */
}

/* Estilo al pasar el mouse (hover) */
.lo:hover {
    color: #ffffff; /* Cambia el color del texto */
    background-color: #0056b3; /* Cambia el fondo */
    border-radius: 5px; /* Bordes redondeados */
}


    </style>
    <!--
<div class="imagen1" style="
    position: relative;
    top: 40px;
    left: 20px;
">
    <img src="img/loader.png" alt="" style="
    height: 272px;
    width: 254px;
">
    </div>
-->
</head>
<body>
    <?php if (!$usuarioValido): ?>
        <form method="POST" enctype="multipart/form-data">
            <label for="cedula">Cédula:</label>
            <input type="text" name="cedula" id="cedula" required>
            <label for="clave">Clave:</label>
            <input type="password" name="clave" id="clave" required>
            <input type="submit" value="Guardar">
        </form>
        <div class="regresar">
        <a href="index.php"><button>Regresar</button></a>
        </div>
    <?php else: ?>
        <div style="position: fixed; right: 41%; top: 31%;">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre" value="_ANDRES CASANOVA_ RICARDO " readonly="">
        </div>
        <form method="POST" enctype="multipart/form-data">
            <div>
                <label for="imagen">Subir Imagen:</label>
                <input type="file" name="imagen" id="imagen" accept="image/*" required>
            </div>
            <input type="submit" value="Subir Imagen">
            <input type="hidden" name="cedula" value="<?php echo htmlspecialchars($cedula); ?>">
            <input type="hidden" name="clave" value="<?php echo htmlspecialchars($clave); ?>">
        </form>
        <br>
        <a href="index.php" class="lo" style="
    position: absolute;
    left: 15%;
">REGRESAR</a>
    <?php endif; ?>

    <?php 
    // Si hay imagen en la base de datos, mostrarla
    if ($usuarioValido) {
        // Recuperar la ruta de la imagen desde la base de datos
        $queryImagen = "SELECT RutaImagen FROM firma_usuarios WHERE Identificacion = ?";
        $paramsImagen = array($cedula);
        $stmtImagen = sqlsrv_query($conn, $queryImagen, $paramsImagen);
        
        if ($stmtImagen) {
            $rowImagen = sqlsrv_fetch_array($stmtImagen, SQLSRV_FETCH_ASSOC);
            if ($rowImagen && $rowImagen['RutaImagen']) {
                // Mostrar la imagen desde la ruta almacenada
                echo '<div style="position: absolute;
                top: 60%;
                left: 37%;"><h3>Imagen subida:</h3>';
                echo '<img src="' . $rowImagen['RutaImagen'] . '" alt="Imagen del usuario" width="200"></div>';
            } else {
                echo 'No se encontró la imagen en la base de datos.';
            }
        }
    }
    ?>         
</body>
</html>
